import 'react-native-gesture-handler';
import React from 'react';
import {View, StyleSheet, ScrollView, Dimensions, LogBox } from 'react-native';
import { ApolloClient, ApolloProvider, InMemoryCache } from '@apollo/client';
import Footer from './components/Footer';
import {baseUrl} from './Utils/constants';
const { width, height } = Dimensions.get('window');
import Navigator from './components/Navigator';
import { Provider } from 'react-redux';
import { myStore } from './components/redux/store';
const App = () => {
  LogBox.ignoreAllLogs();
  return (
      <Provider store={myStore}>
        <Navigator></Navigator>
      </Provider>
  );
}

export default App;
// const styles= StyleSheet.create({
//   container:{
//       flex:1, 
//       height:'100%',
//       width:'100%',
//       padding:height*0.010,
//       top:60
//   },
   
// });
