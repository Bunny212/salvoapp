
import { Dimensions, StyleSheet } from "react-native";

const { width, height } = Dimensions.get('window');
const stylesTags = StyleSheet.create({
    'p':{
        color:'#000',
    },
    'h4':{
        color:'#000',
        bottom:height*0.025
    },
    'img':{
        // height:'100%',
        // width:'100%',
        // scaleX:0.7,
        // scaleY:0.7,
        width:width*0.36,
        marginRight:-20,
    },
    'h3':{
        width:300
    },
    'h1':{
        color:'#000'
    },
    'strong':{
        width:'100%',
        // textAlign:'center',
    },
    'li':{
    },
    'a':{
        textDecorationLine:'none',
        fontSize:height*0.015,
        color:'#000',
    },
    'span':{
    },
});
export default stylesTags;