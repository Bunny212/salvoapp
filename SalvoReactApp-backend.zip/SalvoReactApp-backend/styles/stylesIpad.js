import { Dimensions, StyleSheet,Platform } from "react-native";

const { width, height } = Dimensions.get('screen')

export default StyleSheet.create({
  container:{
      flex:1,
      // justifyContent:'center',
      alignItems:'center',
      height:'100%',
      width:'100%',
      zIndex:-1,
    backgroundColor:'#fff'
  },
  productListContainer:{
      // flex:1,
      justifyContent:'flex-start',
      // alignItems:'center',
      height:'100%',
      width:'100%',
      zIndex:-1,
    backgroundColor:'#fff'    
  },
    wrapper: {
  },
  
  homeWrapper: {
    height:'100%'
  },
  logoContainer:{
    height: height * 0.3,
    width: width * 0.4
  },
  logo:{
    tintColor:'#fff',
    width: '100%',
    height: '100%',
    resizeMode:'contain',
  },
  slide1: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#CA2426',
  },
  slide2: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#317250'
  },
  slide3: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#317250'
  },
  slide4: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#317250'
  },
  slide1TextBold:{
   
    textAlign:'center',
    color:'#fff',
    fontWeight:'bold',
  },
  slide1Text:{
  
    textAlign:'center',
    color:'#fff'
  },
  text: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign:'center',
    bottom:height*0.08
  },
  Subtext: {
    color: '#fff',
    textAlign:'center',
    bottom:height * 0.06
  },
  SignUp:{
      justifyContent:'center',
      alignItems:'center',
      backgroundColor:'#fff',
      position:'absolute',
    
  },
  LoginContainer:{
      flexDirection:'row',
      justifyContent:'center',
      position:'absolute',
  },
  signupText:{
      textAlign:'center',
      fontWeight:"500",
      color:'#000',
     
  },
  Login:{
      fontWeight:'bold',
      color:'#fff',
      
  },
  loginText:{ 
      color:'#fff',
  },
    loginTextButton:{
     
      color:'#fff',
      textAlign:'center'
  },
  headerContainer:{
    flexDirection:'row',
    borderBottomColor:'#ca2426',
    borderTopColor:'#317250',
    alignItems:'center',
    backgroundColor:'#fff',
    // justifyContent:'center'
    borderBottomWidth:3,
    borderTopWidth:3,
  },
  closeSlider:{
    position:'absolute',
    zIndex:1
  },
  closeSliderIcon:{
  
    resizeMode:'contain',
    tintColor:'#fff'
  },
  logoHeader:{
    
    
    resizeMode:'contain',

  },
  HTMLcontainer:{
    backgroundColor:'#fff',
    flex:1,
  },
  facebook:{
    height:height*0.045,
    width:width*0.065,
    resizeMode:'contain',
    position:'absolute',
    left:width*0.330, 
    top:height*(-0.475)
  },
  instagram:{
    height:height*0.045,
    width:width*0.065,
    resizeMode:'contain',
    position:'absolute',
    left:width*0.420, 
    top:height*(-0.475)
  },
  twitter:{
    height:height*0.045,
    width:width*0.065,
    resizeMode:'contain',
    position:'absolute',
    left:width*0.530, 
    top:height*(-0.475)
  },
  searchBarContainer:{
    // padding:height*0.016,
    alignSelf:'center',
    justifyContent:'center',
    position:'absolute',
    width:'70%',
    zIndex:1,
    // height:height*0.12
  },
  searchBarInput:{
    backgroundColor:'#fff',
    borderColor:'#999DA3',
    zIndex:1,
    color:'#000',
  },

  //Home Screen Styles
/*   italianText:{
    color:'#317250',
    fontSize:width*0.07,
    textAlign:'center',
    lineHeight:height*0.045,
    top:height*0.010,
  },
  italianTextBold:{
    fontWeight:'bold',
   },
   stock:{
    backgroundColor:'#317250',
    padding:height*0.009,
    color:'#fff',
    textAlign:'center',
    borderBottomLeftRadius:6,
    borderBottomRightRadius:6,
   },
   orderOuter:{
    color:'#000', 
    fontWeight:'bold', 
    borderWidth:1, 
    padding:height*0.019,
    textAlign:'center', 
    borderColor:'gray',
    fontSize:height*0.020
   }, */

   blocksContainer:{
  
    borderColor:'#999DA3',
   
    flexDirection:'row',
    width:'100%',
    marginTop:0
  },

  //Header styles
  iconContainer:{
    justifyContent:'center',
    alignItems:'center'
  },

  iconStyle:{
    resizeMode:'contain'
  },
  counterItems:{
    justifyContent:'center',
    backgroundColor:'#ca2426',
    position:'absolute',
    alignItems:'center',
    zIndex:1,
  },

  //block styles
  blockTitle:{
    fontWeight:'bold', 
    color:'#000', 
    
  },
  itemsCountContainer:{
    flexDirection:'row', 
    alignItems:'center',
   
  },
  itemsText:{
    color:'#000', 
    fontSize:height*0.020
  },
  lineWithCount:{
    flex: 1, 
    height: height*0.0012, 
    backgroundColor: '#999DA3', 
    marginLeft:width*0.016,
    maxWidth:'28%', 
    marginTop:height*0.008
  },
  blockImageContainer:{
    justifyContent:'center',
    alignItems:'center',
    
  },
  blockImage:{
    resizeMode:'contain',
    
  },

  //Product Screen Styles
    productCategory:{
    color:'#000',
    fontWeight:'500',
    textAlign:'center'
  },
  productContainer:{
    borderColor:'#999DA3',
    // width:width*0.8,
    // marginLeft:width*0.02,
    // marginTop:height*0.016
  },
  skuText:{
    
    color:'#000000',
  
  },

  productImage:{
    justifyContent:'center',
    alignItems:'center',
   
    width:'100%'
  },
  rummoText:{
    fontSize:height*0.022, 
    color:'#999DA3',
    padding:height*0.006,
    marginTop:height*0.012
  },
  productName:{
    
    color:'#000',
    
    // marginTop:height*(-0.010),
    // minHeight:height*0.02,
  },

  priceContainer:{
    
    flexDirection:"row",
    alignItems:'center',
    borderColor:'#999DA3'
  },
  input:{

    textAlign:'center',
    padding:0,
    borderColor:'#999DA3',
    justifyContent:'center',
    backgroundColor:'#fff',
    color:'#000000',
  },
  productPrice:{
    textAlign:'right',
   
    color:'#000000'
  },
  addProduct:{
    backgroundColor:'#317250',
    
    justifyContent:'center',
    alignItems:'center',
   
  },
  shopByBrand:{
    backgroundColor:'#317250',
    padding:height*0.014,
    justifyContent:'center',
    alignItems:'center',
    marginTop:height*0.04
  },
  addProductText:{
   
    color:'#fff'
  },
  tasksIcon:{
    height:height*0.045,
    width:width*0.045,
    resizeMode:'contain',
    tintColor:'#999DA3'
  },
  wishListOuterContainer:{
    position:'absolute',
    width:'90%',
    backgroundColor:'#fff',
    borderWidth:0.6,
    borderColor:'#999DA3',

    zIndex:1,

  },
  wishListClose:{
   
    alignItems:'flex-end',
   
  },
  wishListCloseIcon:{
  
    resizeMode:'contain',
    tintColor:'#999DA3'
  },

  // Wishlist Screen Styles
  chooseList:{
    paddingLeft:height*0.020,
    paddingRight:height*0.020
  },
  chooseListText:{
    color:'#000',
    fontSize:height*0.030,
    fontWeight:'500',
    textAlign:'center'
  },
  createNewWishList:{
    color:'#4776f0',
    fontSize:height*0.022,
    fontWeight:'600'
  },
  addWishList:{
    paddingLeft:height*0.020,
    flexDirection:'row',
    marginBottom:height*0.020
  },
  newWishListName:{
    height: height*0.045,
    borderWidth: 0.5,
    borderColor:'#999DA3',
    width:width*0.620,
    padding:height*0.010,
    color:'#000'
  },
  addWishListBtn:{
    backgroundColor:'#d0d5e1',
    padding:height*0.010,
    borderRadius:height*0.004,
    marginLeft:width*0.030,
    width:width*0.14,
    height:height*0.045,
    justifyContent:'center'
  },
  addWishListBtnText:{
    color:'#fff',
    textAlign:'center'
  },
  wishListContainer:{
    padding:height*0.020,
    flexDirection:'row',
    justifyContent:'space-around'
  },
  wishListTitle:{
    backgroundColor:'#f9d484',
    height:height*0.160,
    width:width*0.340,
    justifyContent:'center'
  },
  wishListTitleText:{
    textAlign:'center',
    color:'#fff',
    fontSize:height*0.037
  },
  wishListName:{
    color:'#000',
    fontWeight:'500',
    marginTop:height*0.010
  },
  addToListBtn:{
    padding:height*0.022,
    backgroundColor:'#fff',
    borderRadius:height*0.004,
    borderTopColor:'#999DA3', 
    borderTopWidth:0.6,
        shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: height*0.002
    },
    shadowOpacity: 0.25,
    shadowRadius: height*0.004,
    elevation: height*0.008
  },
  

  //Filter Styles
  filterSortContainer:{
    width:'75%',
    flexDirection:'row',
  },
  filterContainer:{
    padding:height*0.010,
    borderWidth:height*0.001,
    height:height*0.060,
    borderColor:'#999DA3',   
    width:'50%',
    justifyContent:'center',
},
stickyText: {
  position: 'absolute',
  bottom: 0,
  left: 0,
  right: 0
},
  filterButtonContainerStyle:{
    resizeMode:'contain',
    width:'50%',
  },
  filterButtonText:{
    color:'#000',
    textTransform:'uppercase',
    fontWeight:'bold',
    textAlign:'center',
    
  },
  dropdownStyle:{
    backgroundColor:'red',
    
    borderColor:'#999DA3',
    borderRadius:0,
    justifyContent:'space-between',
  
    backgroundColor:'#f4f4f4',
  }, 
  dropdownContainerStyle:{
    backgroundColor:'red',
    borderRadius:0,
    borderColor:'#999DA3',
    backgroundColor:'#f4f4f4',
  },
  centeredView: {
    justifyContent: "center",
    alignItems: "center",
    
  },
  modalView: {
    width:'80%',
    margin: height*0.020,
    backgroundColor: "white",
    borderRadius: height*0.005,
    padding: height*0.055,

    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: height*0.002
    },
    shadowOpacity: 0.25,
    shadowRadius: height*0.004,
    elevation: height*0.005
  },
  button: {
    padding: height*0.010,
    elevation: height*0.002,
    borderRadius:height*0.005,
    marginTop:height*0.015
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center"
  },
  modalText: {
    color:'#000',
    textAlign: "left",
    fontWeight:'600',
    fontSize:height*0.020,
    marginTop:height*0.010,
  },
  filterModalContainer:{
    width:'120%',
  },
popupCheckbox:{
  flexDirection:'row',
  paddingVertical:height*0.002,
  alignItems:'center',
 
},
checkBoxText:{
  color:'#000000',
  marginLeft:width*0.005,
  fontSize:height*0.020
},

checkbox:{
  transform:[{scale:0.8}],
},
modalOpacity:{
 

},

//Cart Status Styles
popupContainer:{
  top:height*0.03,
  right:width*0.01,
  position:'absolute',
  width:'70%',
  backgroundColor:'#f9fbfd',
  alignSelf:'center',
  borderColor:'#999DA3',
  zIndex:1,
},
emptyCart:{
  fontSize:width<600?height*0.023:height*0.026,
  fontWeight:'600',
  color:'#000',
  textAlign:'center'
},
cartStatusContainer:{
  padding:height*0.024, 
  borderBottomWidth:0.3,
  borderBottomColor:'#999DA3', 
  flex:1,
  backgroundColor:'#f9fbfd',
  
},
yourBasketText:{
  color:'#000',
  fontWeight:'bold', 
  fontSize:height*0.028, 
  left:width*0.026
},
itemName:{
  fontSize:height*0.024,
  fontWeight:'400',
  color:'#000',
  width:'70%'
},
itemPrice:{
  fontSize:height*0.024,
  fontWeight:'400',
  color:'#000'
},
qtyContainer:{
  flexDirection:'row', 
  marginTop:height*0.010,
  width:'20%',
},
qtyText:{
  fontSize:height*0.024,
  fontWeight:'400',
  color:'#000',
  marginRight:'10%'
},
qtyUpdate:{
  borderWidth:0.5,
  justifyContent:'center',
  alignSelf:'center',
  borderRadius:height*0.004,
  marginLeft:width*0.010,
  padding:width*0.010,
  borderColor:'#999DA3',
},
qtyUpdateText:{
  fontSize:height*0.016,
  color:'#000',
},
itemSaperator:{
  borderBottomWidth:0.4,
  borderBottomColor:'#999DA3',
  width:width*0.690,
  marginTop:height*0.010
},
proceedCheckoutBtn:{
  backgroundColor:'#317250',
  padding:height*0.016,
  justifyContent:'center',
  alignItems:'center',
  borderRadius:height*0.008
},

//Product Page Styles
swiperContainer:{
  height:'18%',
  borderBottomWidth:0.4,
  borderBottomColor:'#999DA3',
},
swiperImage:{
  alignItems:'center',
  marginTop:height*0.040,
},
prodSaperator:{

  borderColor:'#999DA3',

},
detailsContainer:{
  borderBottomWidth:0.4,
  borderBottomColor:'#999DA3',
  padding:height*0.030,
  height:'14%',
},
prodSku:{
  color:'#000',
  fontSize:18,
  fontWeight:'bold',
  marginTop:15
},
prodPrice:{
  color:'#000',
  fontSize:height*0.034,
  fontWeight:'bold',
  marginTop:height*0.015
},
prodTitle:{
  color:'#000',
  fontSize:height*0.028,
  fontWeight:'bold',
  marginTop:height*0.015
},
prodQty:{
  flexDirection:'row',
  alignItems:'center',
  width:'30%',
  marginTop:height*0.015
},
prodQtyText:{
  fontSize:height*0.022,
  color:'#000'
},
prodQtyInput:{
  padding:'2%',
  width:'30%',
  borderWidth:1,
  textAlign:'center',
  marginLeft:width*0.040,
  color:'#000',
  fontSize:height*0.018
},
addToBasketCont:{
  justifyContent:'center',
  padding:height*0.010
},
addToBasket:{
  backgroundColor:'#317250',
  padding:height*0.018,
  justifyContent:'center',
  alignItems:'center',
  marginTop:height*0.010,
  borderRadius:height*0.008,
  width:'94%',
  alignSelf:'center'
},

addToBasketText:{
  color:'#fff',
  
},
accordinSaperator:{
  borderWidth:Platform.OS==='ios'?0.5:0.2,
  marginTop:50,
  borderColor:'#999DA3',
},
accordinTitle:{
  width:'100%',
  borderBottomWidth:0.4,
  borderBottomColor:'#999DA3',
  flexDirection:'row',
  justifyContent:'space-between'
},
accordinTitleText:{
 
  color:'#000'
},
downArrow:{
 
  tintColor:'#999DA3'
},
accordinInner:{
  width:'100%',
  
  borderBottomColor:'#999DA3'
},
accordinInnerText:{
  fontSize:height*0.022,
  color:'#000',
  textAlign:'justify',
  marginLeft:width*0.018
},
discountContainer:{
  padding:height*0.030,
},
frequentlyBought:{
  fontWeight:'bold',
  color:'#000',
  fontSize:height*0.022
},
saveAmount:{
  color:'#000',
  fontSize:height*0.020,
  marginTop:height*0.010
},
imagesContainer:{
  flexDirection:'row',
  marginTop:height*0.022,
  alignItems:'center',
  justifyContent:'center'
},
image:{
  width:width*0.290,
  height:height*0.140,
  resizeMode:'contain'
},
checkboxDetail:{
  color:'#000',
  left:width*0.010,
  fontSize:height*0.022,
},
totalPriceContainer:{
  marginBottom:40,  
  borderBottomWidth:0.4,
  borderBottomColor:'#999DA3'
},
totalPrice:{
  color:'#000',
  fontWeight:'bold',
  left:width*0.060,
  fontSize:height*0.022,
  marginBottom:30
},

  // LOGIN SCREEN STYLES
  loginContainer:{
    height:'100%',
   
  },
  textInputLable:{
   
    color:'#000'
  },
  titleText:{
    color:'#000',
    
    fontWeight:'500'
  },
  SecondtitleText:{
    color:'#000',
   
  },
  titlePara:{
    color:'#000',
   
  }
  ,
  textInput:{
    borderColor:'#999DA3',
    color:'#000'
  },
  textInputCode:{
    height: '7%',
    width:'95%',
    borderWidth: 0.5,
    padding: '2%',
    borderColor:'#999DA3',
    marginTop:'5%',
    color:'#000'
  },
  forgotPassword:{
    textAlign:'center',
    color:'#000'
  },
  showPassword:{
    color:'#000',

  },
  requiredFields:{
    color:'#e02b27',
    textAlign:'center',
   
  },
  createAnAccount:{
    backgroundColor:'#317250',
    padding:'6%',
    justifyContent:'center',
    alignItems:'center',
    // marginTop:height*0.040,
    marginBottom:'5%',
    width:'85%'
  },

  // Sign out Screen Styles
  signoutText:{
    color:'#000', 
    fontSize:height*0.036,
    fontWeight:'300'
  },
  signoutMessage:{
    paddingLeft:height*0.040,
    paddingRight:height*0.040
  },
  signoutMessageText:{
    color:'#000',
    fontSize:height*0.022,
    fontWeight:'300',
    lineHeight:height*0.026
  },

  // Forgot Password Screen
  forgotPasswordTitle:{
    paddingLeft:height*0.026,
    paddingRight:height*0.026,
    paddingTop:height*0.026,
    paddingBottom:height*0.016
  },
  forgotPasswordTitleText:{
    color:'#000',
    fontSize:height*0.032
  },
  entityContainer:{
    paddingLeft:height*0.026,
    paddingRight:height*0.026,
    paddingBottom:height*0.026
  },
  emailField:{
    paddingLeft:height*0.022,
    paddingRight:height*0.022,
    paddingBottom:height*0.022
  },


   //REGISTER SCREEN STYLES
   regTitle:{
    color:'#000',
    fontWeight:'400',
    fontSize:height*0.038,
    textAlign:'left',
    marginTop:height*0.026,
    left:width*0.050
  },
  regDesc:{
    color:'#000',
    fontSize:height*0.030, 
    fontWeight:'600',
    textAlign:'left',
    padding:height*0.028,
  },
  whyCreateText:{
    color:'#000',
    textAlign:'center',
    fontSize:height*0.034,
    fontWeight:'300',
  },
  uspContainer:{
    flexDirection:'row',
    marginTop:height*0.020,
    justifyContent:'center',
    left:width*0.018,
  },
  uspView:{
    width:width*0.280,
    height:height*0.130,
    backgroundColor:'#999da3',
    justifyContent:'center',
    marginRight:width*0.030
  },
  uspText:{
    color:'#fff',
    fontWeight:'bold',
    fontSize:height*0.022,
    textAlign:'center'
  },
  regInputLabel:{
    color:'#000',
    fontSize:height*0.018,
  },
  regInput:{
    height: height*0.060,
    width:width*0.405, 
    borderWidth: 0.5,
    borderColor:'#999DA3', 
    marginTop:height*0.012,
    marginRight:width*0.030,
    paddingLeft:height*0.01,
    color:'#000',
    fontSize:height*0.018
  },
  submitForm:{
    backgroundColor:'#317250',
    padding:height*0.014,
    justifyContent:'center',
    alignItems:'center',
  },
  submitFormText:{
    color:'#fff',
    fontSize:height*0.022
  },
  detailsView:{
    justifyContent:"center",
    padding:height*0.028
  },
  detailsText:{
    color:'#000', 
    fontSize:height*0.022
  },

    // Trade Account Styles
    tradeAccountTitle:{
      padding:'3%',
    },
    tradeAccountDesc:{
      padding:'10%',
    },
    tradeAccountDescText:{
      color:'#000',
     
    },
    tradeAccountDescConfirm:{
      color:'#000',
      paddingRight:'18%',
    },
    tradeAccountError:{
      color:'#e02b27',
    },

    //Cart Page Styles
    cartTitle:{
      color:'#000',
      fontSize:height*0.042
    },
    cartQuestion:{
      color:'#000',
      fontSize:height*0.028,
      fontWeight:'400',
      top:height*0.014
      },
    cartDesc:{
        color:'#333',
        fontSize:height*0.018,
        lineHeight:width*0.052
      },
    summaryButton:{
        backgroundColor:'#317250',
        padding:height*0.012,
        justifyContent:'center',
        alignItems:'center',
        width:width*0.40,
        top:height*0.0012
        },
    summaryButtonText:{
          color:'#fff',
          fontSize:height*0.020
        },
      summaryContainer:{
          backgroundColor:'#F7F7F7',
          },
      summaryTitle:{
          fontWeight:'500',
          color:'#000',
          fontSize:height*0.032
        },
      summarySaperator:{
          borderTopWidth:0.8,
          borderTopColor:'#000'
        },
      estimateContainer:{
          width:'100%',
          padding:height*0.010,
          borderBottomWidth:0.8,
          borderBottomColor:'#000',
          flexDirection:'row',
          justifyContent:'space-between'
        },
      estimateText:{
          fontSize:height*0.024,
          fontWeight:'bold',
          color:'#000'
          },
      estimateDownIcon:{
          width:width*0.030,
          height:height*0.018
        },
        estimateDesc:{
          color:'#333',
          fontSize:height*0.017
        },
        shippindAdress:{
          color:'#000',
          fontWeight:'600'
        },
        radioContainer:{
          flexDirection:'row',
        },
        radioOuter:{
          width:width*0.038,
          height:height*0.018,
          borderRadius:height*0.050,
          justifyContent:'center',
          alignItems:'center',
       },
       radioInner:{
        width:width*0.026,
        height:height*0.012,
        backgroundColor:'#000',
        borderRadius:height*0.050,
        alignSelf:'center'
        },
        fixedText:{
          color:'#000',
          left:width*0.012,
          marginTop:height*0.004
        },
        shippingPriceContainer:{
          flexDirection:'row',
          justifyContent:'space-between'
        },
        shippingPrice:{
          color:'#000',
          fontSize:height*0.024,
          marginTop:height*0.012
        },
        applyDiscount:{
          flexDirection:'row',
          justifyContent:'space-between',
          borderBottomWidth:0.8,
          // height:height*0.050
        },
        rewardAmount:{
          color:'#000',
          fontWeight:'bold',
          marginTop:height*0.010,
          fontSize:height*0.018
        },
        proceedCheckout:{
          color:'#fff',
          fontSize:height*0.024,
          fontWeight:'bold'
        },
        prodInfo:{
          color:'#000',
          fontWeight:'500',
          fontSize:height*0.026
        },
        priceInfo:{
          color:'#000',
          fontSize:height*0.026,
          left:width*0.10
        },
        iconsContainer:{
          flexDirection:'row',
          justifyContent:'flex-end',
        },
        updateIcon:{
          width:width*0.06,
          height:height*0.06,
          resizeMode:'contain',
        },
        continueShopping:{
          alignItems:'center',
          marginTop:height*0.020
        },
        backIcon:{
          width:width*0.04,
          height:height*0.020,
          resizeMode:'contain',
          marginRight:'2%',
        },

      //Basket Styles that appears on Cart Page
      basketContainer:{
        padding:height*0.026,
        borderTopColor:'#999DA3', 
        flex:1,
        shadowOffset: {
          width: 0,
          height: height*0.002
        },
        shadowOpacity: 0.25,
        shadowRadius: height*0.004,
        elevation: height*0.003    
      },
      basketTotal:{
        flexDirection:'row',
        marginBottom:height*0.012
      },
      basketIcon:{
        width:width*0.060,
        height:height*0.035,
        resizeMode:'contain'
      },
      basketTotalText:{
        color:'#000',
        fontWeight:'bold', 
        fontSize:height*0.024, 
        left:width*0.026, 
        marginTop:height*0.004
      },
      basketTotalPrice:{
        fontSize:height*0.030,
        fontWeight:'bold',
        color:'#000',
        left:width*0.090
      },
      totalItems:{
        flexDirection:'row', 
        justifyContent:'space-between'
      },
      totalItemsQuantity:{
        flexDirection:'row',
        marginTop:height*0.018
      },
      totalItemsText:{
        fontSize:height*0.022,
        fontWeight:'400',
        color:'#000'
      },

      //Our Brands Page styles
      ourBrands:{
        padding:height*0.022,
        alignItems:'center'
      },
      ourBrandsText:{
        color:'#000',
        fontSize:height*0.028,
        fontWeight:'700'
      },
      ourBrandsDesc:{
        paddingLeft:height*0.022,
        paddingBottom:height*0.022
      },
      ourBrandsDescText:{
        color:'#000',
        fontSize:height*0.024,
        fontWeight:'600',
        lineHeight:height*0.032
      },
      brandsContainer:{
        paddingLeft:height*0.022,
        paddingRight:height*0.022,
        paddingBottom:height*0.022,
        flexDirection:'row',
        justifyContent:'space-around'
      },
      brandBox:{
        borderWidth:0.4,
        borderColor:'#999DA3',
        width:'45%',
        borderRadius:height*0.004,
        alignItems:'center',
        padding:height*0.022
      },
      brandImgContainer:{
        marginTop:height*0.020,
        alignItems:'center'
      },
      brandLogoImg:{
        resizeMode:'contain',
        width:width*0.390,
        height:height*0.130
      },
      brandName:{
        width:'100%',
        marginTop:height*0.020
      },
      brandNameText:{
        color:'#000',
        fontSize:height*0.022,
        fontWeight:'700'
      },
      shopBrandBtn:{
        backgroundColor:'#317250',
        padding:height*0.014,
        marginTop:height*0.010
      },

      //Brands Pages Styles
      brandImgBox:{
        padding:height*0.024,
        alignItems:'center'
      },
      brandImg:{
        resizeMode:'contain',
        width:width*0.590,
        height:height*0.240
      },
      brandDescBox:{
        paddingLeft:height*0.020,
        paddingRight:height*0.020,
        paddingBottom:height*0.020,
        // alignItems:'center'
      },
      brandDescBold:{
        color:'#000',
        fontWeight:'300',
        textAlign:'center',
        fontSize:height*0.022,
        lineHeight:height*0.034
      },
      brandDesc:{
        textAlign:'left',
        fontSize:height*0.022,
        marginTop:height*0.010,
        color:'#000'
      },

      // ShopBrand Screen Styles
      brandTitle:{
        textAlign:'center',
        color:'#000', 
        fontSize:height*0.032,
        fontWeight:'600'
      },


      // Blogs Page Styles
      blogHeading:{
        padding:height*0.026,
        flexDirection:'row',
        justifyContent:'space-between'
      },
      blogHeadingText:{
        color:'#000',
        fontWeight:'600',
        fontSize:height*0.046
      },
      blogMenuContainer:{
        width:width*0.80,
        backgroundColor:'#fafafa',
        position:'absolute',
        right:width*0,
        zIndex:1,
        paddingBottom:height*0.030
      },
      blogMenuTitle:{
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:'center',
      },
      blogMenuTitleText:{
        color:'#000',
        fontSize:height*0.032,
        // marginLeft:width*0.030
      },
      blogMenuCloseIcon:{
        width:width*0.050,
        height:height*0.060,
        resizeMode:'contain',
        tintColor:'#999DA3'
      },
      blogArticle:{
        borderWidth:0.5,
        borderColor:'#999DA3',
        borderBottomLeftRadius:width*0.02,
        borderBottomRightRadius:width*0.02,
        marginLeft:width*0.025,
        marginRight:width*0.025,
        marginTop:height*0.025,
        elevation:5
      },
      blogArticleImg:{
        justifyContent:'center',
        resizeMode:'cover'
      },
      blogDetailsContainer:{
        backgroundColor:'#fff',
        borderBottomRightRadius:width*0.010,
        borderBottomLeftRadius:height*0.010
      },
      blogPublishDate:{
        flexDirection:'row',
        marginTop:height*0.020
      },
      blogPublishDateText:{
        marginRight:width*0.10,
        color:'#999'
      },
      blogArticleTitle:{
        marginTop:height*0.020,
        fontSize:height*0.030,
        color:'#000'
      },
      blogArticlePara:{
        marginTop:height*0.010,
        fontSize:height*0.018,
        color:'#333',
        lineHeight:height*0.028
      },
      blogArticlePosted:{
        marginTop:height*0.020,
        flexDirection:'row'
      },
      blogArticlePostedIn:{
        fontSize:height*0.020,
        color:'#000'
      },
      blogArticleCategoty:{
        fontSize:height*0.020,
        color:'#000',
        fontWeight:'500'
      },
      readMoreBtn:{
        backgroundColor:'#317250',
        padding:height*0.018,
        justifyContent:'center',
        alignItems:'center',
        marginTop:height*0.010,
        width:'100%',
        alignSelf:'center'      
      },
      readMoreBtnText:{
        color:'#fff',
        fontSize:height*0.022      
      },

      // Blog Menu Styles
      blogMenuItemContainer:{
        borderWidth:0.2,
        borderRadius:height*0.003,
        borderColor:'#999DA3',
        marginTop:height*0.040
      },
      blogMenuSearchBox:{
        height:'100%',
        width:'85%',
        marginLeft:width*0.010,
        color:'#000'
      },
      blogMenuSearchIcon:{
        width:width*0.050,
        height:height*0.045,
        resizeMode:'contain',
        tintColor:'#999DA3',
        marginRight:width*0.030
      },
      blogMenuTag:{
        padding:height*0.010,
        backgroundColor:'#f5f5f5',
        borderRadius:height*0.020
      },
      blogMenuPostImg:{
        height:height*0.070,
        width:'20%',
        resizeMode:'cover',
      },
      blogMenuPostTitle:{
        marginTop:height*0.020,
        marginLeft:height*0.010
      },
      blogMenuPostViews:{
        color:'#999DA3',
        marginTop:height*0.020,
        marginLeft:height*0.010
      },

      // Blog Details Screen Styles
      ingredientText:{
        fontSize:height*0.018,
        color:'#333'
      },
      socialIcons:{
        marginTop:height*0.040,
        flexDirection:'row'
      },
      socialIconsImg:{
        resizeMode:'contain',
        marginRight:width*0.030
      },

      // Checkout Page Styles
      checkoutTitle:{
        color:'#000',
        fontSize:height*0.040
      },
      estimatedTotal:{
        borderWidth:0.8,
        height:height*0.120,
        padding:height*0.028,
        borderColor:'#ccc',
        backgroundColor:'#F7F7F7'
      },
      estimatedTotalText:{
        color:'#000', 
        fontSize:height*0.026,
        marginBottom:height*0.006
      },
      titleBox:{
        padding:height*0.016,
        backgroundColor:'#999da3'
      },
      titleBoxText:{
        color:'#fff',
        fontWeight:'bold',
        fontSize:height*0.020
      },
      shippingAddress:{
        color:'#000',
        fontSize:height*0.022,
        marginBottom:height*0.005
      },
      newAddress:{
        backgroundColor:'#317250',
        padding:height*0.010,
        marginTop:height*0.022,
        width:'40%',
        alignItems:'center'
      },
      shippingMethod:{
        backgroundColor:'#f9f9f9',
        justifyContent:'center',
        marginTop:height*0.020
      },
      shippingMethodPrice:{
        color:'#000',
        marginLeft:width*0.030,
        marginTop:height*0.002,
        fontSize:height*0.020
      },
      chooseDate:{
        color:'#000',
        fontWeight:'bold',
        fontSize:height*0.020
      },
      chooseDateClickable:{
        marginTop:height*0.005,
        width:width*0.760
      },
      availableChoices:{
        borderWidth:0.5,
        padding:height*0.016
      },
      availableChoicesText:{
        color:'#000',
        fontSize:height*0.020
      },
      calenderIconContainer:{
        marginTop:height*0.016,
        marginLeft:width*0.040
      },
      calenderIcon:{
        width:width*0.090,
        height:height*0.040,
        resizeMode:'contain'
      },
      calenderView:{
        width:width*0.800,
        height:height*0.002,
        zIndex:1,
      },
      orderSummary:{
        paddingLeft:height*0.020,
        paddingRight:height*0.020,
        paddingBottom:height*0.020
      },
      cartItems:{
        width:'100%',
        padding:height*0.018,
        borderBottomWidth:0.2
      },
      rewardPointsDesc:{
        borderWidth:0.4,
        marginTop:height*0.020,
        padding:height*0.018,
        backgroundColor:'#F7F7F7'
      },
      rewardPointsDescText:{
        color:'#000', 
        fontSize:height*0.020
      },
      itemsInCartText:{
        color:'#000',
        fontSize:height*0.020
      },
      itemDetails:{
        marginRight:width*0.210,
        marginTop:height*0.008
      },
      itemDetailsText:{
        color:'#000',
        marginLeft:width*0.05,
      fontSize:height*0.020,
    },
    itemPrice:{
      color:'#000',
      fontSize:height*0.020,
      marginTop:height*0.026,
      fontWeight:'500'
    },
    priceDetails:{
      padding:height*0.010,
      marginTop:height*0.008
    },
    subTotalPrice:{
      flexDirection:'row',
      justifyContent:'space-between'
    },
    shippingTotal:{
      flexDirection:'row',
      justifyContent:'space-between',
      marginTop:height*0.012
    },
    orderSubtotal:{
      flexDirection:'row',
      justifyContent:'space-between',
      borderTopWidth:0.2,
      marginTop:height*0.020
    },
    applyDiscountBox:{
      borderWidth:0.4,
      padding:height*0.018
    },
    applyDiscountText:{
      color:'#000',
      fontSize:height*0.020
    },
    // My Account Page Styles
    myAccountTitle:{
      color:"#000", 
      fontSize:height*0.030,
      fontWeight:'600'
    },
    myAccountGreeting:{
      color:'#000',
      fontSize:height*0.022,
      fontWeight:'500'
    },
    myAccountDropdown:{
      width:'100%',
      padding:height*0.018,
      borderWidth:0.4,
      borderColor:'#999DA3',
      flexDirection:'row',
      justifyContent:'space-between'
    },
    myAccountMenuText:{
      color:'#000', 
      fontSize:height*0.020,
      paddingLeft:width*0.024
    }
    ,
    myAccountSaperatorLine:{
      borderBottomWidth:0.4,
      borderBottomColor:'#000',
    },
    headingTitle:{
      color:'#000',
      fontSize:height*0.024,
      fontWeight:'500'
    },
    otherOptions:{
    
      color:'#000',
    },
    addressBook:{
      flexDirection:'row',
      justifyContent:'space-between'
    },
    addressBookText:{
      color:'#000', 
      fontSize:height*0.026
    },
    promoBanner:{
      backgroundColor:'#999da3',
      padding:height*0.028, 
      alignSelf:'center'
    },
    promoBannerText:{
      fontSize:height*0.028,
      color:'#000',
      fontWeight:'500'
    },

    // Edit Account Information Screen
    accountInputField:{
    
    },
    questionIcon:{
      width:width*0.055,
      height:height*0.040,
      resizeMode:'contain'
    },
    tooltipText:{
      backgroundColor:'#f5f5f5',
      padding:height*0.014,
      width:width*0.730,
      marginTop:height*0.12,
      marginLeft:width*0.10,
      borderWidth:0.5,
      zIndex:1
    },
    saveBtnBox:{
      marginTop:height*0.020,
      marginBottom:height*0.020,
      alignItems:'center'
    },
    saveBtn:{
      backgroundColor:'#317250',
      padding:height*0.012,
      justifyContent:'center',
      alignItems:'center',
      width:width*0.910
    },
    saveBtnText:{
      color:'#fff',
      textAlign:'center',
      fontSize:height*0.022
    },
    defaultShipping:{
      flexDirection:'row',
      alignItems:'center',
      
      backgroundColor:'#fdf0d5'
    },
    dangerIcon:{
      resizeMode:'contain'
    },
    usuallyBought:{
      marginTop:height*0.020,
      flexDirection:'row',
      justifyContent:'space-between',
      alignItems:'center'
    },
    usuallyBoughtText:{
      color:'#000',
      fontSize:height*0.028,
      fontWeight:'600'
    },
    seeAll:{
      color:'#999da3',
      fontSize:height*0.024,
      marginRight:width*0.026
    },
    nextArrowIcon:{
      width:width*0.040,
      height:height*0.030,
      resizeMode:'contain',
      tintColor:'#999da3'
    },
    shopBrandBox:{
      borderWidth:0.4,
      borderColor:'#999DA3',
      borderRadius:height*0.008,
      marginTop:height*0.020
    },
    brandBannerImg:{
      resizeMode:'cover',
      width:'100%',
      height:height*0.210,
      borderTopRightRadius:height*0.008,
      borderTopLeftRadius:height*0.008
    },
    percentOffText:{
      color:'#ca2426',
      fontSize:height*0.042,
      fontWeight:'700'
    },
    offDateText:{
      color:'#999da3',
      fontSize:height*0.026,
      fontWeight:'500'
    },
    shopNow:{
      padding:height*0.014,
      backgroundColor:'#ca2426',
      width:width*0.430,
      borderRadius:height*0.008,
      marginBottom:height*0.030
    },
    shopNowText:{
      color:'#fff',
      textAlign:'center',
      fontWeight:'500'
    },

    // Previous Orders Screen
    orderNumber:{
      flexDirection:'row',
      marginBottom:height*0.008
    },
    orderDetail:{
      fontSize:height*0.022,
      color:'#000'
    },

    // View Order
    orderStatus:{
      borderWidth:0.4,
      padding:height*0.006,
      width:width*0.40
    },
    orderStatusText:{
      color:'#000',
      fontSize:height*0.026,
      textAlign:'center'
    },
    orderDate:{
      color:"#000", 
      fontSize:height*0.020,
      marginTop:height*0.012
    },
    orderOptions:{
      flexDirection:'row',
      marginTop:height*0.008
    },
    orderDetailsOptions:{
      backgroundColor:'#e5e5e5',
      padding:height*0.020,
      borderWidth:0.4
    },
    orderDetailsContainer:{
      padding:height*0.022,
      borderWidth:0.4
    },
    ordersText:{
      fontSize:height*0.020,
      color:'#000',
      marginTop:height*0.010
    },
    orderPriceDetail:{
      backgroundColor:'#e5e5e5',
      marginTop:height*0.016
    },
    orderPriceTotal:{
      flexDirection:"row",
      justifyContent:'space-between',
      padding:height*0.010
    },
    creditCardContainer:{
      marginTop:height*0.014,
      marginBottom:height*0.022
    },
    creditCard:{
      flexDirection:'row',
      marginRight:height*0.22,
      justifyContent:'space-between',
      marginBottom:height*0.016
    },
    
    // Saved Lists Screen
    savedListContainer:{
      padding:height*0.022,
      flexDirection:'row',
      justifyContent:'space-between'
    },
    savedListTitle:{
      color:'#000',
      fontSize:height*0.030,
      fontWeight:'600'
    },
    createNewList:{
      color:'#000',
      fontSize:height*0.026,
      textDecorationLine:'underline'
    },
    newList:{
      flexDirection:'row',
      justifyContent:'flex-end',
      marginRight:width*0.040
    },
    newListInput:{
      borderWidth:0.4,
      width:width*0.500,
      padding:height*0.005,
      color:'#000'
    },
    addList:{
      backgroundColor:'#317250',
      padding:height*0.012,
      marginLeft:width*0.010,
      width:width*0.16
    },
    addListText:{
      color:'#fff',
      textAlign:'center'
    },
    savedListText:{
      color:'#000',
      fontSize:height*0.022
    },
    savedListSaperatorLine:{
      borderBottomWidth:1,
      borderBottomColor:'#000',
      width:width*0.900,
      alignSelf:'center'
    },

    // View List Screen
    backBtn:{
      flexDirection:'row',
      alignItems:'center'
    },
    backBtnIcon:{
      width:width*0.030,
      height:height*0.020,
      resizeMode:'contain',
      tintColor:'#999DA3'
    },
    listName:{
      color:'#000',
      fontSize:height*0.030,
      fontWeight:'700',
      width:width*0.66,
      // width:'240%'
    },
    penIcon:{
      width:width*0.040,
      height:height*0.030,
      resizeMode:'contain'
    },
    listOptionIcon:{
      width:width*0.040,
      height:height*0.045,
      resizeMode:'contain'
    },
    listOptions:{
      color:'#000',
      fontSize:height*0.020,
      marginLeft:width*0.006
    },
    addNewProduct:{
      color:'#000',
      fontSize:height*0.022
    },
    searchProduct:{
      borderWidth:0.5,
      flexDirection:'row',
      height:height*0.050
    },
    searchProductInput:{
      width:'90%',
      marginLeft:width*0.020,
      color:'#000'
    },
    searchIcon:{
      width:width*0.050,
      height:height*0.045,
      resizeMode:'contain',
      tintColor:'#999DA3',
      marginLeft:width*0.030
    },

    // Share List Screen Styles
    inputText:{
      color:'#000',
      fontSize:height*0.020
    },
    inputTextField:{
      borderWidth: 0.5, 
      borderColor:'#999DA3',
      marginTop:height*0.020,
      color:'#000'
    },

    // Reward Points Screen
    myRewardsPara:{
      color:'#000',
      fontSize:height*0.022,
      fontWeight:'500',
      lineHeight:height*0.028
    },
    rewardQuantity:{
      fontSize:height*0.048,
      color:'#000',
      fontWeight:'500'
    },

    // Help Screen Styles
    helpTitleQuestion:{
      color:'#000',
      fontSize:height*0.030,
      fontWeight:'600'
    },
    helpQuestion:{
      color:'#000',
      fontSize:height*0.024,
      textDecorationLine:'underline'
    },

    // Community Screen Styles
    moreProducts:{
      padding:height*0.010,
      backgroundColor:'#999da3',
      marginTop:height*0.020,
      marginBottom:height*0.030
    },
    moreProductsTxt:{
      color:'#000',
      textAlign:'center'
    },

    // Delivery Page Styles
    deliveryTitle:{
      color:'#000',
      fontWeight:'600',
      fontSize:height*0.030,
      textAlign:'center'
    },
    deliveryTextContainer:{
      paddingLeft:height*0.022,
      paddingRight:height*0.022
    },
    deliveryTextPara:{
      color:'#000',
      fontSize:height*0.020
    },
    menuHeading:{
      padding:height*0.022,
      flexDirection:'row',
      justifyContent:'space-between'
    },
    menuSaperatorLine:{
      borderTopWidth:0.9,
      width:width*0.900,
      alignSelf:'center'
    },

    // Pagination Styles
    paginationContainer:{
      flexDirection:'row',
    },
    pageNumber:{

      justifyContent:'center',
    },
    // Widgets styles
    widgetTitle:{
    
      color:'#000',
      textAlign:'center',
   
      fontWeight:'500'
    },
    // Error Message
    serverError:{
      color:'#e02b27',
      fontSize:height*0.020,
      marginVertical:height*0.020,
      textAlign:'left',
      fontWeight:'600'
    },
    //table styles

tablerow: { height: height*0.050,padding:height*0.010,borderWidth:height*0.001},
tabletext: { textAlign: 'center',color:'#000'}
});


