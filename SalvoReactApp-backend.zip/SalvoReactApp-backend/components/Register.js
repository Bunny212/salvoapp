import React, { useEffect, useRef, useState } from "react";
import { View, Text, TouchableOpacity, Dimensions,TextInput, ScrollView,ActivityIndicator, BackHandler,Keyboard, Image } from "react-native";
import styles from "../styles/styles";
import Header from "./Header";
import Cart from "./CartStatus";
import CheckBox from '@react-native-community/checkbox';
import DropDownPicker from 'react-native-dropdown-picker';
import { gql, useMutation, useQuery } from "@apollo/client";
import { REGISTER_CUSTOMER } from "./mutations/registerCustomer";
import { LOGIN_CUSTOMER } from "./mutations/loginCustomer";
import { useDispatch, useSelector } from "react-redux";
import { customerToken, setStoreView } from "./redux/actions";
import { COUNTRIES } from "./query/countriesList";
import { CUSTOMER_ADDRESS } from "./mutations/createCustomerAddress";
import { CountryCodeEnum } from "./mutations/countryCode";
import { SET_STORE_VIEW } from "./mutations/setStoreView";
import { SIGN_OUT } from "./mutations/signOut";
const { width, height } = Dimensions.get('window');
const Register = ({navigation,route}) => {
    const dispatch=useDispatch ();
    const [toggleCheckBox, setToggleCheckBox] = useState(false);
    const [fname, setFname] = useState('');
    const [lname, setLname] = useState('');
    const [company, setCompany] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [street, setStreet] = useState('');
    const [street2, setStreet2] = useState('');
    const [city, setCity] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [matchPassword, setMatchPassword] = useState('');
    const [postCode, setPostCode] = useState('');

    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(0);
    // const [industry, setIndustory] = useState([
    //     {label: 'Other', value: 'other'},
    // ]);
    const industry=[];
    const hear_about_salvo=[];
    const [open1, setOpen1] = useState(false);
    const [value1, setValue1] = useState(0);
    // const [source, setSource] = useState([
    //     {label: 'Google', value: 'google'},
    //     {label: 'Magazine Advert', value: 'magazine advert'},
    //     {label: 'Previous employement', value: 'previous employment'},
    //     {label: 'Social Media', value: 'social media'},
    //     {label: 'Vehicle signage', value: 'vehicle signage'},
    //     {label: 'Word of mouth', value: 'word of mouth'},

    // ]);
    const [open2, setOpen2] = useState(false);
    const [value2, setValue2] = useState(null);

    const [open3, setOpen3] = useState(false);
    const [value3, setValue3] = useState(null);
    const [countyName, setCountyName]=useState('');

    const county=[];

    const [fnameMessage,setFnameMessage]=useState("");
    const [lnameMessage,setLnameMessage]=useState("");
    const [emailMessage,setEmailMessage]=useState("");
    const [phoneMessage,setPhoneMessage]=useState("");
    const [streetMessage, setStreetMessage]=useState("");
    const [cityMessage, setCityMessage] = useState("");
    const [countyMessage, setCountyMessage] = useState("");
    const [countryMessage, setCountryMessage] = useState("");
    const [passwordMessage,setPasswordMessage]=useState("");
    const [confirmPasswordMessage,setConfirmPasswordMessage]=useState("");
    const [matchPasswordMessage, setMatchPasswordMessage]=useState("");
    const [postCodeMessage,setPostCodeMessage]=useState("");
    const [error,setError]=useState('');
    const [regionId,setRegionId]=useState(0);
    const [regionName,setRegionName]=useState('');
    const [regionCode,setRegionCode]=useState('');
    const [errorsMsg, setErrorsMsg] = useState({});
    const NAVISION_RESPONSE=useSelector(state=>state.navisionResponse);
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const [displayMessage,setDisplayMessage]=useState(false);
    const [isKeyboardVisibleHeight, setKeyboardVisibleHeight] = useState('100%');
    const newErrors = {};
    const getStoreCode=(data)=>{
        console.log('Navision ',NAVISION_RESPONSE.store_code)
       
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        console.log('My Data::::::::::::::::',errors);
        console.log('My Data::::::::::::::::',data);
        console.log('My Store View::::::::::::::::',data?.RegisterSuccess.created_in);
         if(data?.RegisterSuccess.created_in=='london_storeview'){
            dispatch(setStoreView(data?.RegisterSuccess.created_in));
         }else if(data?.RegisterSuccess.created_in=='manchester_storeview'){
            dispatch(setStoreView(data?.RegisterSuccess.created_in));
         }
    }
    const scrollViewRef = useRef(null);

    const validate=()=>{
     
        if(!fname){
            // setFnameMessage("This is a required field.");
            newErrors.fname = "This is a required field";
        }
        if(!lname){
            newErrors.lname = "This is a required field";
        }
        if(!email){
            newErrors.email = "This is a required field";
        }else if (!/\S+@\S+\.\S+/.test(email)) {
            newErrors.email = 'Invalid email address';
        }
        if(!phone){
            newErrors.phone = "This is a required field";
        }
        if(!street && !street2){
            newErrors.street = "This is a required field";
        }
        if(!city){
            newErrors.city = "This is a required field";
        }
        if(county.length!=0){
            if(!value3){
                newErrors.value3 = "This is a required field";
            }else{
                newErrors.value3 = "";
            }
        }
        if(!value2){
            newErrors.value2 = "This is a required field";
        }
        if(!password){
            newErrors.password = "This is a required field";
        }else if (password.length < 8) {
            newErrors.password = 'Password must be at least 8 characters';
        }
        if(!confirmPassword){
            newErrors.confirmPassword = 'This is a required field';
        }
        if (password !== confirmPassword) {
            newErrors.confirmPassword = "Please enter the same value again.";
        }
        if(!postCode){
            newErrors.postCode = "This is a required field";
        }else{
            if(password==confirmPassword){
                register(fname,lname,email,confirmPassword,value,NAVISION_RESPONSE.stock_location,NAVISION_RESPONSE.minimum_order_value,value1,'["'+NAVISION_RESPONSE.delivery_days.toString()+'"]',String(NAVISION_RESPONSE.delivery_schedule_code));
            }
        }
        setErrorsMsg(newErrors);
       
        scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });
        return Object.keys(newErrors).length === 0;    
    }
    const country=[];
function getCountries(){
    const { loading, error, data } = useQuery(COUNTRIES);
if (loading) return <ActivityIndicator></ActivityIndicator>;
if(data!=undefined){
{data.countries.map((name)=>{
    country.push({label: name.full_name_english, value: name.id});
})}
}
}
getCountries();



function getRegion(value2){
    const REGION=gql`{
        country(id: "${value2}") {
          available_regions {
            code
            id
            name
          }
          full_name_english
          full_name_locale
          id
          three_letter_abbreviation
          two_letter_abbreviation
        }
      }`;
      const { loading, error, data } = useQuery(REGION);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if(data!=undefined){
         data.country.available_regions?.map((region)=>{
            county.push({label:region.name,value:region.id,code:region.code});
         })
    }
}
getRegion(value2);

function getSelectedRegionId(value3){
    county.map((regionName)=>{
        console.log(value3);
        if(regionName.value==value3.value){
            setRegionCode(regionName.code);
            setRegionId(regionName.value); 
            setRegionName(regionName.label);
        }
    })
}
function RegisterSuccess () {
    return(
        <>
        <View style={{width:'100%'}}>
            <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
                <Image source={require('../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
                <View style={{marginHorizontal:width*0.020}}>
                <Text style={{color:'#006400',fontSize:height*0.018}}> 
                    Thank you for registering.
                </Text>
                </View>
            </View>
        </View>
        </>
    )
}
// console.log('["'+NAVISION_RESPONSE.delivery_days.toString()+'"]');
    const [createCustomer]=useMutation(REGISTER_CUSTOMER);
 const register =async(firstname,lastname,email,password,industry,stock_location,minimum_order_amount,how_did_you_hear,shipment_days,delivery_schedule)=>{
    console.log(firstname)
    console.log(lastname)
    console.log(email)
    console.log(password)
    console.log(industry)
    console.log(stock_location)
    console.log(minimum_order_amount);
    console.log(how_did_you_hear);
    console.log(shipment_days);
    console.log(NAVISION_RESPONSE)
    try{   
        const{
          data,errors,
        }= await createCustomer({
            variables:{
                firstname,
                lastname,
                email,
                confirmPassword,
                industry,
                stock_location,
                minimum_order_amount,
                how_did_you_hear,
                shipment_days,
                delivery_schedule
            }
        });
        // navigation.navigate("Default");
        
        if(data.createCustomer.length!=0){
            loginCustomer(email,password);
            setDisplayMessage(true);
            setTimeout(() => {
              setDisplayMessage(false);
            }, 10000);
            SignOut();
            setTimeout(async function(){      
                loginCustomer(email,password);
            },3000);

                
        }
        
        
        else {
            console.log('customerrrr 12345',data)
        }
        // dispatch(customerToken(data.generateCustomerToken.token));
        
      }catch(error){
        if(Object.keys(newErrors).length==0){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
        }
      }
 }
 const [setWebsite]=useMutation(SET_STORE_VIEW);
 const createStoreView=async(customerEmail)=>{
  try{
    const{
      data,errors,
    }=await setWebsite({
      variables:{
        customerEmail
      }
    });
    console.log('Created:::::::::::::::::',data);
  }catch(error){
    console.log(error);
    setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message); 
  }
 }
 const [signOut]=useMutation(SIGN_OUT);
 const SignOut=async()=>{
    try{
        const{
          data,errors,
        }=await signOut();
        console.log('Created:::::::::::::::::',data);
      }catch(error){
        console.log(error);
        setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message); 
      }
 }
 
 const [generateCustomerToken]=useMutation(LOGIN_CUSTOMER);
 const loginCustomer = async(email,password)=>{
    try{   
        const{
          data,errors,
        }= await generateCustomerToken({
            variables:{
                email,
                password
            }
        });
        
        if(data.generateCustomerToken.token!=null){
            dispatch(customerToken(data.generateCustomerToken.token));
            setCustomerAddress(regionName,regionCode,regionId,value2,street+" "+street2,city,postCode,phone,fname,lname,company)
            createStoreView(email)
            navigation.navigate("DrawerNavigation",{
                screen:"Default",params:{regionName:regionName,regionCode:regionCode,regionId:regionId,country_code:value2,street:street+" "+street2,city:city,postcode:postCode,phone:phone,firstname:fname,lastname:lname,company:company}
            });
            // if(value3!=null){        
            
            // }else{
            //     setCustomerAddress("","",0,value2,street+" "+street2,city,postCode,phone,fname,lname,company)
            // }
        }
        //set Customer Address
      }catch(error){
        console.log(error);
        setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message); 
      }
}

const [SetCustomerAddress]=useMutation(CUSTOMER_ADDRESS);
const setCustomerAddress=async(region,
  region_code,
  region_id,
  country_code,
  street,
  city,
  postcode,
  telephone,
  firstname,
  lastname,
  company
  )=>{
      console.log(region);
      console.log(region_code);
      console.log(region_id);
      console.log(country_code);
      console.log(street);
      console.log(city);
      console.log(postcode);
      console.log(telephone);
      console.log(firstname);
      console.log(lastname);
      console.log(company);
  try{   
      const{
        data,errors,
      }= await SetCustomerAddress({
          variables:{
              region,
              region_code,
              region_id,
              country_code,
              street,
              city,
              postcode,
              telephone,
              firstname,
              lastname,
              company
          }
      });
      console.log('Address Response:::::::::::::::::::',data);
      
      //set Customer Address
    }catch(error){
      console.log('::::::::::::::::::::',error);
      setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message); 
    }
  }
const getIndustry=()=>{
        const INDUSTRY=gql`
        query {
            CustomerAttibuteLabelsAndValues(attribute_code: "industry") {
            valueAndLabelList{
                value
                label
            }
            }
        }`;
        const {data,errors,loading}=useQuery(INDUSTRY);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if(data!=undefined){
    data.CustomerAttibuteLabelsAndValues?.valueAndLabelList.map((industryAttr)=>{
        industry.push({label:industryAttr.label,value:industryAttr.value});
    });
}
}
getIndustry();
const getHearAboutSalvo=()=>{
    const HEAR_ABOUT_SALVO=gql`
    query {
        CustomerAttibuteLabelsAndValues(attribute_code: "how_did_you_hear") {
        valueAndLabelList{
            value
            label
        }
        }
    }`;
    const {data,errors,loading}=useQuery(HEAR_ABOUT_SALVO);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if(data!=undefined){
data.CustomerAttibuteLabelsAndValues?.valueAndLabelList.map((hearAttr)=>{
    hear_about_salvo.push({label:hearAttr.label,value:hearAttr.value});
});
    }
}
getHearAboutSalvo();
console.log(NAVISION_RESPONSE);
const STORE_VIEW=gql`
query{
    RegisterSuccess(website_customer_relate_to:"${NAVISION_RESPONSE.store_code}"){
        store_id
        website_id
        created_in
      }
    }`;
const {data,errors,loading}=useQuery(STORE_VIEW);
console.log('Register::::::::::::::::::',data);
function handleBackButtonClick() {
    navigation.navigate('DrawerNavigation',{screen:'Login'});
    return true;
  }
  useEffect(() => {
    // {console.log('Industry Value:::::::::::::::',route.params.postcode)}
    setPostCode(route.params.postcode);
    BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
    return () => {
      BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
    };
    
  }, []);


  if (displayServerError) {
    setTimeout(() => {
      setDisplayServerErrorMsg(false);
    }, 12000);
  }
  const keyboardDidShowListener=Keyboard.addListener(
    'keyboardDidShow',
    () => {
      setKeyboardVisibleHeight('60%'); // or some other action
    }
  );
  const keyboardDidHideListener =Keyboard.addListener(
    'keyboardDidHide',
    () => {
      setKeyboardVisibleHeight('100%'); // or some other action
    }
  );
keyboardDidHideListener;
keyboardDidShowListener;        

return(
        <View style={{height:Platform.OS==='ios'?isKeyboardVisibleHeight:'100%'}}>
        <ScrollView ref={scrollViewRef} style={{flex:1,backgroundColor:'#fff'}} keyboardShouldPersistTaps={'handled'}>
            <View>
            <Text style={styles.regTitle}>Create a Trade Account</Text>
            {displayMessage? <View><RegisterSuccess/></View> : <View></View>}

            {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}
            {/* Server errors */}
            <Text style={styles.regDesc}>
                Salvo1968 is for B2B trade only. If you are a restaurant, catering company, retailer, 
                delicatessen or other food-related business with a company Registration number please 
                proceed with the form below.
            </Text>

            <View style={{}}>
                <Text style={styles.whyCreateText}>Why Create an Account</Text>
                <View style={styles.uspContainer}>
                    <View style={styles.uspView}>
                        <Text style={styles.uspText}>USP</Text>
                    </View>
                    <View style={styles.uspView}>
                        <Text style={styles.uspText}>USP</Text>
                    </View>
                    <View style={styles.uspView}>
                        <Text style={styles.uspText}>USP</Text>
                    </View>
                </View>
            </View>

            <View>
                <View style={{marginTop:height*0.020,left:width*0.060,flexDirection:'row'}}>
                    <View style={{}}>
                        <Text style={styles.regInputLabel}>First Name<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} value={fname} onChangeText={newFname=>setFname(newFname)}/>
                        {errorsMsg.fname && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.fname}</Text>}
                    </View>
                    <View>
                        <Text style={styles.regInputLabel}>Last Name<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} value={lname} onChangeText={newLname=>setLname(newLname)}/>
                        {errorsMsg.lname && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.lname}</Text>}
                    </View>
                </View>

                <View style={{left:width*0.040,flexDirection:'row',marginTop:height*0.020}}>
                    <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setToggleCheckBox(!toggleCheckBox)}}>
                        <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleCheckBox} onValueChange={()=>{setToggleCheckBox(!toggleCheckBox)}}></CheckBox>
                        <Text style={[styles.checkBoxText,{marginTop:height*0.008}]}>Sign Up for Newsletter</Text>
                    </TouchableOpacity>
                </View>

                <View style={{marginTop:height*0.010,left:width*0.060,flexDirection:'row'}}>
                    <View style={{}}>
                        <Text style={styles.regInputLabel}>Company</Text>
                        <TextInput style={styles.regInput} onChangeText={(newCompany)=>setCompany(newCompany)}/>
                    </View>
                    <View>
                        <Text style={styles.regInputLabel}>Industory</Text>
                        <View style={{zIndex:1}}>
                        <DropDownPicker
                            placeholder={industry[value]?.label}
                            placeholderStyle={{fontSize:height*0.018}}
                            dropDownContainerStyle={styles.dropdownContainerStyle}
                            style={[styles.dropdownStyle,{backgroundColor:'#fff'}]}
                            containerStyle={[styles.filterButtonContainerStyle,{marginTop:height*0.010,height:height*0.060,width:width*0.405}]}
                            zIndex={1}
                            open={open}
                            value={value}
                            items={industry}
                            setOpen={setOpen}
                            setValue={setValue}
                            defaultValue={2}
                            listMode='MODAL'
                        />
                        {console.log('Industry Value:::::::::::::::',value)}
                        </View>
                    </View>
                </View>

                <View style={{marginTop:height*0.020,left:width*0.060,flexDirection:'row'}}>
                    <View style={{}}>
                        <Text style={styles.regInputLabel}>Email<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} value={email} onChangeText={newEmail=>setEmail(newEmail)}/>
                        {errorsMsg.email && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.email}</Text>}
                    </View>
                    <View>
                        <Text style={styles.regInputLabel}>Phone Number<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} value={phone} onChangeText={newPhone=>setPhone(newPhone)} 
                        keyboardType={'numeric'}/>
                        {errorsMsg.phone && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.phone}</Text>}
                    </View>
                </View>

                <View style={{marginTop:height*0.020,left:width*0.060,flexDirection:'row'}}>
                    <View style={{}}>
                        <Text style={styles.regInputLabel}>Street Address<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3',width:width*0.850}]} maxLength={50} value={street} onChangeText={newStreet=>setStreet(newStreet)}/>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3',width:width*0.850}]} maxLength={50} value={street2} onChangeText={newStreet2=>setStreet2(newStreet2)}/>
                        {errorsMsg.street && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.street}</Text>}
                    </View>
                </View>

                <View style={{marginTop:height*0.020,left:width*0.060,flexDirection:'row'}}>
                    <View style={{}}>
                        <Text style={styles.regInputLabel}>City<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} value={city} onChangeText={newCity=>setCity(newCity)}/>
                        {errorsMsg.city && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.city}</Text>}
                    </View>
                    <View>
                        <Text style={styles.regInputLabel}>County<Text style={{color:'#e02b27'}}> {county.length!=0? "*":""}</Text></Text>
                        {county.length!=0?
                        <View style={{zIndex:1}}>
                        <DropDownPicker
                            placeholder="Please Select a County"
                            placeholderStyle={{fontSize:height*0.018}}
                            dropDownContainerStyle={styles.dropdownContainerStyle}
                            style={[styles.dropdownStyle,{backgroundColor:'#fff'}]}
                            containerStyle={[styles.filterButtonContainerStyle,{marginTop:height*0.010,height:height*0.060,width:width*0.405}]}
                            zIndex={1}
                            open={open3}
                            value={value3}
                            textStyle={{color:'#000'}}
                            items={county}
                            setOpen={setOpen3}
                            setValue={setValue3}
                            listMode='MODAL'
                            onSelectItem={(value3)=>getSelectedRegionId(value3)}
                        />
                        </View>:<View>
                            {/* <TextInput style={styles.regInput} value={countyText} onChangeText={newCounty=>setCountyText(newCounty)}/> */}
                            <TextInput  style={styles.regInput} value={countyName} onChangeText={newCountyName=>setCountyName(newCountyName)}></TextInput>
                        </View>}
                        <View><Text style={{color:'#e02b27',marginTop:height*0.010}}>{county.length!=0? countyMessage:""}</Text></View>
                    </View>
                </View>

                <View style={{marginTop:height*0.020,left:width*0.060,flexDirection:'row'}}>
                    <View style={{}}>
                        <Text style={styles.regInputLabel}>Post Code<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} onChangeText={newPostCode=>setPostCode(newPostCode)} 
                        >{route.params.postcode}</TextInput>
                        {errorsMsg.postCode && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.postCode}</Text>}
                    </View>
                </View>

                <View style={{marginTop:height*0.020,left:width*0.060,flexDirection:'row',zIndex:1}}>
                    <View style={{zIndex:1}}>
                        <Text style={[styles.regInputLabel,{width:width*0.340}]}>Country<Text style={{color:'#e02b27'}}> *</Text></Text>
                            <DropDownPicker
                                placeholder="Select Country"
                                placeholderStyle={{fontSize:height*0.018}}
                                dropDownContainerStyle={styles.dropdownContainerStyle}
                                style={[styles.dropdownStyle,{backgroundColor:'#fff'}]}
                                containerStyle={[styles.filterButtonContainerStyle,{marginTop:height*0.010,height:height*0.060,width:width*0.405}]}
                                open={open2}
                                value={value2}
                                items={country}
                                setOpen={setOpen2}
                                setValue={setValue2}
                                listMode='MODAL'
                                />
                        {errorsMsg.value2 && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.value2}</Text>}
                    </View>

                    <View style={{left:width*0.030,bottom:height*0.020}}>
                        <Text style={[styles.regInputLabel,{width:width*0.320}]}>How did you hear about Salvo 1968</Text>
                        <View style={{zIndex:1}}>
                        <DropDownPicker
                            placeholder={hear_about_salvo[value1]?.label}
                            placeholderStyle={{fontSize:height*0.018}}
                            dropDownContainerStyle={styles.dropdownContainerStyle}
                            style={[styles.dropdownStyle,{backgroundColor:'#fff'}]}
                            containerStyle={[styles.filterButtonContainerStyle,{marginTop:height*0.010,height:height*0.060}]}
                            zIndex={1}
                            open={open1}
                            value={value1}
                            items={hear_about_salvo}
                            setOpen={setOpen1}
                            setValue={setValue1}
                            listMode='MODAL'
                        />
                        </View>
                    </View>
                </View>

                <View style={{marginTop:height*0.020,left:width*0.060,flexDirection:'row'}}>
                    <View style={{}}>
                        <Text style={styles.regInputLabel}>Password<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} value={password} onChangeText={newPassword=>setPassword(newPassword)} 
                            secureTextEntry={true}/>
                        {errorsMsg.password && <Text style={{color:'#e02b27',marginTop:height*0.010,width:width*0.4,fontSize:height*0.018}}>{errorsMsg.password}</Text>}
                    </View>
                    <View>
                        <Text style={styles.regInputLabel}>Confirm Password<Text style={{color:'#e02b27'}}> *</Text></Text>
                        <TextInput style={[styles.regInput,{borderColor: error? '#ed8380': '#999DA3'}]} value={confirmPassword} onChangeText={newConfirmPassword=>setConfirmPassword(newConfirmPassword)} 
                        secureTextEntry={true}/>
                        {errorsMsg.confirmPassword && <Text style={{color:'#e02b27',marginTop:height*0.010,width:width*0.4,fontSize:height*0.018}}>{errorsMsg.confirmPassword}</Text>}
                    </View>
                </View>

                <View style={[styles.detailsView,{marginTop:height*0.020}]}>
                    <Text style={styles.detailsText}>Once submitted, our customer service team 
                    will contact you within 7 days to verify your account.</Text>

                    <Text style={[styles.detailsText,{marginTop:height*0.020}]}>Salvo1968 is committed to protecting and 
                    respecting your privacy, and we’ll only use your personal information to administer your 
                    account and to provide the products and services you requested from us. From time to time, 
                    we would like to contact you about our products and services, as well as other content that 
                    may be of interest to you. If you consent to us contacting you for this purpose, please tick 
                    below to say how you would like us to contact you:</Text>
                    
                    <Text style={[styles.detailsText,{marginTop:height*0.020}]}>You can unsubscribe from these 
                    communications at any time. For more information on how to unsubscribe, our privacy practices, 
                    and how we are committed to protecting and respecting your privacy, please review our Privacy 
                    Policy.</Text>

                    <Text style={[styles.detailsText,{marginTop:height*0.020}]}>By clicking submit below, you consent to 
                    allow Salvo1968 to store and process the personal information submitted above to provide you 
                    the content requested.</Text>
                </View>

                <View style={{padding:height*0.030}}>
                    <TouchableOpacity style={styles.submitForm} onPress={() => {validate(); getStoreCode(data)}}>
                        <Text style={styles.submitFormText}>Create an Account</Text>
                    </TouchableOpacity>
                </View>
            </View>
            </View>
        </ScrollView>
          </View>                  
    )
}

export default Register;