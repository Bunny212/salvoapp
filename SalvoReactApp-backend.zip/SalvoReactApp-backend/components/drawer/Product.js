import React,{useState} from 'react';
import {View, StyleSheet, ScrollView,Button,Text,Dimensions,Pressable,ActivityIndicator,TouchableOpacity, Image } from 'react-native';
import styles from '../../styles/styles';
import Sort from '../Sort';
import ProductList from '../list/ProductList';
import { gql, useQuery } from '@apollo/client';
import CheckBox from '@react-native-community/checkbox';
import Modal from "react-native-modal";
import { useDispatch, useSelector } from 'react-redux';
import SubProductList from '../list/SubProductList';
import { setFilter, setSelectedFilter, setWishLists } from '../redux/actions';

const { width, height } = Dimensions.get('window')

  const Product = ({route,navigation}) => {
    const [modalVisible, setModalVisible] = useState(false);
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState('position');
    const [items, setItems] = useState([
      {label: 'Position', value: 'position'},
      {label: 'Name', value: 'name'},
      {label: 'Price', value: 'price'},
      {label: 'Frozen', value: 'is_frozen'}
    ]);
    const [selected,setSelected]=useState([]);
    const [finalArray,setFinalArray]=useState([]);
    const CUSTOMER_EMAIL=useSelector(state=>state.customer?.customer?.email);
    const dispatch=useDispatch();
    const [filterName,setFilterName]=useState('');
    const [selectedInStockFilter,setSelectedInStockFilter]=useState({color:'#000000',index:0,selected:false});
    const [selectedOutStockFilter,setSelectedOutStockFilter]=useState('#000000');
    const [stockStatus,setStockStatus]=useState('');
    const [selectedBrand,setSelectedBrand]=useState('#000000');
    const [brand,setbrand]=useState('');
    const [toggleCheckBoxNew, setToggleCheckBoxNew] = useState(false);
    const [toggleCheckBoxSpecial, setToggleCheckBoxSpecial] = useState(false);
    const [priceFilter,setPriceFilter]=useState({color:'#000000',index:0,selected:false});
    // const [attributeFilter,setAttributeFilter]=useState({color:'#000000',index:0,selected:false});
    // const [attribute,setAttribute]=useState({attr_code:'',value:''});
    const [price,setPrice]=useState(`""`);
    const [price2,setPrice2]=useState(`""`);
    const [currentPage,setCurrentPage]=useState(0);
    const initialFilter=[]
    const [arr,setFilterArray]=useState(initialFilter);
    const TOKEN=useSelector(state=>state.token);
    const getStockCount=(stockValue)=>{
      const GET_STOCK_COUNT = gql`
      {
        products(
          filter: {
            category_id:{in:["${route.params.category_sub_id}"]
            },
            stock_status:{eq:${stockValue}}
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_STOCK_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    // console.log('Count::::::::::::::::::',data);
    return data.products?.total_count;
    }
    console.log('Sub Category ID:::::::::::::',route.params.category_sub_id);

    const getPriceFilterProductCount=(price1,price2)=>{
      const GET_PRODUCT_PRICE_COUNT = gql`
      {
        products(
          filter: {
            category_id:{in:["${route.params.category_sub_id}"]
            },
            price:{
              from:"${price1}"
              to:"${price2}"
            }
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_PRODUCT_PRICE_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    return data.products?.total_count;
    }
    // console.log('ID:::::::::',route.params.category_sub_id);
    const getBrandCount=()=>{
      const GET_BRAND_COUNT=gql`
      {
        products(
          filter: {
            category_id:{in:["${route.params.category_sub_id}"]
            },
            brand_name:{eq:"5"}
          }
        )
         {
          total_count
        }
        }
      `;
      const { loading, error, data } = useQuery(GET_BRAND_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    return data.products?.total_count;
    }
    const getCategoryProductCount=(categoryId)=>{
      const GET_CATEGORY_PRODUCT_COUNT = gql`
      {
        products(
          filter: {
            category_id:{in:["${categoryId}"]
            },
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_CATEGORY_PRODUCT_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    return data?.products?.total_count;
    }
    const getLabels=(option,label)=>{
      if(option==1){
      return  'In Stock';
      }else if(option==2){
        return  'Out of Stock';
      }else{
        return option;
      }
        
    }
    const reteriveWishList=()=>{
      const WISHLIST=gql`query{
        AmastyMultiWishListRetrive(
            customerEmail: "${CUSTOMER_EMAIL}"
        ){
            output{
                wishList_id
                wishList_name
                wishList_count
            }
        }
    }`;
    const { loading, error, data } = useQuery(WISHLIST);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
  dispatch(setWishLists(data?.AmastyMultiWishListRetrive?.output));
  }
  reteriveWishList();
  const getFilters=()=>{
    console.log('My Selkected:::::::::::::::',selected);
    const FILTER=gql`
    {
      products(filter:{category_id:{eq:"${route.params.category_sub_id}"},
      price:{
        from:${price}
        to:${price2}
      }
        ${selected?.map((filter)=>{
          return filter?.id;
        })}
        
    }){
        aggregations{
          label
          attribute_code
          options{
            label
            value
            count
          }
        }
      }
    }
    `;
    const { loading, error, data } = useQuery(FILTER);
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return data;  
  }
  
    function CustomModal(){
     

      return(
      // <>
      // {console.log(priceFilter)}
      // </>
         <View style={styles.centeredView}>
            <Modal
transparent={false}
visible={modalVisible}
onBackdropPress={() => {
  setModalVisible(!modalVisible);
}}
onRequestClose={() => {setModalVisible(false)}}
>
<ScrollView showsVerticalScrollIndicator={false} style={{paddingTop:height*0.15}}>
  <View style={{paddingBottom:height*0.10}}>
<View style={{flexDirection:'row',borderBottomWidth:0.8,justifyContent:'center',top:height*-0.10,paddingBottom:height*0.02}}>
          <Text style={{color:'#000',fontSize:height*0.026}}>Shopping Options</Text>

          <TouchableOpacity style={{right:0,position:'absolute'}} onPress={() => { setModalVisible(false); }}>
            <Image source={require('../../assets/icons/close.png')} 
                  style={{width:width*0.050,height:height*0.050,resizeMode:'contain',tintColor:'#999DA3'}}/>
          </TouchableOpacity>
      </View>

<View style={styles.centeredView}>
  <View style={{width:'100%'}}>
  <View style={[styles.filterModalContainer,{top:height*-0.10}]}>
    
    {getFilters()?.products?.aggregations?.map((filter)=>{
      var att_cod=null;
     
      if(filter?.label!='Category'){
        if(selected?.length!=0){
        var codeIndex = selected?.findIndex(x => x.code ===filter?.attribute_code);
        console.log('Code Index',codeIndex);
        console.log('Code Index',filter?.attribute_code);
        if(codeIndex>-1){
          att_cod=filter?.attribute_code;
        }
        }
        return (
          <>
          <Text style={styles.modalText}>{filter?.label}</Text>
              {filter?.options?.map((options,index)=>{
                 var priceLabel=options?.label?.split('-');
                 var priceLabel1=priceLabel[0];
                 var priceLabel2=priceLabel[1];
                 var att_value=null;
                
                 if(codeIndex>-1){
                    var valueIndex = selected?.findIndex(x => x.value ===options?.label);
                    if(valueIndex>-1){
                    att_value=options?.label;
                    }
                 }
                 return(
                  <>
                        {filter?.label=='Price'?  <TouchableOpacity onPress={()=>{applyPriceFilter(index,`"${priceLabel1}"`,`"${priceLabel2}"`);setCurrentPage(1);}} style={styles.modalOpacity}>
                          <Text style={{color:index==priceFilter?.index?priceFilter.color:'#000000',fontSize:height*0.020}}>£{priceLabel1} - £{priceLabel2} ({options.count})</Text>
                          </TouchableOpacity>
                            :
                            
                          // <TouchableOpacity onPress={()=>{setStockInFilter(selected,{code:filter.attribute_code,value:filter.label=='Stock'?`${filter.attribute_code}:{eq:${options.label}}`:options.label,color:'red',id:options.value});setSelectedValue({code:filter.attribute_code,value:filter.label=='Stock'?`${filter.attribute_code}:{eq:${options.label}}`:options.label,color:'red',id:options.value})}} style={styles.modalOpacity}>
                          // <Text style={{color:'#000000',fontSize:height*0.020}}>{getLabels(options.label,filter.label)} ({options.count})</Text></TouchableOpacity>

                          <TouchableOpacity onPress={()=>{setStockInFilter(selected,{code:filter?.attribute_code,value:options?.label,color:'red',id:`${filter?.attribute_code}:{eq:"${options?.value}"}`}); setSelectedValue({code:filter?.attribute_code,value:options?.label,color:'red',id:`${filter?.attribute_code}:{eq:"${options?.value}"}`})}} style={styles.modalOpacity}>
                          <Text style={{color:att_cod==filter?.attribute_code && att_value ==options?.label? 'red':'#000000',fontSize:height*0.020}}>{getLabels(options?.label,filter?.label)} ({options?.count})</Text></TouchableOpacity>
                          
                          }
                        </>
                 )
                      })}
          </>
        )
      }
    })}
    
    {/* {priceFilter.map((price,index)=>{
      var priceLabel=price.label.split('-');
      var priceLabel1=priceLabel[0];
      var priceLabel2=priceLabel[1];

      return(
        // <TouchableOpacity onPress={()=>{priceFilterOne(`"0"`,`"100"`);setCurrentPage(1);}} style={styles.modalOpacity}>
        // <Text style={{color:price1FilterColor,fontSize:height*0.020}}>£0.00 - £100.00 ({getPriceFilterProductCount(0,100)})</Text>
        <TouchableOpacity onPress={()=>{priceFilterOne(index,`"${priceLabel1}"`,`"${priceLabel2}"`);setCurrentPage(1);}} style={styles.modalOpacity}>
            <Text style={{color:index==price1FilterColor.index?price1FilterColor.color:'#000000',fontSize:height*0.020}}>£{priceLabel1} - £{priceLabel2} ({price.count})</Text>
        </TouchableOpacity>
      )
    })} */}
 
         {/* <TouchableOpacity onPress={()=>{priceFiltertwo(`"100"`,`"200"`);setCurrentPage(1);}} style={styles.modalOpacity}>
         <Text style={{color:price2FilterColor,fontSize:height*0.020}}>£100.00 - £200.00 ({getPriceFilterProductCount(100,200)})</Text>
         </TouchableOpacity>
         <TouchableOpacity onPress={()=>{priceFilterthree(`"200"`,`"300"`);setCurrentPage(1);}} style={styles.modalOpacity}>
           <Text style={{color:price3FilterColor,fontSize:height*0.020}}>£200.00 - £300.00 ({getPriceFilterProductCount(200,300)})</Text>
           </TouchableOpacity> */}
    {/* <Text style={styles.modalText}>BRAND NAME</Text>
         <TouchableOpacity onPress={()=>{setBrandFilter();setCurrentPage(1);}} style={styles.modalOpacity}>
           <Text style={{color:selectedBrand,fontSize:height*0.020}}>Rummo ({getBrandCount()})</Text>
         </TouchableOpacity>
    <Text style={styles.modalText}>FILTER BY</Text>
       <View style={styles.popupCheckbox}>
       <CheckBox style={styles.checkbox} value={toggleCheckBoxNew} onValueChange={()=>{setToggleCheckBoxNew(!toggleCheckBoxNew); setModalVisible(!modalVisible); setCurrentPage(1);}} boxType='square' tintColors={'#9E663C'} ></CheckBox>
       <Text style={styles.checkBoxText}>New ({getCategoryProductCount(5)})</Text>
       </View>
       <View style={styles.popupCheckbox}>
       <CheckBox style={styles.checkbox} value={toggleCheckBoxSpecial} onValueChange={()=>{setToggleCheckBoxSpecial(!toggleCheckBoxSpecial);  setModalVisible(!modalVisible); setCurrentPage(1);}} boxType='square' tintColors={'#9E663C'} ></CheckBox>
       <Text style={styles.checkBoxText}>Special Offers ({getCategoryProductCount(4)})</Text>
       </View>
    <Text style={[styles.modalText,{marginTop:height*0.018}]}>STOCK</Text>
    <View style={{flexDirection:'row'}}>
         <TouchableOpacity onPress={()=>{setStockInFilter(1);setCurrentPage(1);}}>
           <Text style={{color:selectedInStockFilter,fontSize:height*0.020}}>In Stock ({getStockCount(1)})</Text>
         </TouchableOpacity>
         <TouchableOpacity onPress={()=>{setStockOutFilter(2);setCurrentPage(1);}}>
           <Text style={{color:selectedOutStockFilter,marginLeft:width*0.10,fontSize:height*0.020}}>Out of Stock ({getStockCount(2)})</Text>
         </TouchableOpacity>
    </View> */}
   </View>
  </View>
</View>
</View>
</ScrollView>
            </Modal>
         </View>
      );
      
    }
    const setStockInFilter=(array,item)=>{
        if(array?.length == 0)
        {
          // setModalVisible(!modalVisible);
          array?.push(item);
          
        }
        else if(array?.length > 0)
        {
          codeIndex = array?.findIndex(x => x?.code ===item?.code);
          valueIndex = array?.findIndex(x => x?.value ===item?.value);
          console.log(valueIndex);
          if(codeIndex == -1)
          {
            // setModalVisible(!modalVisible);
            array?.push(item);
            // setStockStatus(item.id);
            
          }
          else if(codeIndex > -1)
          {
            if(codeIndex == valueIndex)
            {
              // setModalVisible(!modalVisible);
              array?.splice(codeIndex, 1);
              // setStockStatus("");
             
            }
            else{
              // setModalVisible(!modalVisible);
              array?.splice(codeIndex, 1);
              // setStockStatus("");
              array?.push(item);
              setStockStatus(item.id);
             
            }
          }
          
        }
        setFinalArray([...finalArray],selected);
        // dispatch(setSelectedFilter(selected));
    }
    const setSelectedValue=(item)=>{
        // console.log('Array::::::::',selected);
        // selected.map((select)=>{
        //   if(select.value==item.value){
        //     return selected.color;
        //   }
        // })
        setModalVisible(!modalVisible);
    }

    const setStockOutFilter=()=>{
      if(arr.indexOf('out')==-1){
        arr.push('out');
        console.log('selected if length !=0 and value is also not inserted',initialFilter.indexOf('selected out'));
        setFilterArray(arr);
        console.log('arr if',arr);
        setSelectedOutStockFilter('red');
        setStockStatus(`stock_status:{eq:2}`);   
        setModalVisible(!modalVisible);    
      }else {
        arr.splice(arr.indexOf('out'),1);
        setFilterArray(arr);
        console.log('arr else',arr);
        setSelectedOutStockFilter('#000000');
        console.log('selected if length !=0 and value is inserted',initialFilter);
        setStockStatus(``);   
        setModalVisible(!modalVisible);                  
       }
    }
    const setBrandFilter=()=>{
      if(arr.indexOf('brand')==-1){
        arr.push('brand');
        console.log('selected if length !=0 and value is also not inserted',initialFilter.indexOf('brand'));
        setFilterArray(arr);
        console.log('arr if',arr);
        setSelectedBrand('red');
        setbrand(`eq:"5"`);       
        setModalVisible(!modalVisible);       
      }else {
        arr.splice(arr.indexOf('brand'),1);
        setFilterArray(arr);
        console.log('arr else',arr);
        setSelectedOutStockFilter('#000000');
        console.log('selected if length !=0 and value is inserted',initialFilter);
        setSelectedBrand('#000000');
        setbrand(`eq:""`);    
        setModalVisible(!modalVisible);                      
       }
    }
    const applyPriceFilter=(index,value1,value2)=>{
      console.log(index);
      console.log(value1);
      console.log(value2);

      // if(arr.indexOf('priceOne')==-1){
      //   arr.push('priceOne');
      //   setFilterArray(arr);
     
if(priceFilter.selected==true){    
  if(value1==price && value2==price2){      
        setPriceFilter({color:'#000000',index:index,selected:false});
        setPrice('""');
        setPrice2('""');
        setModalVisible(!modalVisible);
  }else{
    setPriceFilter({color:'red',index:index,selected:true});
    setPrice(value1);
    setPrice2(value2);
    setModalVisible(!modalVisible);
  }
}else{
  setPriceFilter({color:'red',index:index,selected:true});
  setPrice(value1);
  setPrice2(value2);
  setModalVisible(!modalVisible);
}     
      // }else {
      //   arr.splice(arr.indexOf('priceOne'),1);
      //   setFilterArray(arr);
      //   setSelectedOutStockFilter('#000000');
      //   setPrice1FilterColor('#000000');
      //   setPrice(`""`);
      //   setPrice2(`""`);
      //   setModalVisible(!modalVisible);    
      //  }
      
    }
    const priceFiltertwo=(price1,price2)=>{
      if(arr.indexOf('priceOne')==-1){
        arr.push('priceOne');
        setFilterArray(arr);
        setPrice2FilterColor('red');
        setPrice(price1);
        setPrice2(price2);
        setModalVisible(!modalVisible);    
      }else {
        arr.splice(arr.indexOf('priceOne'),1);
        setFilterArray(arr);
        setSelectedOutStockFilter('#000000');
        setPrice2FilterColor('#000000');
        setPrice(`""`);
        setPrice2(`""`);
        setModalVisible(!modalVisible);     
       }
    }
    const priceFilterthree=(price1,price2)=>{
      if(arr.indexOf('priceOne')==-1){
        arr.push('priceOne');
        setFilterArray(arr);
        setPrice3FilterColor('red');
        setPrice(price1);
        setPrice2(price2);
        setModalVisible(!modalVisible);    
      }else {
        arr.splice(arr.indexOf('priceOne'),1);
        setFilterArray(arr);
        setSelectedOutStockFilter('#000000');
        setPrice3FilterColor('#000000');
        setPrice(`""`);
        setPrice2(`""`);
        setModalVisible(!modalVisible);    
       }
    }
    console.log(route.params.title)
   
    return (
      <View style={styles.productListContainer}>
            {/* <TouchableOpacity style={{display: TOKEN==null? 'none':'flex'}} onPress={()=>{navigation.navigate('MyAccount')}}>
              <Text style={{color:'#000',textDecorationLine:'underline',margin:height*0.010}}>My Account</Text>
            </TouchableOpacity> */}
            {/* <Text style={styles.productCategory}>{route.params.category}</Text> */}
            {route.params.search===undefined?<Text style={styles.productCategory}>{route?.params?.title}</Text>:<Text style={styles.productCategory}>Search results for "{route.params.search}"</Text>}
            <View style={[styles.filterSortContainer,{zIndex:1}]}>
            <Sort open={open} setOpen={setOpen} value={value} setValue={setValue} items={items} setItems={setItems}></Sort>
            <TouchableOpacity onPress={()=>setModalVisible(!modalVisible)} style={styles.filterContainer}>
                <Text style={styles.filterButtonText}>Filter</Text>
            </TouchableOpacity>
            </View>
            <Text>{filterName}</Text>
            <SubProductList search={route.params.search} navigation={navigation} dynamicFilter={selected} cart={route.params.cart} filterByPiceOne={price} filterByPiceTwo={price2} filterByNew={toggleCheckBoxNew} filterBySpecial={toggleCheckBoxSpecial} filterByStock={stockStatus} filterByBrand={brand}  value={value} id={route.params.category_sub_id} pageNo={currentPage} title={route?.params?.title}></SubProductList>
            <CustomModal></CustomModal>
        </View>
    );
  };
    
export default Product;
