import React,{useState,useEffect,useRef} from "react";
import { View, Text, StyleSheet,Image,TouchableOpacity, Dimensions,Platform,ScrollView ,ActivityIndicator, Button, KeyboardAvoidingView, FlatList, useWindowDimensions } from "react-native";
import { TextInput } from "react-native-gesture-handler";
import styles from '../../styles/styles';
import {gql, useQuery,useMutation } from '@apollo/client';
import { FlatGrid } from "react-native-super-grid";
import { CREATE_CART } from "../mutations/createCart";
import { ADD_TO_CART } from "../mutations/addToCart";
import { useDispatch, useSelector } from "react-redux";
import { AddtoCart, CartIdSet, NumberofItems,setShippingValue,setSubTotal,setTotalPrice,TotalQuantity } from "../redux/actions";
import WishList from "../list/WishList";
import Sort from "../Sort";
import CheckBox from '@react-native-community/checkbox';
import Modal from "react-native-modal";
import Basket from "../Basket";
import stylesIpad from "../../styles/stylesIpad";

const { width, height } = Dimensions.get('window')
const BlockList = ({route,navigation,id}) =>{
  const heightPad = useWindowDimensions().height;
  const widthPad = useWindowDimensions().width;
    const [cartId,setCartId]=useState(null);
    const pages=[];
    const PRODUCT_SKU=useSelector(state=>state.previousOrders);
    const skus=[];
    const [skuArray,setSkuArray]=useState([]);
    const [currentPage,setCurrentPage]=useState(1);
    const dispatch=useDispatch();
    const [quantity,setQuantity]=useState(1);
    const [sku,setSku]=useState('');
    const TOKEN=useSelector(state=>state.token);
    const [fetchCartId]=useMutation(CREATE_CART);
    const [wishListVisible, setWishListVisible] = useState('none');
    const [load,setLoad]=useState(true);
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState('position');
    const NAVISION_RESPONSE=useSelector(state=>state?.customer?.customer?.minimum_order_amount);
    const [items, setItems] = useState([
      {label: 'Position', value: 'position'},
      {label: 'Name', value: 'name'},
      {label: 'Price', value: 'price'},
      {label: 'Frozen', value: 'is_frozen'}
    ]);
    const units=[];
    const ITEMS=useSelector(state=>state);
    const [modalVisible, setModalVisible] = useState(false);
    const [filterName,setFilterName]=useState(null);
    const [selectedInStockFilter,setSelectedInStockFilter]=useState('#000000');
    const [selectedOutStockFilter,setSelectedOutStockFilter]=useState('#000000');
    const [stockStatus,setStockStatus]=useState('');
    const [selectedBrand,setSelectedBrand]=useState('#000000');
    const [brand,setbrand]=useState('');
    const [toggleCheckBoxNew, setToggleCheckBoxNew] = useState(false);
    const [toggleCheckBoxSpecial, setToggleCheckBoxSpecial] = useState(false);
    const [price1FilterColor,setPrice1FilterColor]=useState('#000000');
    const [price2FilterColor,setPrice2FilterColor]=useState('#000000');
    const [price3FilterColor,setPrice3FilterColor]=useState('#000000');
    const [price,setPrice]=useState(`""`);
    const [price2,setPrice2]=useState(`""`);
    const [minOrdervalue,setMinOrdervalue] = useState('');
    const [remainingMinOrdervalue, setRemainingMinOrderValue] = useState('');
    const [displayMessage,setDisplayMessage]=useState(false);
    const [wishlistMessage,setWishlistMessage]=useState(false);
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
      const [selected,setSelected]=useState([]);
    const [finalArray,setFinalArray]=useState([]);
    const initialFilter=[];
    const Items=[];
    const [arr,setFilterArray]=useState(initialFilter);
    const createCart = async(sku,quantity)=>{
        try{
          const{
            data,errors,
          }=await fetchCartId();
          setCartId(data.cartId);
          setTimeout(() => {
            addToCart(sku,quantity,data?.cartId);
        }, 5000);
         
        }catch(error){
          console.log(error);
          setDisplayServerErrorMsg(true);
          setServerErrorMsg(error.message);        
        }
      }
      const [addProductsToCart]=useMutation(ADD_TO_CART);
    
    const addToCart = async (sku,quantity,cartId) =>{
        try{   
          const{
            data,errors,
          }= await addProductsToCart({
              variables:{
                  cartId,
                  sku,
                  quantity
              }
          });
          dispatch(TotalQuantity(data?.addProductsToCart?.cart?.total_quantity));
          dispatch(NumberofItems(data?.addProductsToCart?.cart?.items?.length));
          dispatch(AddtoCart(data?.addProductsToCart?.cart?.items));
          dispatch(setTotalPrice(data?.addProductsToCart?.cart?.prices?.grand_total?.value));
          dispatch(setSubTotal(data?.addProductsToCart?.cart?.prices?.subtotal_excluding_tax?.value));
          dispatch(setShippingValue(data?.addProductsToCart?.cart?.shipping_addresses[0]?.selected_shipping_method?.amount?.value));
          setMinOrdervalue(NAVISION_RESPONSE);
          setRemainingMinOrderValue(NAVISION_RESPONSE-data?.addProductsToCart?.cart?.prices?.grand_total?.value.toFixed(2));
          dispatch(CartIdSet(cartId));
            }catch(error){
          console.log(error);
          setDisplayServerErrorMsg(true);
          setServerErrorMsg(error.message);        
        }
      }
      if (displayServerError) {
        setTimeout(() => {
          setDisplayServerErrorMsg(false);
        }, 12000);
      }
    
      useEffect(()=>{
        // if(!cartId){
        // createCart();
        // }
        setTimeout(() => {
            setLoad(false);
        }, 5000);

      },[]);

      if (displayMessage) {
        setTimeout(() => {
          setDisplayMessage(!displayMessage)
        }, 12000);
      }
      if (wishlistMessage) {
        setTimeout(() => {
          setWishlistMessage(!wishlistMessage)
        }, 12000);
      }

    const changeWishListVisible = (sku) =>{
    setSku(sku);
     if(wishListVisible=='none'){
      setWishListVisible('flex');
     }
    }
    const close=()=>{
      setWishListVisible('none');
    }
    const onPress=()=>{
      setWishListVisible('none');
      setWishlistMessage(!wishlistMessage);
    }
    console.log('id from another file',route.params.category_id)
    const getStockCount=(stockValue)=>{
      const GET_STOCK_COUNT = gql`
      {
        products(
          filter: {
            stock_status:{eq:${stockValue}}
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_STOCK_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    // console.log('Count::::::::::::::::::',data);
    return data.products?.total_count;
    }
    const getUnit=()=>{
      const SALES_UNIT_OF_MEASURE=gql`
      {
        customAttributeMetadata(
          attributes: [
            {
              attribute_code: "sales_unit_of_measure"
              entity_type: "catalog_product"
            }
          ]
        ) {
          items {
            attribute_code
            attribute_type
            entity_type
            input_type
            attribute_options {
             value
             label
           }
          }
        }
      }
        `;
        const { loading, error, data } = useQuery(SALES_UNIT_OF_MEASURE);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      // console.log(data.customAttributeMetadata.items[0].attribute_options);
      data?.customAttributeMetadata?.items[0]?.attribute_options.map((unit)=>{
        units.push(unit);
      })
    }
    getUnit();
    const getPriceFilterProductCount=(price1,price2)=>{
      const GET_PRODUCT_PRICE_COUNT = gql`
      {
        products(
          filter:  {month_special:{eq:true},
            price:{
              from:"${price1}"
              to:"${price2}"
            }
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_PRODUCT_PRICE_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return data.products?.total_count;
    }
    const getBrandCount=()=>{
      const GET_BRAND_COUNT=gql`
      {
        products(
          filter:  {month_special:{eq:true},
            brand_name:{eq:"5"}
          }
        )
         {
          total_count
        }
        }
      `;
      const { loading, error, data } = useQuery(GET_BRAND_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return data.products?.total_count;
    }
    const getCategoryProductCount=(categoryId)=>{
      const GET_CATEGORY_PRODUCT_COUNT = gql`
      {
        products(
          filter:  {month_special:{eq:true},
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_CATEGORY_PRODUCT_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return data.products?.total_count;
    }
    
    const GetBrand=({data})=>{
        return(
          <View>
          {data.products.aggregations.map((brand_array)=>{
           return(
            <>
            {
            brand_array.attribute_code=="brand_name"? <Text style={styles.rummoText}>
              {brand_array.options[0].label}
            </Text>:<Text style={{height:0}}></Text>
          }
          </>
           )
          })}
          </View>
        )
      }
      const CustomButton=({data,quantity,item,index})=>{
        if(Platform.isPad){
          if(TOKEN==null){
            if(item.stock_status=="IN_STOCK"){
          return(
          <TouchableOpacity onPress={()=>navigation.navigate('Login')} style={[stylesIpad.addProduct,{padding:'8%',
            borderBottomLeftRadius:heightPad*0.010,
            borderBottomRightRadius:heightPad*0.010,
          }]}>
          <Text style={[stylesIpad.loginTextButton,{ fontSize:heightPad*0.015,}]}>Login/Create an Account</Text>
        </TouchableOpacity>
          )
            }else{
              return(
                <View style={[stylesIpad.addProduct,{padding:'8%',
                  borderBottomLeftRadius:heightPad*0.010,
                  borderBottomRightRadius:heightPad*0.010,
                  height:'20%',
                }]}>
                <Text style={[stylesIpad.loginTextButton,{ fontSize:heightPad*0.015,}]}>Out of Stock</Text>
              </View>
              )
            }
          }else{
            if(item.stock_status=="IN_STOCK"){
              return(
              <TouchableOpacity onPress={()=>{addToCart(data.products?.items[index].sku,quantity),setDisplayMessage(!displayMessage),createCart()}}
              style={[stylesIpad.addProduct,{padding:'8%',
                height:'20%',
                borderBottomLeftRadius:heightPad*0.010,
                borderBottomRightRadius:heightPad*0.010,
              }]}>
                
                <Text style={[stylesIpad.addProductText,{ fontSize:heightPad*0.015,}]}>Add to Basket</Text>
              </TouchableOpacity>
              )
            }else{
              return(
              <View style={[stylesIpad.addProduct,{padding:'8%',
                height:'20%',
                borderBottomLeftRadius:heightPad*0.010,
                borderBottomRightRadius:heightPad*0.010,
              }]}>
              <Text style={[stylesIpad.addProductText,{ fontSize:heightPad*0.015,}]}>Out of Stock</Text>
            </View>
              )
            }
      
          }
        }else{
    
          if(item.stock_status=="IN_STOCK"){
            return(
            <TouchableOpacity onPress={()=>{
            
              setDisplayMessage(!displayMessage),createCart(data.products?.items[index].sku,quantity)}} style={styles.addProduct}>
              
              <Text style={styles.addProductText}>Add to Basket</Text>
            </TouchableOpacity>
            )
          }else{
            if(item.stock_status=="IN_STOCK"){
              return(
              <TouchableOpacity onPress={()=>{addToCart(data.products?.items[index].sku,quantity),setDisplayMessage(!displayMessage),createCart()}} style={styles.addProduct}>
                
                <Text style={styles.addProductText}>Add to Basket</Text>
              </TouchableOpacity>
              )
            }else{
              return(
              <View style={styles.addProduct}>
              <Text style={styles.addProductText}>Out of Stock</Text>
            </View>
              )
            }
      
          }
        }
      }
      // console.log(route.params.widget)

  const setStockOutFilter=()=>{
    if(arr.indexOf('out')==-1){
      arr.push('out');
      console.log('selected if length !=0 and value is also not inserted',initialFilter.indexOf('selected out'));
      setFilterArray(arr);
      console.log('arr if',arr);
      setSelectedOutStockFilter('red');
      setStockStatus(`stock_status:{eq:2}`);  
      setModalVisible(!modalVisible);         
    }else {
      arr.splice(arr.indexOf('out'),1);
      setFilterArray(arr);
      console.log('arr else',arr);
      setSelectedOutStockFilter('#000000');
      console.log('selected if length !=0 and value is inserted',initialFilter);
      setStockStatus(``);   
      setModalVisible(!modalVisible);                     
     }
  }
  const setBrandFilter=()=>{
    if(arr.indexOf('brand')==-1){
      arr.push('brand');
      console.log('selected if length !=0 and value is also not inserted',initialFilter.indexOf('brand'));
      setFilterArray(arr);
      console.log('arr if',arr);
      setSelectedBrand('red');
      setbrand(`eq:"5"`);       
      setModalVisible(!modalVisible);       
    }else {
      arr.splice(arr.indexOf('brand'),1);
      setFilterArray(arr);
      console.log('arr else',arr);
      setSelectedOutStockFilter('#000000');
      console.log('selected if length !=0 and value is inserted',initialFilter);
      setSelectedBrand('#000000');
      setbrand(`eq:""`);    
      setModalVisible(!modalVisible);                      
     }
  }
  const priceFilterOne=(price1,price2)=>{
    if(arr.indexOf('priceOne')==-1){
      arr.push('priceOne');
      setFilterArray(arr);
      setPrice1FilterColor('red');
      setPrice(price1);
      setPrice2(price2);
      setModalVisible(!modalVisible);     
    }else {
      arr.splice(arr.indexOf('priceOne'),1);
      setFilterArray(arr);
      setSelectedOutStockFilter('#000000');
      setPrice1FilterColor('#000000');
      setPrice(`""`);
      setPrice2(`""`);
      setModalVisible(!modalVisible);    
     }
  }
  const priceFiltertwo=(price1,price2)=>{
    if(arr.indexOf('priceOne')==-1){
      arr.push('priceOne');
      setFilterArray(arr);
      setPrice2FilterColor('red');
      setPrice(price1);
      setPrice2(price2);
      setModalVisible(!modalVisible);    
    }else {
      arr.splice(arr.indexOf('priceOne'),1);
      setFilterArray(arr);
      setSelectedOutStockFilter('#000000');
      setPrice2FilterColor('#000000');
      setPrice(`""`);
      setPrice2(`""`);
      setModalVisible(!modalVisible);     
     }
  }
  const priceFilterthree=(price1,price2)=>{
    if(arr.indexOf('priceOne')==-1){
      arr.push('priceOne');
      setFilterArray(arr);
      setPrice3FilterColor('red');
      setPrice(price1);
      setPrice2(price2);
      setModalVisible(!modalVisible);    
    }else {
      arr.splice(arr.indexOf('priceOne'),1);
      setFilterArray(arr);
      setSelectedOutStockFilter('#000000');
      setPrice3FilterColor('#000000');
      setPrice(`""`);
      setPrice2(`""`);
      setModalVisible(!modalVisible);    
     }
  }
  const setFilter=()=>{
    if(toggleCheckBoxNew==true && toggleCheckBoxSpecial==true){
        return `"4","5"`;
    }else if(toggleCheckBoxNew==true && toggleCheckBoxSpecial==false){
        return `"5"`;
    }else if(toggleCheckBoxNew==false && toggleCheckBoxSpecial==true){
      return `"4"`;    
    }else{
       return '""';
    }
  }
  const getFilters=()=>{
    // console.log('My Selkected:::::::::::::::',route.params.category_id.length);
      if(route.params.skus==undefined){
        var stringCategory1=route?.params?.category_id?.split(',');
        var stringArray=JSON.stringify(stringCategory1);
    const FILTER=gql`
    {
      products(filter:{
        ${route.params.widget!='previous_orders_homepageblock'? `category_id:{in:${route?.params?.category_id==''?"1435":stringArray}`:`sku:{in:[${PRODUCT_SKU}]`}
      },
      price:{
        from:${price}
        to:${price2}
      }
        ${selected?.map((filter)=>{
          return filter?.id;
        })}
        
    }){
        aggregations{
          label
          attribute_code
          options{
            label
            value
            count
          }
        }
      }
    }
    `;
    const { loading, error, data } = useQuery(FILTER);
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    console.log(data?.products.aggregations[2]);
    return data;
  }else{
    const FILTER=gql`
    {
      products(filter:{
      sku:{in:[${route.params.skus}]
      },
      price:{
        from:${price}
        to:${price2}
      }
        ${selected?.map((filter)=>{
          return filter?.id;
        })}
        
    }){
        aggregations{
          label
          attribute_code
          options{
            label
            value
            count
          }
        }
      }
    }
    `;
    const { loading, error, data } = useQuery(FILTER);
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    console.log(data?.products.aggregations[2]);
    return data;
  }
  
  }
  const getLabels=(option,label)=>{
    if(option==1){
    return  'In Stock';
    }else if(option==2){
      return  'Out of Stock';
    }else{
      return option;
    }
      
  }
  const setSelectedValue=(item)=>{
    // console.log('Array::::::::',selected);
    // selected.map((select)=>{
    //   if(select.value==item.value){
    //     return selected.color;
    //   }
    // })
    setModalVisible(!modalVisible);
}
const setStockInFilter=(array,item)=>{
  if(array?.length == 0)
  {
    // setModalVisible(!modalVisible);
    array?.push(item);
    
  }
  else if(array?.length > 0)
  {
    codeIndex = array?.findIndex(x => x?.code ===item?.code);
    valueIndex = array?.findIndex(x => x?.value ===item?.value);
    console.log(valueIndex);
    if(codeIndex == -1)
    {
      // setModalVisible(!modalVisible);
      array?.push(item);
      // setStockStatus(item.id);
      
    }
    else if(codeIndex > -1)
    {
      if(codeIndex == valueIndex)
      {
        // setModalVisible(!modalVisible);
        array?.splice(codeIndex, 1);
        // setStockStatus("");
       
      }
      else{
        // setModalVisible(!modalVisible);
        array?.splice(codeIndex, 1);
        // setStockStatus("");
        array?.push(item);
        setStockStatus(item.id);
       
      }
    }
    
  }
  setFinalArray([...finalArray],selected);
  // dispatch(setSelectedFilter(selected));
}
    function CustomModal(){
      return(
         <View style={styles.centeredView}>
            <Modal
transparent={false}
visible={modalVisible}
onBackdropPress={() => {
  setModalVisible(!modalVisible);
}}
onRequestClose={() => {setModalVisible(false)}}
>
<ScrollView showsVerticalScrollIndicator={false} style={{paddingTop:height*0.15}}>
  <View style={{paddingBottom:height*0.10}}>
<View style={{flexDirection:'row',borderBottomWidth:0.8,justifyContent:'center',top:height*-0.10,paddingBottom:height*0.02}}>
          <Text style={{color:'#000',fontSize:height*0.026}}>Shopping Options</Text>

          <TouchableOpacity style={{right:0,position:'absolute'}} onPress={() => { setModalVisible(false); }}>
            <Image source={require('../../assets/icons/close.png')} 
                  style={{width:width*0.050,height:height*0.050,resizeMode:'contain',tintColor:'#999DA3'}}/>
          </TouchableOpacity>
      </View>

<View style={styles.centeredView}>
  <View style={{width:'100%'}}>
  <View style={[styles.filterModalContainer,{top:height*-0.10}]}>
    
    {getFilters()?.products?.aggregations?.map((filter)=>{
      var att_cod=null;
     
      if(filter?.label!='Category' && filter?.label!='Price'){
        if(selected?.length!=0){
        var codeIndex = selected?.findIndex(x => x.code ===filter?.attribute_code);
        console.log('Code Index',codeIndex);
        console.log('Code Index',filter?.attribute_code);
        if(codeIndex>-1){
          att_cod=filter?.attribute_code;
        }
        }
        return (
          <>
          <Text style={styles.modalText}>{filter?.label}</Text>
              {filter?.options?.map((options,index)=>{
                 var priceLabel=options?.label?.split('-');
                 var priceLabel1=priceLabel[0];
                 var priceLabel2=priceLabel[1];
                 var att_value=null;
                
                 if(codeIndex>-1){
                    var valueIndex = selected?.findIndex(x => x.value ===options?.label);
                    if(valueIndex>-1){
                    att_value=options?.label;
                    }
                 }
                 return(
                  <>
                        {filter?.label=='Price'?  <TouchableOpacity onPress={()=>{applyPriceFilter(index,`"${priceLabel1}"`,`"${priceLabel2}"`);setCurrentPage(1);}} style={styles.modalOpacity}>
                          <Text style={{color:index==priceFilter?.index?priceFilter.color:'#000000',fontSize:height*0.020}}>£{priceLabel1} - £{priceLabel2} ({options.count})</Text>
                          </TouchableOpacity>
                            :                            
                          <TouchableOpacity onPress={()=>{setStockInFilter(selected,{code:filter?.attribute_code,value:options?.label,color:'red',parentLabel:filter?.label,id:`${filter?.attribute_code}:{eq:"${options?.value}"}`}); setSelectedValue({code:filter?.attribute_code,value:options?.label,color:'red',id:`${filter?.attribute_code}:{eq:"${options?.value}"}`})}} style={styles.modalOpacity}>
                          <Text style={{color:att_cod==filter?.attribute_code && att_value ==options?.label? 'red':'#000000',fontSize:height*0.020}}>{getLabels(options?.label,filter?.label)} ({options?.count})</Text></TouchableOpacity>
                          
                          }
                        </>
                 )
                      })}
          </>
        )
      }
    })}
   </View>
  </View>
</View>
</View>
</ScrollView>
            </Modal>
         </View>
      );
      
    }


 
  //     function CustomModal(){
  //       return(
  //         <>
  //          <View style={styles.centeredView}>
  //             <Modal
  // transparent={false}
  // visible={modalVisible}
  // onBackdropPress={() => {
  //   setModalVisible(!modalVisible);
  // }}
  
  // >
  //       <View style={{flexDirection:'row',borderBottomWidth:0.8,justifyContent:'center',top:height*-0.15,paddingBottom:height*0.02}}>
  //         <Text style={{color:'#000',fontSize:height*0.026}}>Shopping Options</Text>

  //         <TouchableOpacity style={{right:0,position:'absolute'}} onPress={() => { setModalVisible(false); }}>
  //           <Image source={require('../../assets/icons/close.png')} 
  //                 style={{width:width*0.050,height:height*0.050,resizeMode:'contain',tintColor:'#999DA3'}}/>
  //         </TouchableOpacity>
  //     </View>

  // <View style={[styles.centeredView]}>

  //   <View style={{width:'100%'}}>
  //    <View style={[styles.filterModalContainer,{top:height*-0.14}]}>
  //     <Text style={styles.modalText}>PRICE</Text>
  //     <TouchableOpacity onPress={()=>{priceFilterOne(`"0"`,`"100"`);setCurrentPage(1);}} style={styles.modalOpacity}>
  //            <Text style={{color:price1FilterColor,fontSize:height*0.020}}>£0.00 - £100.00 ({getPriceFilterProductCount(0,100)})</Text>
           
  //          </TouchableOpacity>
  //          <TouchableOpacity onPress={()=>{priceFiltertwo(`"100"`,`"200"`);setCurrentPage(1);}} style={styles.modalOpacity}>
  //          <Text style={{color:price2FilterColor,fontSize:height*0.020}}>£100.00 - £200.00 ({getPriceFilterProductCount(100,200)})</Text>
  //          </TouchableOpacity>
  //          <TouchableOpacity onPress={()=>{priceFilterthree(`"200"`,`"300"`);setCurrentPage(1);}} style={styles.modalOpacity}>
  //            <Text style={{color:price3FilterColor,fontSize:height*0.020}}>£200.00 - £300.00 ({getPriceFilterProductCount(200,300)})</Text>
  //            </TouchableOpacity>
  //     <Text style={styles.modalText}>BRAND NAME</Text>
  //          <TouchableOpacity onPress={()=>{setBrandFilter();setCurrentPage(1);}} style={styles.modalOpacity}>
  //            <Text style={{color:selectedBrand,fontSize:height*0.020}}>Rummo ({getBrandCount()})</Text>
  //          </TouchableOpacity>
  //     <Text style={styles.modalText}>FILTER BY</Text>
  //        <View style={styles.popupCheckbox}>
  //        <CheckBox style={styles.checkbox} value={toggleCheckBoxNew} onValueChange={()=>{setToggleCheckBoxNew(!toggleCheckBoxNew); setModalVisible(!modalVisible);setCurrentPage(1);}} boxType='square' tintColors={'#9E663C'} ></CheckBox>
  //        <Text style={styles.checkBoxText}>New ({getCategoryProductCount(5)})</Text>
  //        </View>
  //        <View style={styles.popupCheckbox}>
  //        <CheckBox style={styles.checkbox} value={toggleCheckBoxSpecial} onValueChange={()=>{setToggleCheckBoxSpecial(!toggleCheckBoxSpecial);  setModalVisible(!modalVisible); setCurrentPage(1);}} boxType='square' tintColors={'#9E663C'} ></CheckBox>
  //        <Text style={styles.checkBoxText}>Special Offers ({getCategoryProductCount(4)})</Text>
  //        </View>
  //     <Text style={[styles.modalText,{marginTop:height*0.018}]}>STOCK</Text>
  //     <View style={{flexDirection:'row'}}>
  //          <TouchableOpacity onPress={()=>{setStockInFilter(1);setCurrentPage(1);}}>
  //            <Text style={{color:selectedInStockFilter,fontSize:height*0.020}}>In Stock ({getStockCount(1)})</Text>
  //          </TouchableOpacity>
  //          <TouchableOpacity onPress={()=>{setStockOutFilter(2);setCurrentPage(1);}}>
  //            <Text style={{color:selectedOutStockFilter,marginLeft:width*0.10,fontSize:height*0.020}}>Out of Stock ({getStockCount(2)})</Text>
  //          </TouchableOpacity>
  //     </View>
  //    </View>
  //   </View>
  // </View>
  //             </Modal>
  //          </View>
  //          </>
  //       );
        
  //     }
      function MinimumOrderWarning () {
        return(
          <>
      <View style={{flexDirection:'row',padding:height*0.02,backgroundColor:'#fdf0d5',alignItems:'center'}}>
        <Image source={require('../../assets/icons/danger.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.020}}>
        <Text style={{color:'#6f4400',fontSize:height*0.018,marginLeft:width*0.010}}>
            Minimum order value for delivery is £{minOrdervalue} (excluding VAT) please add £{remainingMinOrdervalue} to your basket.
        </Text>
        </View>
      </View>
          </>
        )
      }
    
      const scrollViewRef = useRef(null);
    
      const selectedPage=(pageNo)=>{
        setLoad(true)
        setCurrentPage(pageNo);
        setTimeout(() => {
          setLoad(false);
      }, 5000);
      }
      const toNextPage = (pageNo) => {
        if(currentPage!=pageNo){
        setCurrentPage(currentPage+1)
        scrollViewRef.current.scrollTo({x:width/currentPage, animated: true});
        setLoad(true);
        setTimeout(() => {
          setLoad(false);
      }, 5000);
      }else{
        setCurrentPage(pageNo);
        setTimeout(() => {
          setLoad(false);
      }, 5000);
      }
    
     };
     const toPreviousPage = () => {
      if(currentPage!=1){
      setCurrentPage(currentPage-1);
      setLoad(true)
      setTimeout(() => {
        setLoad(false);
    }, 5000);
      }else{
        setCurrentPage(1);
        setTimeout(() => {
          setLoad(false);
      }, 5000);
      }
     }
     const [descOpen, setDescOpen] = useState('none');
     const changeDescOpen = () =>{
         if(descOpen=='none'){
             setDescOpen('flex')
         }else{
             setDescOpen('none');
         }
     }

     const getSortValues=()=>{
      const SORT_VALUES = gql`
      {
        products(
          filter: {}
        ) {
           sort_fields{
             options{
               label
               value
             }
           }
        }
      }
    `;
    const { loading, error, data } = useQuery(SORT_VALUES)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    console.log('Search:::::::::',route.params.search);
    data?.products?.sort_fields?.options?.map((item,index)=>{
        // Items.push({label:item.label=='Position' && route.params.search!=undefined? 'Relevence':item.label=='Position'?'Sort':item.label,value:item.label=='Position' && route.params.search!=undefined? searchValue:item.value});
        if(route.params.search==undefined){
          Items.push({label:item.label=='Position'?'Sort':item.label,value:item.value});
        }else{
          Items.push({label:item.label=='Position'?'Relevance':item.label,value:item.value=='position'?'relevance':item.value});
        }
    })
    }
    
    getSortValues();
    //  PRODUCT_SKU?.map((sku)=>{
    //   skus.push(sku?.product_sku);
    //   setSkuArray([...skuArray],skus);
    // })
    console.log('skus":::::::::::::::::::',route.params.skus);

    if(Platform.isPad){
      if(route.params.skus==undefined){
           var stringCategory2=route?.params?.category_id?.split(',');
           var stringArray=JSON.stringify(stringCategory2);
      const WIDGET=gql`
      {
       products(
         filter:
           {
             ${route.params.widget!='previous_orders_homepageblock'? `category_id:{in:${route?.params?.category_id==''?"1435":stringArray}`:`sku:{in:[${PRODUCT_SKU}]`}
           }
           price:{
             from:${price}
             to:${price2}
           }
           ${selected?.map((filter)=>{
             return filter?.id;
           })}
         }
         sort:{
         ${value}:ASC
         }
         pageSize: 15
         currentPage:${currentPage}
       
       )
        {
         sort_fields{
           options{
             label
           }
         }
         aggregations{
           attribute_code
           options{
             label
             value
           }
         }
         
           page_info{
           total_pages
         }
           items{
             sales_unit_of_measure
             brand_name
             stock_status
             is_frozen
             sku
             name
             stock_status
             small_image{
               url
             }
            
             price_range{
               maximum_price{
                 final_price{
                   value
                 }
               }
             }
           }
       }
       }
      `;
      const { loading, error, data } = useQuery(WIDGET);
       if (loading) return <ActivityIndicator></ActivityIndicator>;
       if (error) return <Text style={{color:'#000'}}>{setCurrentPage(1)}</Text>;
       for(let i=1;i<=data.products.page_info.total_pages;i++){
         pages.push(i);
       }
     
         // getSkus(productSKU);
     return(
         <>
         <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
         <Text style={[stylesIpad.widgetTitle,{fontSize:heightPad*0.025,
           padding:'2.5%',}]}>{route?.params?.title}</Text>
         <View style={{display:selected.length!=0?'flex':'none',marginBottom:'5%'}}>  
                     <TouchableOpacity onPress={()=>changeDescOpen()} style={[stylesIpad.accordinTitle,{padding:heightPad*0.022,
       borderBottomWidth:0.4,padding:heightPad*0.005,alignItems:'center',borderBottomWidth:0}]}>
                         <View style={{flexDirection:'row'}}>
                         <Text style={[stylesIpad.accordinTitleText,{fontSize:heightPad*0.018}]}>NOW SHOPPING BY</Text>
                         <Text style={[stylesIpad.accordinTitleText,{fontSize:heightPad*0.018,fontWeight:'200'}]}> ({selected.length})</Text>
                         </View>
                         <Image source={require('../../assets/icons/down-arrow.png')} style={[stylesIpad.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}], width:widthPad*0.032,
       height:heightPad*0.032}]}/>
                     </TouchableOpacity>
                     <View style={[stylesIpad.accordinInner,{display:descOpen,borderBottomWidth:0,padding:heightPad*0.018,
       borderBottomWidth:0.4,}]}>
                         {selected?.map((filters)=>{
                           return(
                             <View style={{flexDirection:'row',alignItems:'center',marginLeft:widthPad*0.020}}>
                               <TouchableOpacity onPress={()=>{
                                 codeIndex = selected?.findIndex(x => x?.code ===filters?.code);
                                 valueIndex = selected?.findIndex(x => x?.value ===filters?.value);
                                 if(codeIndex > -1)
                                     {
                                       if(codeIndex == valueIndex)
                                       {
                                         // setModalVisible(!modalVisible);
                                         selected?.splice(codeIndex, 1);
                                         console.log('Clicked 1');
                                         var array=route?.params?.category_id?.split(',');
                                        
                                         if(array?.length==1){
                                           navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                         }else if(array?.length>1){
                                           navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                         }else{
                                           navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                                         }
                                         // setStockStatus("");
                                       
                                       }
                                     }
                               }}>
                                       <Image source={require('../../assets/icons/close.png')} style={[stylesIpad.downArrow,{ width:widthPad*0.020,
                               height:heightPad*0.010}]}/>  
                               </TouchableOpacity>
                             <Text style={{fontWeight:'bold',marginLeft:widthPad*0.010,fontSize:heightPad*0.020}}>
                               {filters.parentLabel}
                             </Text>
                             <Text>
                               :
                             </Text>
                             <Text style={{marginLeft:widthPad*0.010,fontSize:heightPad*0.020}}>
                             {getLabels(filters.value)}
                             </Text>
                             </View>
                           )
                         })}
                         <TouchableOpacity onPress={()=>{
                               while (selected.length > 0) {
                                 selected.shift();
                                 if(selected.length==0){
                                   console.log('Clicked 1');
                                   var array=route?.params?.category_id?.split(',');
                                  
                                   if(array?.length==1){
                                     navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                   }else if(array?.length>1){
                                     navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                   }else{
                                     navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                                   }
                                 }
                             }         
                         }} style={{marginTop:heightPad*0.015}}>
                           <Text style={{color:'#4776f0',fontSize:heightPad*0.020}}>Clear All</Text>
                         </TouchableOpacity>
                     </View>
                     </View>
                     <View style={{alignItems:'center',zIndex:1,}}>
         <View style={[stylesIpad.filterSortContainer,{height:Platform.OS==='ios'? heightPad*0.060:heightPad*0.066,}]}>
                 <Sort open={open} setOpen={setOpen} value={value} setValue={setValue} items={Items}></Sort>
                 <TouchableOpacity onPress={()=>{setModalVisible(!modalVisible);setOpen(false)}} style={[stylesIpad.filterContainer,{ padding:heightPad*0.010,

         borderWidth:heightPad*0.001,
         height:heightPad*0.060}]}>
                     <Text style={[stylesIpad.filterButtonText,{fontSize:heightPad*0.018,}]}>Filter</Text>
                 </TouchableOpacity>
         </View>
         </View>
         {/* {displayMessage && remainingMinOrdervalue<=minOrdervalue  && ITEMS?.total_qty<=1? <View><MinimumOrderWarning/></View> : null} */}
         {displayMessage? <View style={{width:'100%'}}>
         <View style={{flexDirection:'row',padding:heightPad*0.020,backgroundColor:'#e5efe5',marginTop:heightPad*0.010,alignItems:'center'}}>
             <Image source={require('../../assets/icons/checked.png')} style={{width:widthPad*0.07,height:heightPad*0.04,resizeMode:'contain'}}></Image>
             <View style={{marginHorizontal:widthPad*0.020}}>
               <Text style={{color:'#006400',fontSize:heightPad*0.018,paddingRight:widthPad*0.020}}>  You added {data?.products?.items[0]?.name} to your 
                 <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
                 <Text style={{color:'#000',fontSize:heightPad*0.018,top:heightPad*0.004}}> shopping cart.</Text></TouchableOpacity>
               </Text>
             </View>
           </View>
         </View> : null}
         {wishlistMessage? <View style={{width:'100%'}}>
         <View style={{flexDirection:'row',padding:heightPad*0.020,backgroundColor:'#e5efe5',marginTop:heightPad*0.010,alignItems:'center'}}>
             <Image source={require('../../assets/icons/checked.png')} style={{width:widthPad*0.07,height:heightPad*0.04,resizeMode:'contain'}}></Image>
             <View style={{marginHorizontal:widthPad*0.022}}>
               <Text style={{color:'#006400',fontSize:heightPad*0.018,paddingRight:widthPad*0.020}}>  {data?.products?.items[0]?.name} has been added to 
                 <TouchableOpacity>
                 <Text style={{color:'#000',fontSize:heightPad*0.018,top:heightPad*0.004}}> WishList.</Text></TouchableOpacity>
               </Text>
             </View>
           </View>
         </View> : null}
         {displayServerError==true?<View style={{paddingHorizontal:widthPad*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                     <Text style={stylesIpad.serverError}>{serverError}</Text>  
                 </View>:<View></View>}
     
         {/* style={{width:width<600?width*3.9:width*0.5,marginLeft:width<600?width*0.050:width*0.2}} */}
         {console.log('My Data::::::::::::::::::::',data?.products?.items)}
         {data.products.items.length!=0?  
         <FlatGrid itemDimension={widthPad<heightPad? widthPad/5.095:widthPad/5.095} spacing={10} indicatorStyle={false} data={data?.products?.items}
         renderItem={({index,item})=>(
           <>
     <View style={[stylesIpad.productContainer,{flex:1/data.products.items.length,borderWidth:0.5,
         maxHeight:'90%',
         borderTopLeftRadius:heightPad*0.012,
         borderTopRightRadius:heightPad*0.012,
         borderBottomLeftRadius:heightPad*0.012,
         borderBottomRightRadius:heightPad*0.012,}]}>
     <TouchableOpacity  onPress={()=>{navigation.navigate('ProductPage',{sku:`"${item.sku}"`,block_title:route?.params?.title})}}>
       <View style={{flexDirection:'row',justifyContent:'space-between'}}>
       <Text numberOfLines={1} style={[stylesIpad.skuText,{fontSize:heightPad*0.015,
         padding:heightPad*0.008,
         minHeight:heightPad*0.02,
         maxWidth:widthPad*0.12,}]}>{item.sku}</Text>
       <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible(item.sku):navigation.navigate('Login')}} style={{marginRight:widthPad*0.010,marginTop:heightPad*0.005}}>
         <Image style={{height:heightPad*0.025,width:widthPad*0.025,resizeMode:'contain',tintColor:'#999DA3'}} source={require('../../assets/icons/tasks.png')}></Image>
       </TouchableOpacity>
      
         
       </View>
       <View style={[stylesIpad.productImage,{ height:heightPad*0.150,}]}>
         {load? <ActivityIndicator animating={load}></ActivityIndicator>:<Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:heightPad*0.090,width:widthPad*0.150}}></Image>}
       </View>
       <GetBrand data={data}></GetBrand>
       <Text numberOfLines={3} style={[stylesIpad.productName,{fontSize:heightPad*0.014,
         height:'10%',
         padding:'5%'
        }]}>
         {item.name}
       </Text>
       </TouchableOpacity>
     
       <View style={[stylesIpad.priceContainer,{padding:heightPad*0.009,
         borderWidth:heightPad*0.0005,}]}>
         <TextInput keyboardType="numeric" onChangeText={newQuantity=>setQuantity(newQuantity)} key={item} style={[stylesIpad.input,{
         borderWidth:heightPad*0.0005,
         paddingVertical:'3%',
         paddingHorizontal:'7%',
         fontSize:heightPad*0.015}]}>
             1
         </TextInput>
         <Text style={[stylesIpad.productPrice,{ fontSize:heightPad*0.015, width:'85%',
         padding:'2%'}]}>£{parseFloat(item.price_range.maximum_price.final_price.value).toFixed(2)} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
       </View>
         <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
       
     </View>
           </>
         )}
         />: <View style={[stylesIpad.accountInputField,{width:'100%',  paddingLeft:widthPad*0.022,
         paddingRight:widthPad*0.022,
         paddingBottom:heightPad*0.022,
         marginTop:heightPad*0.010}]}>
         <View style={[stylesIpad.defaultShipping,{padding:heightPad*0.005,}]}>
             <Image source={require('../../assets/icons/danger.png')}
             style={[stylesIpad.dangerIcon,{marginLeft:widthPad*0.020, width:widthPad*0.055,
               height:heightPad*0.040,}]}/>
             <Text style={{color:'#6f4400',fontSize:heightPad*0.018}}>  No Products Found !</Text>
         </View>
       </View>}
       
       <View style={{justifyContent:'center',alignItems:'center'}}>
         {pages.length!=0 && pages.length!=1? <View style={{flexDirection:'row',width:'50%',justifyContent:'center',alignItems:'center'}}>
         <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:heightPad*0.010,width:widthPad*0.07,height:heightPad*0.035,borderRadius:heightPad*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
             <Image source={require('../../assets/icons/back.png')} style={{height:heightPad*0.02,width:widthPad*0.04,tintColor:'#999DA3'}}></Image>
           </TouchableOpacity>
         <View style={[stylesIpad.paginationContainer,{  paddingHorizontal:widthPad*0.010,}]}>
           <ScrollView ref={scrollViewRef}
      horizontal pagingEnabled={true} scrollEnabled={true} showsHorizontalScrollIndicator={false} >
         {pages.map((pageNo)=>{
           return(
             <>
             
             <TouchableOpacity onPress={()=>selectedPage(pageNo)} style={[stylesIpad.pageNumber,{borderColor:currentPage==pageNo? '#000000':'#999DA3',
                 padding:heightPad*0.005,
                 borderWidth:1,
                 marginLeft:widthPad*0.020,
                 width:widthPad<heightPad?widthPad*0.07:widthPad*0.05,
                 height:heightPad*0.040,
                 borderRadius:heightPad*0.006}]}>
               <Text style={{textAlign:'center',color:currentPage==pageNo? '#000000':'#999DA3',fontWeight:currentPage==pageNo? '700':'600',fontSize:heightPad*0.018}}>
                 {pageNo}
               </Text>
             </TouchableOpacity>
             </>
           )
         })}
         </ScrollView>
         </View>
         
         <TouchableOpacity style={{backgroundColor:'#999da3',padding:heightPad*0.010,width:widthPad*0.07,height:heightPad*0.035,borderRadius:heightPad*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toNextPage(data.products.page_info.total_pages)}}>
             <Image source={require('../../assets/icons/back.png')} style={{height:heightPad*0.02,width:widthPad*0.02,tintColor:'#fff',transform:[{rotate:"180deg"}]}}></Image>
           </TouchableOpacity>
         </View>:<View></View>}
         </View>
        
         <CustomModal></CustomModal>
         </ScrollView>
         {TOKEN!=null?<View style={{height:'20%',display:ITEMS.total_qty==0?'none':'flex'}}>
             <Basket navigation={navigation}></Basket>
           </View>:<View></View>}
     
         <KeyboardAvoidingView behavior='height' keyboardVerticalOffset={110} style={[stylesIpad.wishListOuterContainer,{display:wishListVisible,
             height:heightPad*0.70,
             marginLeft:widthPad*0.050,
             marginTop:heightPad*0.060,
             borderRadius:heightPad*0.004,
         }]}>
             <View style={[stylesIpad.wishListClose,{ paddingTop:heightPad*0.020,
         paddingRight:widthPad*0.030}]}>
                 <TouchableOpacity onPress={()=>{close()}}>
                     <Image source={require('../../assets/icons/close.png')} 
                     style={[stylesIpad.wishListCloseIcon,{  width:widthPad*0.040,
                       height:heightPad*0.060,}]}/>
                 </TouchableOpacity>
             </View>
             <WishList onPress={onPress} sku={sku} quantity={quantity} navigation={navigation} id={id}/>
           
       </KeyboardAvoidingView>
     </>
     )
       }else{
         const WIDGET=gql`
      {
       products(
         filter:
           {
             sku:{in:[${route.params.skus}]
           }
           price:{
             from:${price}
             to:${price2}
           }
           ${selected?.map((filter)=>{
             return filter?.id;
           })}
         }
         sort:{
         ${value}:ASC
         }
         pageSize: 15
         currentPage:${currentPage}
       
       )
        {
         sort_fields{
           options{
             label
           }
         }
         aggregations{
           attribute_code
           options{
             label
             value
           }
         }
         
           page_info{
           total_pages
         }
           items{
             sales_unit_of_measure
             brand_name
             stock_status
             is_frozen
             sku
             name
             stock_status
             small_image{
               url
             }
            
             price_range{
               maximum_price{
                 final_price{
                   value
                 }
               }
             }
           }
       }
       }
      `;
      const { loading, error, data } = useQuery(WIDGET);
       if (loading) return <ActivityIndicator></ActivityIndicator>;
       if (error) return <Text style={{color:'#000'}}>{setCurrentPage(1)}</Text>;
       for(let i=1;i<=data.products.page_info.total_pages;i++){
         pages.push(i);
       }
     
         // getSkus(productSKU);
     return(
         <>
         <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
         <Text style={[stylesIpad.widgetTitle,{   fontSize:heightPad*0.035,
           padding:heightPad*0.0215,}]}>{route?.params?.title}</Text>
         <View style={{display:selected.length!=0?'flex':'none',marginBottom:heightPad*0.005}}>  
                     <TouchableOpacity onPress={()=>changeDescOpen()} style={[stylesIpad.accordinTitle,{padding:heightPad*0.022,
       borderBottomWidth:0.4,padding:heightPad*0.005,alignItems:'center',borderBottomWidth:0}]}>
                         <View style={{flexDirection:'row'}}>
                         <Text style={[stylesIpad.accordinTitleText,{fontSize:heightPad*0.018}]}>NOW SHOPPING BY</Text>
                         <Text style={[stylesIpad.accordinTitleText,{fontSize:heightPad*0.018,fontWeight:'200'}]}> ({selected.length})</Text>
                         </View>
                         <Image source={require('../../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                     </TouchableOpacity>
                     <View style={[stylesIpad.accordinInner,{display:descOpen,borderBottomWidth:0}]}>
                         {selected?.map((filters)=>{
                           return(
                             <View style={{flexDirection:'row',alignItems:'center',marginLeft:widthPad*0.020}}>
                               <TouchableOpacity onPress={()=>{
                                 codeIndex = selected?.findIndex(x => x?.code ===filters?.code);
                                 valueIndex = selected?.findIndex(x => x?.value ===filters?.value);
                                 if(codeIndex > -1)
                                     {
                                       if(codeIndex == valueIndex)
                                       {
                                         // setModalVisible(!modalVisible);
                                         selected?.splice(codeIndex, 1);
                                         console.log('Clicked 1');
                                         var array=route?.params?.category_id?.split(',');
                                        
                                         if(array?.length==1){
                                           navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                         }else if(array?.length>1){
                                           navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                         }else{
                                           navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                                         }
                                         // setStockStatus("");
                                       
                                       }
                                     }
                               }}>
                                       <Image source={require('../../assets/icons/close.png')} style={[stylesIpad.downArrow,{ width:widthPad*0.030,
                               height:heightPad*0.030}]}/>  
                               </TouchableOpacity>
                             <Text style={{fontWeight:'bold',marginLeft:widthPad*0.010,fontSize:heightPad*0.020}}>
                               {filters.parentLabel}
                             </Text>
                             <Text>
                               :
                             </Text>
                             <Text style={{marginLeft:widthPad*0.010,fontSize:heightPad*0.020}}>
                             {getLabels(filters.value)}
                             </Text>
                             </View>
                           )
                         })}
                         <TouchableOpacity onPress={()=>{
                               while (selected.length > 0) {
                                 selected.shift();
                                 if(selected.length==0){
                                   console.log('Clicked 1');
                                   var array=route?.params?.category_id?.split(',');
                                  
                                   if(array?.length==1){
                                     navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                   }else if(array?.length>1){
                                     navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                   }else{
                                     navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                                   }
                                 }
                             }         
                         }} style={{marginTop:heightPad*0.015}}>
                           <Text style={{color:'#4776f0'}}>Clear All</Text>
                         </TouchableOpacity>
                     </View>
                     </View>
         <View style={[stylesIpad.filterSortContainer,{zIndex:1}]}>
                 <Sort open={open} setOpen={setOpen} value={value} setValue={setValue} items={Items}></Sort>
                 <TouchableOpacity onPress={()=>{setModalVisible(!modalVisible);setOpen(false)}} style={[stylesIpad.filterContainer,{ 
                  padding:heightPad*0.010,
         borderWidth:heightPad*0.001,
         height:heightPad*0.060}]}>
                     <Text style={[stylesIpad.filterButtonText,{fontSize:heightPad*0.018,}]}>Filter</Text>
                 </TouchableOpacity>
         </View>
     
         {/* {displayMessage && remainingMinOrdervalue<=minOrdervalue  && ITEMS?.total_qty<=1? <View><MinimumOrderWarning/></View> : null} */}
         {displayMessage? <View style={{width:'100%'}}>
         <View style={{flexDirection:'row',padding:heightPad*0.020,backgroundColor:'#e5efe5',marginTop:heightPad*0.010,alignItems:'center'}}>
             <Image source={require('../../assets/icons/checked.png')} style={{width:widthPad*0.07,heightPad:height*0.04,resizeMode:'contain'}}></Image>
             <View style={{marginHorizontal:widthPad*0.020}}>
               <Text style={{color:'#006400',fontSize:heightPad*0.018,paddingRight:widthPad*0.020}}>  You added {data?.products?.items[0]?.name} to your 
                 <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
                 <Text style={{color:'#000',fontSize:heightPad*0.018,top:heightPad*0.004}}> shopping cart.</Text></TouchableOpacity>
               </Text>
             </View>
           </View>
         </View> : null}
         {wishlistMessage? <View style={{width:'100%'}}>
         <View style={{flexDirection:'row',padding:heightPad*0.020,backgroundColor:'#e5efe5',marginTop:heightPad*0.010,alignItems:'center'}}>
             <Image source={require('../../assets/icons/checked.png')} style={{width:widthPad*0.07,height:heightPad*0.04,resizeMode:'contain'}}></Image>
             <View style={{marginHorizontal:widthPad*0.022}}>
               <Text style={{color:'#006400',fontSize:heightPad*0.018,paddingRight:widthPad*0.020}}>  {data?.products?.items[0]?.name} has been added to 
                 <TouchableOpacity>
                 <Text style={{color:'#000',fontSize:heightPad*0.018,top:heightPad*0.004}}> WishList.</Text></TouchableOpacity>
               </Text>
             </View>
           </View>
         </View> : null}
         {displayServerError==true?<View style={{paddingHorizontal:widthPad*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                     <Text style={styles.serverError}>{serverError}</Text>  
                 </View>:<View></View>}
     
         {/* style={{width:width<600?width*3.9:width*0.5,marginLeft:width<600?width*0.050:width*0.2}} */}
         {console.log('My Data::::::::::::::::::::',data?.products?.items)}
         {data.products.items.length!=0?  
         //I am here
         <FlatGrid itemDimension={widthPad<heightPad? width/3.095:widthPad/5.3} spacing={10} indicatorStyle={false} data={data?.products?.items}
         renderItem={({index,item})=>(
           <>
         <View style={{minHeight:heightPad*0.46}}>
     <View  style={[styles.productContainer,{flex:1/data.products.items.length,borderWidth:0.5,
         borderTopLeftRadius:heightPad*0.012,
         borderTopRightRadius:heightPad*0.012,
         borderBottomLeftRadius:heightPad*0.012,
         borderBottomRightRadius:heightPad*0.012,}]}>
     <TouchableOpacity  onPress={()=>{navigation.navigate('ProductPage',{sku:`"${item.sku}"`,block_title:route?.params?.title})}}>
       <View style={{flexDirection:'row',justifyContent:'space-between'}}>
       <Text numberOfLines={1} style={styles.skuText}>{item.sku}</Text>
       <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible(item.sku):navigation.navigate('Login')}} style={{marginRight:width*0.022}}>
         <Image style={{height:heightPad*0.045,width:widthPad*0.045,resizeMode:'contain',tintColor:'#999DA3'}} source={require('../../assets/icons/tasks.png')}></Image>
       </TouchableOpacity>
      
         
       </View>
       <View style={[styles.productImage,{ height:heightPad*0.150,}]}>
         {load? <ActivityIndicator animating={load}></ActivityIndicator>:<Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:height*0.150,width:width*0.350}}></Image>}
       </View>
       <GetBrand data={data}></GetBrand>
       <Text numberOfLines={3} style={[styles.productName,{fontSize:height*0.024,
         minHeight:heightPad*0.12,
         padding:heightPad*0.009,
         marginTop:heightPad*0.016}]}>
         {item.name}
       </Text>
       </TouchableOpacity>
     
       <View style={styles.priceContainer}>
         <TextInput keyboardType='numeric' onChangeText={newQuantity=>setQuantity(newQuantity)} key={item} style={[styles.input,{height:width<600?height*.036:height*0.040,
         borderWidth:heightPad*0.0005,
         width:widthPad<heightPad?width*0.085:widthPad*0.06,
         fontSize:height*0.018}]}>
             1
         </TextInput>
         <Text style={[styles.productPrice,{ fontSize:heightPad*0.018,
         padding:height*0.006}]}>£{parseFloat(item.price_range.maximum_price.final_price.value).toFixed(2)} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
       </View>
         <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
       
     </View>
     </View>
           </>
         )}
         />: <View style={[styles.accountInputField,{width:'100%',  paddingLeft:width*0.022,
         paddingRight:widthPad*0.022,
         paddingBottom:heightPad*0.022,
         marginTop:heightPad*0.010}]}>
         <View style={[styles.defaultShipping,{padding:heightPad*0.005,}]}>
             <Image source={require('../../assets/icons/danger.png')}
             style={[styles.dangerIcon,{marginLeft:widthPad*0.020}]}/>
             <Text style={{color:'#6f4400',fontSize:heightPad*0.018}}>  No Products Found !</Text>
         </View>
       </View>}
       
       <View style={{justifyContent:'center',alignItems:'center'}}>
         {pages.length!=0 && pages.length!=1? <View style={{flexDirection:'row',width:'50%',justifyContent:'center',alignItems:'center'}}>
         <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:heightPad*0.010,width:widthPad*0.07,height:heightPad*0.035,borderRadius:heightPad*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
             <Image source={require('../../assets/icons/back.png')} style={{height:heightPad*0.02,width:widthPad*0.04,tintColor:'#999DA3'}}></Image>
           </TouchableOpacity>
         <View style={styles.paginationContainer}>
           <ScrollView ref={scrollViewRef}
      horizontal pagingEnabled={true} scrollEnabled={true} showsHorizontalScrollIndicator={false} >
         {pages.map((pageNo)=>{
           return(
             <>
             
             <TouchableOpacity onPress={()=>selectedPage(pageNo)} style={[styles.pageNumber,{borderColor:currentPage==pageNo? '#000000':'#999DA3'}]}>
               <Text style={{textAlign:'center',color:currentPage==pageNo? '#000000':'#999DA3',fontWeight:currentPage==pageNo? '700':'600'}}>
                 {pageNo}
               </Text>
             </TouchableOpacity>
             </>
           )
         })}
         </ScrollView>
         </View>
         
         <TouchableOpacity style={{backgroundColor:'#999da3',padding:heightPad*0.010,width:widthPad*0.07,height:heightPad*0.035,borderRadius:heightPad*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toNextPage(data.products.page_info.total_pages)}}>
             <Image source={require('../../assets/icons/back.png')} style={{height:heightPad*0.02,width:widthPad*0.02,tintColor:'#fff',transform:[{rotate:"180deg"}]}}></Image>
           </TouchableOpacity>
         </View>:<View></View>}
         </View>
        
         <CustomModal></CustomModal>
         </ScrollView>
         {TOKEN!=null?<View style={{height:'20%',display:ITEMS.total_qty==0?'none':'flex'}}>
             <Basket navigation={navigation}></Basket>
           </View>:<View></View>}
     
         <KeyboardAvoidingView behavior='height' keyboardVerticalOffset={110} style={[styles.wishListOuterContainer,{display:wishListVisible,
          height:heightPad*0.70,
          marginLeft:widthPad*0.050,
          marginTop:heightPad*0.060,
          borderRadius:heightPad*0.004,
         }]}>
             <View style={[styles.wishListClose,{ paddingTop:heightPad*0.020,
         paddingRight:width*0.030}]}>
                 <TouchableOpacity onPress={()=>{close()}}>
                     <Image source={require('../../assets/icons/close.png')} 
                      style={[styles.wishListCloseIcon,{  width:widthPad*0.040,
                       height:heightPad*0.060,}]}/>
                 </TouchableOpacity>
             </View>
             <WishList onPress={onPress} sku={sku} quantity={quantity} navigation={navigation} id={id}/>
           
       </KeyboardAvoidingView>
     </>
     )
       }
     
     
     }else{
     //Mobile View
     if(route.params.skus==undefined){
      var stringCategory2=route?.params?.category_id?.split(',');
      var stringArray=JSON.stringify(stringCategory2);
 const WIDGET=gql`
 {
  products(
    filter:
      {
        ${route.params.widget!='previous_orders_homepageblock'? `category_id:{in:${route?.params?.category_id==''?"1435":stringArray}`:`sku:{in:[${PRODUCT_SKU}]`}
      }
      price:{
        from:${price}
        to:${price2}
      }
      ${selected?.map((filter)=>{
        return filter?.id;
      })}
    }
    sort:{
    ${value}:ASC
    }
    pageSize: 15
    currentPage:${currentPage}
  
  )
   {
    sort_fields{
      options{
        label
      }
    }
    aggregations{
      attribute_code
      options{
        label
        value
      }
    }
    
      page_info{
      total_pages
    }
      items{
        sales_unit_of_measure
        brand_name
        stock_status
        is_frozen
        sku
        name
        stock_status
        small_image{
          url
        }
       
        price_range{
          maximum_price{
            final_price{
              value
            }
          }
        }
      }
  }
  }
 `;
 const { loading, error, data } = useQuery(WIDGET);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>{setCurrentPage(1)}</Text>;
  for(let i=1;i<=data.products.page_info.total_pages;i++){
    pages.push(i);
  }

    // getSkus(productSKU);
return(
    <>
    <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
    <Text style={styles.widgetTitle}>{route?.params?.title}</Text>
    <View style={{display:selected.length!=0?'flex':'none',marginBottom:height*0.005}}>  
                <TouchableOpacity onPress={()=>changeDescOpen()} style={[styles.accordinTitle,{padding:height*0.005,alignItems:'center',borderBottomWidth:0}]}>
                    <View style={{flexDirection:'row'}}>
                    <Text style={[styles.accordinTitleText,{fontSize:height*0.018}]}>NOW SHOPPING BY</Text>
                    <Text style={[styles.accordinTitleText,{fontSize:height*0.018,fontWeight:'200'}]}> ({selected.length})</Text>
                    </View>
                    <Image source={require('../../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                </TouchableOpacity>
                <View style={[styles.accordinInner,{display:descOpen,borderBottomWidth:0}]}>
                    {selected?.map((filters)=>{
                      return(
                        <View style={{flexDirection:'row',alignItems:'center',marginLeft:height*0.020}}>
                          <TouchableOpacity onPress={()=>{
                            codeIndex = selected?.findIndex(x => x?.code ===filters?.code);
                            valueIndex = selected?.findIndex(x => x?.value ===filters?.value);
                            if(codeIndex > -1)
                                {
                                  if(codeIndex == valueIndex)
                                  {
                                    // setModalVisible(!modalVisible);
                                    selected?.splice(codeIndex, 1);
                                    console.log('Clicked 1');
                                    var array=route?.params?.category_id?.split(',');
                                   
                                    if(array?.length==1){
                                      navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                    }else if(array?.length>1){
                                      navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                    }else{
                                      navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                                    }
                                    // setStockStatus("");
                                  
                                  }
                                }
                          }}>
                                  <Image source={require('../../assets/icons/close.png')} style={[styles.downArrow,{ width:width*0.030,
                          height:height*0.030}]}/>  
                          </TouchableOpacity>
                        <Text style={{fontWeight:'bold',marginLeft:height*0.010}}>
                          {filters.parentLabel}
                        </Text>
                        <Text>
                          :
                        </Text>
                        <Text style={{marginLeft:height*0.010}}>
                        {getLabels(filters.value)}
                        </Text>
                        </View>
                      )
                    })}
                    <TouchableOpacity onPress={()=>{
                          while (selected.length > 0) {
                            selected.shift();
                            if(selected.length==0){
                              console.log('Clicked 1');
                              var array=route?.params?.category_id?.split(',');
                             
                              if(array?.length==1){
                                navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                              }else if(array?.length>1){
                                navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                              }else{
                                navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                              }
                            }
                        }         
                    }} style={{marginTop:height*0.015}}>
                      <Text style={{color:'#4776f0'}}>Clear All</Text>
                    </TouchableOpacity>
                </View>
                </View>
    <View style={[styles.filterSortContainer,{zIndex:1}]}>
            <Sort open={open} setOpen={setOpen} value={value} setValue={setValue} items={Items}></Sort>
            <TouchableOpacity onPress={()=>{setModalVisible(!modalVisible);setOpen(false)}} style={styles.filterContainer}>
                <Text style={styles.filterButtonText}>Filter</Text>
            </TouchableOpacity>
    </View>

    {/* {displayMessage && remainingMinOrdervalue<=minOrdervalue  && ITEMS?.total_qty<=1? <View><MinimumOrderWarning/></View> : null} */}
    {displayMessage? <View style={{width:'100%'}}>
    <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.020}}>
          <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  You added {data?.products?.items[0]?.name} to your 
            <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
            <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> shopping cart.</Text></TouchableOpacity>
          </Text>
        </View>
      </View>
    </View> : null}
    {wishlistMessage? <View style={{width:'100%'}}>
    <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.022}}>
          <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  {data?.products?.items[0]?.name} has been added to 
            <TouchableOpacity>
            <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> WishList.</Text></TouchableOpacity>
          </Text>
        </View>
      </View>
    </View> : null}
    {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}

    {/* style={{width:width<600?width*3.9:width*0.5,marginLeft:width<600?width*0.050:width*0.2}} */}
    {console.log('My Data::::::::::::::::::::',data?.products?.items)}
    {data.products.items.length!=0?  
    <FlatGrid itemDimension={width<720? width/3.095:width/4.095} spacing={10} indicatorStyle={false} data={data?.products?.items}
    renderItem={({index,item})=>(
      <>
    <View style={{minHeight:height*0.44}}>
<View style={[styles.productContainer,{flex:1/data.products.items.length}]}>
<TouchableOpacity  onPress={()=>{navigation.navigate('ProductPage',{sku:`"${item.sku}"`,block_title:route?.params?.title})}}>
  <View style={{flexDirection:'row',justifyContent:'space-between'}}>
  <Text numberOfLines={1} style={styles.skuText}>{item.sku}</Text>
  <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible(item.sku):navigation.navigate('Login')}} style={{marginRight:width*0.022}}>
    <Image style={{height:height*0.045,width:width*0.045,resizeMode:'contain',tintColor:'#999DA3'}} source={require('../../assets/icons/tasks.png')}></Image>
  </TouchableOpacity>
 
    
  </View>
  <View style={styles.productImage}>
    {load? <ActivityIndicator animating={load}></ActivityIndicator>:<Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:height*0.150,width:width*0.350}}></Image>}
  </View>
  <GetBrand data={data}></GetBrand>
  <Text numberOfLines={3} style={styles.productName}>
    {item.name}
  </Text>
  </TouchableOpacity>

  <View style={styles.priceContainer}>
    <TextInput keyboardType='numeric' onChangeText={newQuantity=>setQuantity(newQuantity)} key={item} style={styles.input}>
        1
    </TextInput>
    <Text style={styles.productPrice}>£{parseFloat(item.price_range.maximum_price.final_price.value).toFixed(2)} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
  </View>
    <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
  
</View>
</View>
      </>
    )}
    />: <View style={[styles.accountInputField,{width:'100%'}]}>
    <View style={styles.defaultShipping}>
        <Image source={require('../../assets/icons/danger.png')}
        style={[styles.dangerIcon,{marginLeft:width*0.020}]}/>
        <Text style={{color:'#6f4400',fontSize:height*0.018}}>  No Products Found !</Text>
    </View>
  </View>}
  
  <View style={{justifyContent:'center',alignItems:'center'}}>
    {pages.length!=0 && pages.length!=1? <View style={{flexDirection:'row',width:'50%',justifyContent:'center',alignItems:'center'}}>
    <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.04,tintColor:'#999DA3'}}></Image>
      </TouchableOpacity>
    <View style={styles.paginationContainer}>
      <ScrollView ref={scrollViewRef}
 horizontal pagingEnabled={true} scrollEnabled={true} showsHorizontalScrollIndicator={false} >
    {pages.map((pageNo)=>{
      return(
        <>
        
        <TouchableOpacity onPress={()=>selectedPage(pageNo)} style={[styles.pageNumber,{borderColor:currentPage==pageNo? '#000000':'#999DA3'}]}>
          <Text style={{textAlign:'center',color:currentPage==pageNo? '#000000':'#999DA3',fontWeight:currentPage==pageNo? '700':'600'}}>
            {pageNo}
          </Text>
        </TouchableOpacity>
        </>
      )
    })}
    </ScrollView>
    </View>
    
    <TouchableOpacity style={{backgroundColor:'#999da3',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toNextPage(data.products.page_info.total_pages)}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.02,tintColor:'#fff',transform:[{rotate:"180deg"}]}}></Image>
      </TouchableOpacity>
    </View>:<View></View>}
    </View>
   
    <CustomModal></CustomModal>
    </ScrollView>
    {TOKEN!=null?<View style={{height:'20%',display:ITEMS.total_qty==0?'none':'flex'}}>
        <Basket navigation={navigation}></Basket>
      </View>:<View></View>}

    <KeyboardAvoidingView behavior='height' keyboardVerticalOffset={110} style={[styles.wishListOuterContainer,{display:wishListVisible}]}>
        <View style={styles.wishListClose}>
            <TouchableOpacity onPress={()=>{close()}}>
                <Image source={require('../../assets/icons/close.png')} 
                style={styles.wishListCloseIcon}/>
            </TouchableOpacity>
        </View>
        <WishList onPress={onPress} sku={sku} quantity={quantity} navigation={navigation} id={id}/>
      
  </KeyboardAvoidingView>
</>
)
  }else{
    const WIDGET=gql`
 {
  products(
    filter:
      {
        sku:{in:[${route.params.skus}]
      }
      price:{
        from:${price}
        to:${price2}
      }
      ${selected?.map((filter)=>{
        return filter?.id;
      })}
    }
    sort:{
    ${value}:ASC
    }
    pageSize: 15
    currentPage:${currentPage}
  
  )
   {
    sort_fields{
      options{
        label
      }
    }
    aggregations{
      attribute_code
      options{
        label
        value
      }
    }
    
      page_info{
      total_pages
    }
      items{
        sales_unit_of_measure
        brand_name
        stock_status
        is_frozen
        sku
        name
        stock_status
        small_image{
          url
        }
       
        price_range{
          maximum_price{
            final_price{
              value
            }
          }
        }
      }
  }
  }
 `;
 const { loading, error, data } = useQuery(WIDGET);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>{setCurrentPage(1)}</Text>;
  for(let i=1;i<=data.products.page_info.total_pages;i++){
    pages.push(i);
  }

    // getSkus(productSKU);
return(
    <>
    <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
    <Text style={styles.widgetTitle}>{route?.params?.title}</Text>
    <View style={{display:selected.length!=0?'flex':'none',marginBottom:height*0.005}}>  
                <TouchableOpacity onPress={()=>changeDescOpen()} style={[styles.accordinTitle,{padding:height*0.005,alignItems:'center',borderBottomWidth:0}]}>
                    <View style={{flexDirection:'row'}}>
                    <Text style={[styles.accordinTitleText,{fontSize:height*0.018}]}>NOW SHOPPING BY</Text>
                    <Text style={[styles.accordinTitleText,{fontSize:height*0.018,fontWeight:'200'}]}> ({selected.length})</Text>
                    </View>
                    <Image source={require('../../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                </TouchableOpacity>
                <View style={[styles.accordinInner,{display:descOpen,borderBottomWidth:0}]}>
                    {selected?.map((filters)=>{
                      return(
                        <View style={{flexDirection:'row',alignItems:'center',marginLeft:height*0.020}}>
                          <TouchableOpacity onPress={()=>{
                            codeIndex = selected?.findIndex(x => x?.code ===filters?.code);
                            valueIndex = selected?.findIndex(x => x?.value ===filters?.value);
                            if(codeIndex > -1)
                                {
                                  if(codeIndex == valueIndex)
                                  {
                                    // setModalVisible(!modalVisible);
                                    selected?.splice(codeIndex, 1);
                                    console.log('Clicked 1');
                                    var array=route?.params?.category_id?.split(',');
                                   
                                    if(array?.length==1){
                                      navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                    }else if(array?.length>1){
                                      navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                                    }else{
                                      navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                                    }
                                    // setStockStatus("");
                                  
                                  }
                                }
                          }}>
                                  <Image source={require('../../assets/icons/close.png')} style={[styles.downArrow,{ width:width*0.030,
                          height:height*0.030}]}/>  
                          </TouchableOpacity>
                        <Text style={{fontWeight:'bold',marginLeft:height*0.010}}>
                          {filters.parentLabel}
                        </Text>
                        <Text>
                          :
                        </Text>
                        <Text style={{marginLeft:height*0.010}}>
                        {getLabels(filters.value)}
                        </Text>
                        </View>
                      )
                    })}
                    <TouchableOpacity onPress={()=>{
                          while (selected.length > 0) {
                            selected.shift();
                            if(selected.length==0){
                              console.log('Clicked 1');
                              var array=route?.params?.category_id?.split(',');
                             
                              if(array?.length==1){
                                navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                              }else if(array?.length>1){
                                navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search});
                              }else{
                                navigation.navigate('BlockList',{category_id:route.params.category_id,title:route.params.title,search:route.params.search,skus:PRODUCT_SKU});
                              }
                            }
                        }         
                    }} style={{marginTop:height*0.015}}>
                      <Text style={{color:'#4776f0'}}>Clear All</Text>
                    </TouchableOpacity>
                </View>
                </View>
    <View style={[styles.filterSortContainer,{zIndex:1}]}>
            <Sort open={open} setOpen={setOpen} value={value} setValue={setValue} items={Items}></Sort>
            <TouchableOpacity onPress={()=>{setModalVisible(!modalVisible);setOpen(false)}} style={styles.filterContainer}>
                <Text style={styles.filterButtonText}>Filter</Text>
            </TouchableOpacity>
    </View>

    {/* {displayMessage && remainingMinOrdervalue<=minOrdervalue  && ITEMS?.total_qty<=1? <View><MinimumOrderWarning/></View> : null} */}
    {displayMessage? <View style={{width:'100%'}}>
    <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.020}}>
          <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  You added {data?.products?.items[0]?.name} to your 
            <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
            <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> shopping cart.</Text></TouchableOpacity>
          </Text>
        </View>
      </View>
    </View> : null}
    {wishlistMessage? <View style={{width:'100%'}}>
    <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.022}}>
          <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  {data?.products?.items[0]?.name} has been added to 
            <TouchableOpacity>
            <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> WishList.</Text></TouchableOpacity>
          </Text>
        </View>
      </View>
    </View> : null}
    {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}

    {/* style={{width:width<600?width*3.9:width*0.5,marginLeft:width<600?width*0.050:width*0.2}} */}
    {console.log('My Data::::::::::::::::::::',data?.products?.items)}
    {data.products.items.length!=0?  
    <FlatGrid itemDimension={width<720? width/3.095:width/4.095} spacing={10} indicatorStyle={false} data={data?.products?.items}
    renderItem={({index,item})=>(
      <>
    <View style={{minHeight:height*0.46}}>
<View style={[styles.productContainer,{flex:1/data.products.items.length}]}>
<TouchableOpacity  onPress={()=>{navigation.navigate('ProductPage',{sku:`"${item.sku}"`,block_title:route?.params?.title})}}>
  <View style={{flexDirection:'row',justifyContent:'space-between'}}>
  <Text numberOfLines={1} style={styles.skuText}>{item.sku}</Text>
  <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible(item.sku):navigation.navigate('Login')}} style={{marginRight:width*0.022}}>
    <Image style={{height:height*0.045,width:width*0.045,resizeMode:'contain',tintColor:'#999DA3'}} source={require('../../assets/icons/tasks.png')}></Image>
  </TouchableOpacity>
 
    
  </View>
  <View style={styles.productImage}>
    {load? <ActivityIndicator animating={load}></ActivityIndicator>:<Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:height*0.150,width:width*0.350}}></Image>}
  </View>
  <GetBrand data={data}></GetBrand>
  <Text numberOfLines={3} style={styles.productName}>
    {item.name}
  </Text>
  </TouchableOpacity>

  <View style={styles.priceContainer}>
    <TextInput keyboardType='numeric' onChangeText={newQuantity=>setQuantity(newQuantity)} key={item} style={styles.input}>
        1
    </TextInput>
    <Text style={styles.productPrice}>£{parseFloat(item.price_range.maximum_price.final_price.value).toFixed(2)} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
  </View>
    <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
  
</View>
</View>
      </>
    )}
    />: <View style={[styles.accountInputField,{width:'100%'}]}>
    <View style={styles.defaultShipping}>
        <Image source={require('../../assets/icons/danger.png')}
        style={[styles.dangerIcon,{marginLeft:width*0.020}]}/>
        <Text style={{color:'#6f4400',fontSize:height*0.018}}>  No Products Found !</Text>
    </View>
  </View>}
  
  <View style={{justifyContent:'center',alignItems:'center'}}>
    {pages.length!=0 && pages.length!=1? <View style={{flexDirection:'row',width:'50%',justifyContent:'center',alignItems:'center'}}>
    <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.04,tintColor:'#999DA3'}}></Image>
      </TouchableOpacity>
    <View style={styles.paginationContainer}>
      <ScrollView ref={scrollViewRef}
 horizontal pagingEnabled={true} scrollEnabled={true} showsHorizontalScrollIndicator={false} >
    {pages.map((pageNo)=>{
      return(
        <>
        
        <TouchableOpacity onPress={()=>selectedPage(pageNo)} style={[styles.pageNumber,{borderColor:currentPage==pageNo? '#000000':'#999DA3'}]}>
          <Text style={{textAlign:'center',color:currentPage==pageNo? '#000000':'#999DA3',fontWeight:currentPage==pageNo? '700':'600'}}>
            {pageNo}
          </Text>
        </TouchableOpacity>
        </>
      )
    })}
    </ScrollView>
    </View>
    
    <TouchableOpacity style={{backgroundColor:'#999da3',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toNextPage(data.products.page_info.total_pages)}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.02,tintColor:'#fff',transform:[{rotate:"180deg"}]}}></Image>
      </TouchableOpacity>
    </View>:<View></View>}
    </View>
   
    <CustomModal></CustomModal>
    </ScrollView>
    {TOKEN!=null?<View style={{height:'20%',display:ITEMS.total_qty==0?'none':'flex'}}>
        <Basket navigation={navigation}></Basket>
      </View>:<View></View>}

    <KeyboardAvoidingView behavior='height' keyboardVerticalOffset={110} style={[styles.wishListOuterContainer,{display:wishListVisible}]}>
        <View style={styles.wishListClose}>
            <TouchableOpacity onPress={()=>{close()}}>
                <Image source={require('../../assets/icons/close.png')} 
                style={styles.wishListCloseIcon}/>
            </TouchableOpacity>
        </View>
        <WishList onPress={onPress} sku={sku} quantity={quantity} navigation={navigation} id={id}/>
      
  </KeyboardAvoidingView>
</>
)
  }
}
     }
     



  

export default BlockList;