import React, { useEffect } from 'react';
import { Text,Image, useWindowDimensions, ScrollView, View, TouchableOpacity, Dimensions,ActivityIndicator, BackHandler, Platform} from 'react-native';
import {gql, useMutation, useQuery } from '@apollo/client';
import styles from '../../styles/styles';
import stylesIpad from '../../styles/stylesIpad';
import ItemsCount from './Items';
import { useDispatch, useSelector } from 'react-redux';
import { AddtoCart, CartIdSet, customerDetails, NumberofItems, setPreviousOrders, setTotalPrice, setWishLists, TotalQuantity } from '../redux/actions';
import { CUSTOMER } from '../query/loggedInCustomer';
import { CUSTOMER_ADDRESS } from '../mutations/createCustomerAddress';
import { SET_STORE_VIEW } from '../mutations/setStoreView';


const { width, height } = Dimensions.get('window');

const Block=({navigation,route})=>{
  const heightPad=useWindowDimensions().height;
  const widthPad=useWindowDimensions().width;
  const CUSTOMER_EMAIL=useSelector(state=>state.customer?.customer?.email);
  const cheerio = require('cheerio');

    const blockImages=[require('../../assets/images/block/best-sellers.png'),
    require('../../assets/images/block/fresh-food.png'),
    require('../../assets/images/block/month-special.png'),
    require('../../assets/images/block/orders.png'),
    require('../../assets/images/block/orders.png')];
    const block=[];
 const dispatch=useDispatch();
 const skus=[];
 const TOKEN=useSelector(state=>state.token);
    function createCart (){
      const CUSTOMER_CART=gql`{

    PreviousOrderItem(
      customerEmail: "${CUSTOMER_EMAIL}"
  ){
      product_details{
          product_sku
          product_name
          product_qty
          product_price
          product_image
      }
      message
  }
        customerCart {
          shipping_addresses {
              
            available_shipping_methods {
              amount {
                currency
                value
              }
              available
              carrier_code
              carrier_title
              method_code
              method_title
              price_excl_tax {
                value
                currency
              }
              price_incl_tax {
                value
                currency
              }
            }
            selected_shipping_method {
              amount {
                value
                currency
              }
              carrier_code
              carrier_title
              method_code
              method_title
              
            }
          }
          available_payment_methods{
              code
            }
            id
             items {
          uid
          product {
  
            name
            sku
            small_image{
              url
            }
            price_range{
              maximum_price{
                final_price{
                  value
                }
              }
            }
          }
          quantity
        }
        prices{
          grand_total{
            value
          }
        }
        total_quantity
      }
    }`;
    const {loading,error,data}=useQuery(CUSTOMER_CART);
    if(data!=undefined){
      dispatch(NumberofItems(data?.customerCart?.items?.length));
      dispatch(TotalQuantity(data?.customerCart?.total_quantity));
      dispatch(AddtoCart(data?.customerCart?.items));
      dispatch(setTotalPrice(data?.customerCart?.prices?.grand_total?.value));
      dispatch(CartIdSet(data?.customerCart?.id));
      if(CUSTOMER_EMAIL!=null){
        data?.PreviousOrderItem?.product_details.map((sku)=>{
          skus.push(sku.product_sku);
        })
        dispatch(setPreviousOrders(skus));
      }
    }
    }

     

  
          // useEffect(()=>{
          //     if(TOKEN!=null && route.params!=undefined){
          //         setCustomerAddress(route.params.regionName,route.params.regionCode,route.params.regionId,route.params.country_code,route.params.street,route.params.city,route.params.postcode,route.params.phone,route.params.firstname,route.params.lastname,route.params.company);
                
          //     }
          // },[]);
          // const {loadings,errors,datas}=useQuery(CUSTOMER);
      //     function getCustomer(data){ 
           
      //       if (loading) return <ActivityIndicator></ActivityIndicator>;
      //       if(data!=undefined){
      //            console.log('My Customer Details ',data);
      //            dispatch(customerDetails(data));
      //       }
      //  }
      //  useEffect(()=>{
      //       getCustomer(datas);  
      //  },[])
    createCart();
    const reteriveWishList=()=>{
      const WISHLIST=gql`query{
        AmastyMultiWishListRetrive(
            customerEmail: "${CUSTOMER_EMAIL}"
        ){
            output{
                wishList_id
                wishList_name
                wishList_count
            }
        }
    }`;
    const { loading, error, data } = useQuery(WISHLIST);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
  dispatch(setWishLists(data?.AmastyMultiWishListRetrive?.output));
  }
  reteriveWishList();
    function handleBackButtonClick() {
      navigation.navigate('Default');
      return true;
    }
    useEffect(() => {
      BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
      return () => {
        BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
      };
    }, []);

    const getCategoryId=(content,identifier)=>{
      const startIndex = content.indexOf(`operator`) + 14;
      const endIndex = content.indexOf('"', startIndex);
      const category_url = content.substring(startIndex, endIndex);
      var thenum = category_url.replace(/^\D+/g, '');
      console.log(':::::::::::::',thenum.replace('`^]^]',''));
      block.push({id:thenum.replace('`^]^]','')!=undefined?thenum.replace('`^]^]',''):'',identifier:identifier})
    }

  const GET_BLOCKS = gql`      
        {
          cmsBlocksIdentifier {
            allBlocks {
              identifier
              name
              content
            }
          }



  categoryList{
   id
    children{
      id
      children{
        id
      }
    }
  }


        }
      `;
      const { loading, error, data } = useQuery(GET_BLOCKS);
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      if(Platform.isPad){
        return (
          <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
            <View style={{flexDirection:'column-reverse'}}>
          {data?.cmsBlocksIdentifier?.allBlocks?.map((item,index)=>{
            if(item?.identifier?.includes('homepageblock') && TOKEN==null && item?.identifier!='previous_orders_homepageblock'){
              {getCategoryId(item.content,item?.identifier)}
            return(
            
           <TouchableOpacity onPress={()=>{
            block?.map((identifier)=>{
              if(identifier?.identifier==item?.identifier){
                console.log('My ID',identifier?.id);
                navigation.navigate("BlockList",{widget:item?.identifier,title:item?.name,category_id:identifier?.id})
              }
           })
          }} key={item}>
            <View style={[stylesIpad.blocksContainer,{
               paddingTop:heightPad*0.060,
               paddingBottom:heightPad*0.080, 
               paddingLeft:widthPad*0.060, 
               paddingRight:widthPad*0.060,
               borderWidth:0.4,
            }]}>
              <View style={{width:'65%',paddingHorizontal:'10%'}}>
                {loading?<ActivityIndicator></ActivityIndicator>:<Text style={[stylesIpad.blockTitle,{fontSize:heightPad*0.024}]}>
                      {item?.name}
                  </Text>}
    
                <View style={[stylesIpad.itemsCountContainer,{ marginTop:heightPad*0.010}]}>
                  <Text style={{color:'#a3a3a3',fontSize:heightPad*0.020}}>{cheerio.load(item.content)('.for-app-subheading p').text()}</Text>
                </View>
              
              </View>
              <View style={[stylesIpad.blockImageContainer,{padding:heightPad*0.005}]}>
                <Image source={blockImages[index]} style={[stylesIpad.blockImage,{height:heightPad*0.080,
      width:widthPad*0.300}]}></Image>
              </View>
            </View>
            </TouchableOpacity>
            )
            }else if(item?.identifier?.includes('homepageblock') && TOKEN!=null){


              {getCategoryId(item.content,item?.identifier)}
              return(
             <TouchableOpacity onPress={()=>{
              block?.map((identifier)=>{
                if(identifier?.identifier==item?.identifier){
                  console.log('My ID',identifier?.id);
                  if(item?.identifier=='previous_orders_homepageblock'){
                    navigation.navigate("BlockList",{widget:item?.identifier,title:item?.name})
                  }else{
                    navigation.navigate("BlockList",{widget:item?.identifier,title:item?.name,category_id:identifier?.id})
                  }
                }
             })
            }} key={item}>
              <View style={[stylesIpad.blocksContainer,{
               paddingTop:heightPad*0.060,
               paddingBottom:heightPad*0.080, 
               paddingLeft:widthPad*0.060, 
               paddingRight:widthPad*0.060,
               borderWidth:0.4,
            }]}>
                <View style={{width:'65%',paddingHorizontal:'10%'}}>
                  {loading?<ActivityIndicator></ActivityIndicator>:<Text style={[stylesIpad.blockTitle,{fontSize:heightPad*0.024}]}>
                      {item?.name}
                  </Text>}
      
                  <View style={[stylesIpad.itemsCountContainer,{ marginTop:heightPad*0.010}]}>
                    <Text style={{color:'#a3a3a3',fontSize:heightPad*0.020}}>{cheerio.load(item.content)('.for-app-subheading p').text()}</Text>
                  </View>
                
                </View>
                <View style={[stylesIpad.blockImageContainer,{padding:heightPad*0.005}]}>
                  <Image source={blockImages[index]} style={[stylesIpad.blockImage,{height:heightPad*0.080,
      width:widthPad*0.300}]}></Image>
                </View>
              </View>
              </TouchableOpacity>
              )
            }
           }
        )}
        </View>
       </ScrollView>
        );
      }else{
        //Mobile View
      return (
        <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
          <View style={{flexDirection:'column-reverse'}}>
        {data?.cmsBlocksIdentifier?.allBlocks?.map((item,index)=>{
          if(item?.identifier?.includes('homepageblock') && TOKEN==null && item?.identifier!='previous_orders_homepageblock'){
            {getCategoryId(item.content,item?.identifier)}
          return(
          
         <TouchableOpacity onPress={()=>{
          block?.map((identifier)=>{
            if(identifier?.identifier==item?.identifier){
              console.log('My ID',identifier?.id);
              navigation.navigate("BlockList",{widget:item?.identifier,title:item?.name,category_id:identifier?.id})
            }
         })
        }} key={item}>
          <View style={styles.blocksContainer}>
            <View style={{width:'65%'}}>
              {loading?<ActivityIndicator></ActivityIndicator>:<Text style={styles.blockTitle}>
                  {item?.name}
              </Text>}
  
              <View style={styles.itemsCountContainer}>
                <Text style={{color:'#a3a3a3',fontSize:height*0.020}}>{cheerio.load(item.content)('.for-app-subheading p').text()}</Text>
              </View>
            
            </View>
            <View style={styles.blockImageContainer}>
              <Image source={blockImages[index]} style={styles.blockImage}></Image>
            </View>
          </View>
          </TouchableOpacity>
          )
          }else if(item?.identifier?.includes('homepageblock') && TOKEN!=null){
            {getCategoryId(item.content,item?.identifier)}
            return(
           <TouchableOpacity onPress={()=>{
            block?.map((identifier)=>{
              if(identifier?.identifier==item?.identifier){
                console.log('My ID',identifier?.id);
                if(item?.identifier=='previous_orders_homepageblock'){
                  navigation.navigate("BlockList",{widget:item?.identifier,title:item?.name})
                }else{
                  navigation.navigate("BlockList",{widget:item?.identifier,title:item?.name,category_id:identifier?.id})
                }
              }
           })
          }} key={item}>
            <View style={styles.blocksContainer}>
              <View style={{width:'65%'}}>
                {loading?<ActivityIndicator></ActivityIndicator>:<Text style={styles.blockTitle}>
                    {item?.name}
                </Text>}
    
                <View style={styles.itemsCountContainer}>
                  <Text style={{color:'#a3a3a3',fontSize:height*0.020}}>{cheerio.load(item.content)('.for-app-subheading p').text()}</Text>
                </View>
              
              </View>
              <View style={styles.blockImageContainer}>
                <Image source={blockImages[index]} style={styles.blockImage}></Image>
              </View>
            </View>
            </TouchableOpacity>
            )
          }
         }
      )}
      </View>
     </ScrollView>
      );
        }
}
export default Block;