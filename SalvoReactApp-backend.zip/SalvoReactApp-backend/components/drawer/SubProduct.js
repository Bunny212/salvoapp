import React,{useState} from 'react';
import {View, StyleSheet, ScrollView,Button,Text,Dimensions,Pressable,ActivityIndicator,TouchableOpacity, Image, useWindowDimensions, Platform } from 'react-native';
import styles from '../../styles/styles';
import Sort from '../Sort';
import ProductList from '../list/ProductList';
import { gql, useQuery } from '@apollo/client';
import CheckBox from '@react-native-community/checkbox';
import Modal from "react-native-modal";
import { useDispatch, useSelector } from 'react-redux';
import SubProductList from '../list/SubProductList';
import { ITEMS, setFilter, setSelectedFilter, setWishLists } from '../redux/actions';
import stylesIpad from '../../styles/stylesIpad';
const { width, height } = Dimensions.get('window')
  const SubProduct = ({route,navigation}) => {
    const heightPad = useWindowDimensions().height;
    const widthPad = useWindowDimensions().width;
    const [modalVisible, setModalVisible] = useState(false);
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState('position');
    const [searchValue, setSearchValue] = useState('relevance');
    const [items, setItems] = useState([]);
    const Items=[];
    const ItemsSearch=[{label:'Relevance',value:'relevance'}];
    const [selected,setSelected]=useState([]);
    const [finalArray,setFinalArray]=useState([]);
    const CUSTOMER_EMAIL=useSelector(state=>state.customer?.customer?.email);
    const dispatch=useDispatch();
    const [filterName,setFilterName]=useState('');
    const [selectedInStockFilter,setSelectedInStockFilter]=useState({color:'#000000',index:0,selected:false});
    const [selectedOutStockFilter,setSelectedOutStockFilter]=useState('#000000');
    const [stockStatus,setStockStatus]=useState('');
    const [selectedBrand,setSelectedBrand]=useState('#000000');
    const [brand,setbrand]=useState('');
    const [toggleCheckBoxNew, setToggleCheckBoxNew] = useState(false);
    const [toggleCheckBoxSpecial, setToggleCheckBoxSpecial] = useState(false);
    const [priceFilter,setPriceFilter]=useState({color:'#000000',index:0,selected:false});
    // const [attributeFilter,setAttributeFilter]=useState({color:'#000000',index:0,selected:false});
    // const [attribute,setAttribute]=useState({attr_code:'',value:''});
    const [price,setPrice]=useState(`""`);
    const [price2,setPrice2]=useState(`""`);
    const [currentPage,setCurrentPage]=useState(0);
    const initialFilter=[]
    const [arr,setFilterArray]=useState(initialFilter);
    const TOKEN=useSelector(state=>state.token);
    console.log('Value:::::::::::::',value);
    console.log('Value:::::::::::::',searchValue)
    const getStockCount=(stockValue)=>{
      const GET_STOCK_COUNT = gql`
      {
        products(
          filter: {
            category_id:{in:["${route.params.category_sub_id}"]
            },
            stock_status:{eq:${stockValue}}
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_STOCK_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    // console.log('Count::::::::::::::::::',data);
    return data.products?.total_count;
    }
    console.log('Sub Category ID:::::::::::::',route.params.category_sub_id);

    const getPriceFilterProductCount=(price1,price2)=>{
      const GET_PRODUCT_PRICE_COUNT = gql`
      {
        products(
          filter: {
            category_id:{in:["${route.params.category_sub_id}"]
            },
            price:{
              from:"${price1}"
              to:"${price2}"
            }
          }
        )
         {
          total_count
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_PRODUCT_PRICE_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    return data.products?.total_count;
    }
    // console.log('ID:::::::::',route.params.category_sub_id);
    const getBrandCount=()=>{
      const GET_BRAND_COUNT=gql`
      {
        products(
          filter: {
            category_id:{in:["${route.params.category_sub_id}"]
            },
            brand_name:{eq:"5"}
          }
        )
         {
          total_count
        }
        }
      `;
      const { loading, error, data } = useQuery(GET_BRAND_COUNT)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    return data.products?.total_count;
    }
    const getSortValues=()=>{
      const SORT_VALUES = gql`
      {
        products(
          filter: {}
        ) {
           sort_fields{
             options{
               label
               value
             }
           }
        }
      }
    `;
    const { loading, error, data } = useQuery(SORT_VALUES)
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text>Error :(</Text>;
    console.log('Search:::::::::',route.params.search);
    data.products.sort_fields.options.map((item,index)=>{
        // Items.push({label:item.label=='Position' && route.params.search!=undefined? 'Relevence':item.label=='Position'?'Sort':item.label,value:item.label=='Position' && route.params.search!=undefined? searchValue:item.value});
        if(route.params.search==undefined){
          Items.push({label:item.label=='Position'?'Sort':item.label,value:item.value});
        }else{
          Items.push({label:item.label=='Position'?'Relevance':item.label,value:item.value=='position'?'relevance':item.value});
        }
    })
    console.log(':::::::::::::::::::',Items);
    }
    
    getSortValues();
    const getLabels=(option,label)=>{
      if(option==1){
      return  'In Stock';
      }else if(option==2){
        return  'Out of Stock';
      }else{
        return option;
      }
        
    }
    const reteriveWishList=()=>{
      const WISHLIST=gql`query{
        AmastyMultiWishListRetrive(
            customerEmail: "${CUSTOMER_EMAIL}"
        ){
            output{
                wishList_id
                wishList_name
                wishList_count
            }
        }
    }`;
    const { loading, error, data } = useQuery(WISHLIST);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>Error :(</Text>; 
  dispatch(setWishLists(data?.AmastyMultiWishListRetrive?.output));
  }
  reteriveWishList();
  const getFilters=()=>{
    console.log('My Selkected:::::::::::::::',route.params.search);
    if(route.params.search==null || route.params.search==''){
    const FILTER=gql`
    {
      products(filter:{category_id:{eq:"${route?.params?.category_sub_id}"},
      price:{
        from:${price}
        to:${price2}
      }
        ${selected?.map((filter)=>{
          return filter?.id;
        })}
        
    }){
        aggregations{
          label
          attribute_code
          options{
            label
            value
            count
          }
        }
      }
    }
    `;
    const { loading, error, data } = useQuery(FILTER);
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    console.log(data?.products.aggregations[2]);
    return data;
  }else{
    const FILTER=gql`
    {
      products(
        search:"${route.params.search}"
        filter:{
      price:{
        from:${price}
        to:${price2}
      }
        ${selected?.map((filter)=>{
          return filter?.id;
        })}
        
    }){
        aggregations{
          label
          attribute_code
          options{
            label
            value
            count
          }
        }
      }
    }
    `;
    const { loading, error, data } = useQuery(FILTER);
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    console.log('my log:::::::::',data?.products.aggregations);
    return data;
  }  
  }
  
    function CustomModal(){
      return(
         <View style={styles.centeredView}>
            <Modal
transparent={false}
visible={modalVisible}
onBackdropPress={() => {
  setModalVisible(!modalVisible);
}}
onRequestClose={() => {setModalVisible(false)}}
>
<ScrollView showsVerticalScrollIndicator={false} style={{paddingTop:height*0.15}}>
  <View style={{paddingBottom:height*0.10}}>
<View style={{flexDirection:'row',borderBottomWidth:0.8,justifyContent:'center',top:height*-0.10,paddingBottom:height*0.02}}>
          <Text style={{color:'#000',fontSize:height*0.026}}>Shopping Options</Text>

          <TouchableOpacity style={{right:0,position:'absolute'}} onPress={() => { setModalVisible(false); }}>
            <Image source={require('../../assets/icons/close.png')} 
                  style={{width:width*0.050,height:height*0.050,resizeMode:'contain',tintColor:'#999DA3'}}/>
          </TouchableOpacity>
      </View>

<View style={styles.centeredView}>
  <View style={{width:'100%'}}>
  <View style={[styles.filterModalContainer,{top:height*-0.10}]}>
    
    {getFilters()?.products?.aggregations?.map((filter)=>{
      var att_cod=null;
     
      if(filter?.label!='Category' && filter?.label!='Price'){
        if(selected?.length!=0){
        var codeIndex = selected?.findIndex(x => x.code ===filter?.attribute_code);
        console.log('Code Index',codeIndex);
        console.log('Code Index',filter?.attribute_code);
        if(codeIndex>-1){
          att_cod=filter?.attribute_code;
        }
        }
        return (
          <>
          <Text style={styles.modalText}>{filter?.label}</Text>
              {filter?.options?.map((options,index)=>{
                 var priceLabel=options?.label?.split('-');
                 var priceLabel1=priceLabel[0];
                 var priceLabel2=priceLabel[1];
                 var att_value=null;
                
                 if(codeIndex>-1){
                    var valueIndex = selected?.findIndex(x => x.value ===options?.label);
                    if(valueIndex>-1){
                    att_value=options?.label;
                    }
                 }
                 return(
                  <>
                        {filter?.label=='Price'?  <TouchableOpacity onPress={()=>{applyPriceFilter(index,`"${priceLabel1}"`,`"${priceLabel2}"`);setCurrentPage(1);}} style={styles.modalOpacity}>
                          <Text style={{color:index==priceFilter?.index?priceFilter.color:'#000000',fontSize:height*0.020}}>£{priceLabel1} - £{priceLabel2} ({options.count})</Text>
                          </TouchableOpacity>
                            :                            
                          <TouchableOpacity onPress={()=>{setStockInFilter(selected,{code:filter?.attribute_code,value:options?.label,color:'red',parentLabel:filter?.label,id:`${filter?.attribute_code}:{eq:"${options?.value}"}`}); setSelectedValue({code:filter?.attribute_code,value:options?.label,color:'red',id:`${filter?.attribute_code}:{eq:"${options?.value}"}`})}} style={styles.modalOpacity}>
                          <Text style={{color:att_cod==filter?.attribute_code && att_value ==options?.label? 'red':'#000000',fontSize:height*0.020}}>{getLabels(options?.label,filter?.label)} ({options?.count})</Text></TouchableOpacity>
                          
                          }
                        </>
                 )
                      })}
          </>
        )
      }
    })}
   </View>
  </View>
</View>
</View>
</ScrollView>
            </Modal>
         </View>
      );
      
    }
    const setStockInFilter=(array,item)=>{
        if(array?.length == 0)
        {
          // setModalVisible(!modalVisible);
          array?.push(item);
          
        }
        else if(array?.length > 0)
        {
          codeIndex = array?.findIndex(x => x?.code ===item?.code);
          valueIndex = array?.findIndex(x => x?.value ===item?.value);
          console.log(valueIndex);
          if(codeIndex == -1)
          {
            // setModalVisible(!modalVisible);
            array?.push(item);
            // setStockStatus(item.id);
            
          }
          else if(codeIndex > -1)
          {
            if(codeIndex == valueIndex)
            {
              // setModalVisible(!modalVisible);
              array?.splice(codeIndex, 1);
              // setStockStatus("");
             
            }
            else{
              // setModalVisible(!modalVisible);
              array?.splice(codeIndex, 1);
              // setStockStatus("");
              array?.push(item);
              setStockStatus(item.id);
             
            }
          }
          
        }
        setFinalArray([...finalArray],selected);
        // dispatch(setSelectedFilter(selected));
    }
    const setSelectedValue=(item)=>{
        // console.log('Array::::::::',selected);
        // selected.map((select)=>{
        //   if(select.value==item.value){
        //     return selected.color;
        //   }
        // })
        setModalVisible(!modalVisible);
    }

    const setStockOutFilter=()=>{
      if(arr.indexOf('out')==-1){
        arr.push('out');
        console.log('selected if length !=0 and value is also not inserted',initialFilter.indexOf('selected out'));
        setFilterArray(arr);
        console.log('arr if',arr);
        setSelectedOutStockFilter('red');
        setStockStatus(`stock_status:{eq:2}`);   
        setModalVisible(!modalVisible);    
      }else {
        arr.splice(arr.indexOf('out'),1);
        setFilterArray(arr);
        console.log('arr else',arr);
        setSelectedOutStockFilter('#000000');
        console.log('selected if length !=0 and value is inserted',initialFilter);
        setStockStatus(``);   
        setModalVisible(!modalVisible);                  
       }
    }
    const setBrandFilter=()=>{
      if(arr.indexOf('brand')==-1){
        arr.push('brand');
        console.log('selected if length !=0 and value is also not inserted',initialFilter.indexOf('brand'));
        setFilterArray(arr);
        console.log('arr if',arr);
        setSelectedBrand('red');
        setbrand(`eq:"5"`);       
        setModalVisible(!modalVisible);       
      }else {
        arr.splice(arr.indexOf('brand'),1);
        setFilterArray(arr);
        console.log('arr else',arr);
        setSelectedOutStockFilter('#000000');
        console.log('selected if length !=0 and value is inserted',initialFilter);
        setSelectedBrand('#000000');
        setbrand(`eq:""`);    
        setModalVisible(!modalVisible);                      
       }
    }
    const applyPriceFilter=(index,value1,value2)=>{
      console.log(index);
      console.log(value1);
      console.log(value2);

      // if(arr.indexOf('priceOne')==-1){
      //   arr.push('priceOne');
      //   setFilterArray(arr);
     
if(priceFilter.selected==true){    
  if(value1==price && value2==price2){      
        setPriceFilter({color:'#000000',index:index,selected:false});
        setPrice('""');
        setPrice2('""');
        setModalVisible(!modalVisible);
  }else{
    setPriceFilter({color:'red',index:index,selected:true});
    setPrice(value1);
    setPrice2(value2);
    setModalVisible(!modalVisible);
  }
}else{
  setPriceFilter({color:'red',index:index,selected:true});
  setPrice(value1);
  setPrice2(value2);
  setModalVisible(!modalVisible);
}     
      // }else {
      //   arr.splice(arr.indexOf('priceOne'),1);
      //   setFilterArray(arr);
      //   setSelectedOutStockFilter('#000000');
      //   setPrice1FilterColor('#000000');
      //   setPrice(`""`);
      //   setPrice2(`""`);
      //   setModalVisible(!modalVisible);    
      //  }
      
    }
    const priceFiltertwo=(price1,price2)=>{
      if(arr.indexOf('priceOne')==-1){
        arr.push('priceOne');
        setFilterArray(arr);
        setPrice2FilterColor('red');
        setPrice(price1);
        setPrice2(price2);
        setModalVisible(!modalVisible);    
      }else {
        arr.splice(arr.indexOf('priceOne'),1);
        setFilterArray(arr);
        setSelectedOutStockFilter('#000000');
        setPrice2FilterColor('#000000');
        setPrice(`""`);
        setPrice2(`""`);
        setModalVisible(!modalVisible);     
       }
    }
    const priceFilterthree=(price1,price2)=>{
      if(arr.indexOf('priceOne')==-1){
        arr.push('priceOne');
        setFilterArray(arr);
        setPrice3FilterColor('red');
        setPrice(price1);
        setPrice2(price2);
        setModalVisible(!modalVisible);    
      }else {
        arr.splice(arr.indexOf('priceOne'),1);
        setFilterArray(arr);
        setSelectedOutStockFilter('#000000');
        setPrice3FilterColor('#000000');
        setPrice(`""`);
        setPrice2(`""`);
        setModalVisible(!modalVisible);    
       }
    }
    console.log(route.params.title)
    const [descOpen, setDescOpen] = useState('none');
    const changeDescOpen = () =>{
        if(descOpen=='none'){
            setDescOpen('flex')
        }else{
            setDescOpen('none');
        }
    }
    if(Platform.isPad){
      return (
        <View style={stylesIpad.productListContainer}>
              {/* <TouchableOpacity style={{display: TOKEN==null? 'none':'flex'}} onPress={()=>{navigation.navigate('MyAccount')}}>
                <Text style={{color:'#000',textDecorationLine:'underline',margin:height*0.010}}>My Account</Text>
              </TouchableOpacity> */}
              {/* <Text style={styles.productCategory}>{route.params.category}</Text> */}
              {route.params.search===undefined?<Text style={[stylesIpad.productCategory,{fontSize:heightPad*0.028,
      padding:heightPad*0.024}]}>{route?.params?.title}</Text>:<Text style={[stylesIpad.productCategory,{fontSize:heightPad*0.028,
        padding:heightPad*0.024,}]}>Search results for "{route.params.search}"</Text>}
  
                  <View style={{display:selected.length!=0?'flex':'none',marginBottom:heightPad*0.005}}>  
                  <TouchableOpacity onPress={()=>changeDescOpen()} style={[styles.accordinTitle,{padding:heightPad*0.005,alignItems:'center',borderBottomWidth:0}]}>
                      <View style={{flexDirection:'row'}}>
                      <Text style={[stylesIpad.accordinTitleText,{fontSize:heightPad*0.018}]}>NOW SHOPPING BY</Text>
                      <Text style={[stylesIpad.accordinTitleText,{fontSize:heightPad*0.018,fontWeight:'200'}]}> ({selected.length})</Text>
                      </View>
                      <Image source={require('../../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                  </TouchableOpacity>
                  <View style={[stylesIpad.accordinInner,{display:descOpen,borderBottomWidth:0}]}>
                      {selected?.map((filters)=>{
                        return(
                          <View style={{flexDirection:'row',alignItems:'center',marginLeft:heightPad*0.020}}>
                            <TouchableOpacity onPress={()=>{
                              codeIndex = selected?.findIndex(x => x?.code ===filters?.code);
                              valueIndex = selected?.findIndex(x => x?.value ===filters?.value);
                              if(codeIndex > -1)
                                  {
                                    if(codeIndex == valueIndex)
                                    {
                                      // setModalVisible(!modalVisible);
                                      selected?.splice(codeIndex, 1);
                                     navigation.navigate('SubProduct',{category_sub_id:route.params.category_sub_id,title:route.params.title,search:route.params.search});
                                      // setStockStatus("");
                                    
                                    }
                                  }
                            }}>
                                    <Image source={require('../../assets/icons/close.png')} style={[stylesIpad.downArrow,{ width:widthPad*0.030,
                            height:height*0.030}]}/>  
                            </TouchableOpacity>
                          <Text style={{fontWeight:'bold',marginLeft:heightPad*0.010}}>
                            {filters.parentLabel}
                          </Text>
                          <Text>
                            :
                          </Text>
                          <Text style={{marginLeft:heightPad*0.010}}>
                          {getLabels(filters.value)}
                          </Text>
                          </View>
                        )
                      })}
                      <TouchableOpacity onPress={()=>{
                            while (selected.length > 0) {
                              selected.shift();
                              if(selected.length==0){
                                navigation.navigate('SubProduct',{category_sub_id:route.params.category_sub_id,title:route.params.title,search:route.params.search});
                              }
                          }         
                      }} style={{marginTop:heightPad*0.015}}>
                        <Text style={{color:'#4776f0'}}>Clear All</Text>
                      </TouchableOpacity>
                  </View>
                  </View>
               <View style={{width:'100%',alignItems:'center',zIndex:1}}>  
              <View style={[stylesIpad.filterSortContainer,{height:Platform.OS==='ios'? heightPad*0.060:heightPad*0.066,}]}>
                {route.params.search!=undefined?
                <Sort open={open} setOpen={setOpen} value={searchValue} setValue={setSearchValue} items={Items}></Sort>:            
                <Sort open={open} setOpen={setOpen} value={value} setValue={setValue} items={Items}></Sort>}
  
              <TouchableOpacity onPress={()=>setModalVisible(!modalVisible)} style={[stylesIpad.filterContainer,{ padding:heightPad*0.010,
         borderWidth:heightPad*0.001,
         height:heightPad*0.060}]}>
                     <Text style={[styles.filterButtonText,{fontSize:heightPad*0.018,}]}>Filter</Text>
              </TouchableOpacity>
              </View>
              </View>
              <Text>{filterName}</Text>
              <SubProductList search={route.params.search} navigation={navigation} dynamicFilter={selected} cart={route.params.cart} filterByPiceOne={price} filterByPiceTwo={price2} filterByNew={toggleCheckBoxNew} filterBySpecial={toggleCheckBoxSpecial} filterByStock={stockStatus} filterByBrand={brand}  value={route.params.search!=undefined?searchValue:value} id={route.params.category_sub_id} pageNo={currentPage} title={route?.params?.title}></SubProductList>
              <CustomModal></CustomModal>
          </View>
          
      );
    }else{
      //Mobile View
      return (
        <View style={styles.productListContainer}>
              {/* <TouchableOpacity style={{display: TOKEN==null? 'none':'flex'}} onPress={()=>{navigation.navigate('MyAccount')}}>
                <Text style={{color:'#000',textDecorationLine:'underline',margin:height*0.010}}>My Account</Text>
              </TouchableOpacity> */}
              {/* <Text style={styles.productCategory}>{route.params.category}</Text> */}
              {route.params.search===undefined?<Text style={[styles.productCategory,{fontSize:height*0.035,
      padding:height*0.024}]}>{route?.params?.title}</Text>:<Text style={[styles.productCategory,{fontSize:height*0.035,
        padding:height*0.024,}]}>Search results for "{route.params.search}"</Text>}
  
                  <View style={{display:selected.length!=0?'flex':'none',marginBottom:height*0.005}}>  
                  <TouchableOpacity onPress={()=>changeDescOpen()} style={[styles.accordinTitle,{padding:height*0.005,alignItems:'center',borderBottomWidth:0}]}>
                      <View style={{flexDirection:'row'}}>
                      <Text style={[styles.accordinTitleText,{fontSize:height*0.018}]}>NOW SHOPPING BY</Text>
                      <Text style={[styles.accordinTitleText,{fontSize:height*0.018,fontWeight:'200'}]}> ({selected.length})</Text>
                      </View>
                      <Image source={require('../../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                  </TouchableOpacity>
                  <View style={[styles.accordinInner,{display:descOpen,borderBottomWidth:0}]}>
                      {selected?.map((filters)=>{
                        return(
                          <View style={{flexDirection:'row',alignItems:'center',marginLeft:height*0.020}}>
                            <TouchableOpacity onPress={()=>{
                              codeIndex = selected?.findIndex(x => x?.code ===filters?.code);
                              valueIndex = selected?.findIndex(x => x?.value ===filters?.value);
                              if(codeIndex > -1)
                                  {
                                    if(codeIndex == valueIndex)
                                    {
                                      // setModalVisible(!modalVisible);
                                      selected?.splice(codeIndex, 1);
                                     navigation.navigate('SubProduct',{category_sub_id:route.params.category_sub_id,title:route.params.title,search:route.params.search});
                                      // setStockStatus("");
                                    
                                    }
                                  }
                            }}>
                                    <Image source={require('../../assets/icons/close.png')} style={[styles.downArrow,{ width:width*0.030,
                            height:height*0.030}]}/>  
                            </TouchableOpacity>
                          <Text style={{fontWeight:'bold',marginLeft:height*0.010}}>
                            {filters.parentLabel}
                          </Text>
                          <Text>
                            :
                          </Text>
                          <Text style={{marginLeft:height*0.010}}>
                          {getLabels(filters.value)}
                          </Text>
                          </View>
                        )
                      })}
                      <TouchableOpacity onPress={()=>{
                            while (selected.length > 0) {
                              selected.shift();
                              if(selected.length==0){
                                navigation.navigate('SubProduct',{category_sub_id:route.params.category_sub_id,title:route.params.title,search:route.params.search});
                              }
                          }         
                      }} style={{marginTop:height*0.015}}>
                        <Text style={{color:'#4776f0'}}>Clear All</Text>
                      </TouchableOpacity>
                  </View>
                  </View>
                 
              <View style={[styles.filterSortContainer,{zIndex:1}]}>
                {route.params.search!=undefined?
                <Sort open={open} setOpen={setOpen} value={searchValue} setValue={setSearchValue} items={Items}></Sort>:            
                <Sort open={open} setOpen={setOpen} value={value} setValue={setValue} items={Items}></Sort>}
  
              <TouchableOpacity onPress={()=>setModalVisible(!modalVisible)} style={styles.filterContainer}>
                  <Text style={styles.filterButtonText}>Filter</Text>
              </TouchableOpacity>
              </View>
              <Text>{filterName}</Text>
              <SubProductList search={route.params.search} navigation={navigation} dynamicFilter={selected} cart={route.params.cart} filterByPiceOne={price} filterByPiceTwo={price2} filterByNew={toggleCheckBoxNew} filterBySpecial={toggleCheckBoxSpecial} filterByStock={stockStatus} filterByBrand={brand}  value={route.params.search!=undefined?searchValue:value} id={route.params.category_sub_id} pageNo={currentPage} title={route?.params?.title}></SubProductList>
              <CustomModal></CustomModal>
          </View>
      );
    }
  };
    
export default SubProduct;
