import React from 'react';
import { Text,Image, useWindowDimensions, ScrollView, View, TouchableOpacity, Dimensions,ActivityIndicator} from 'react-native';
import {gql, useQuery } from '@apollo/client';
import styles from '../../styles/styles';
const { width, height } = Dimensions.get('window');
const Items=()=>{

  const GET_COUNT = gql`    
        {
            categoryList{
            products{
            total_count
            }
        }
        }
      `;
      const { loading, error, data } = useQuery(GET_COUNT);
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      return(
    
            <Text style={styles.itemsText}>
               {data?.categoryList[0]?.products?.total_count} items
            </Text>
            )
}
export default Items;