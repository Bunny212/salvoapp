import { gql, useMutation, useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { ScrollView, View,Image, Text, TouchableOpacity,Dimensions, ActivityIndicator, KeyboardAvoidingView, Keyboard } from "react-native";
import { TextInput } from "react-native-gesture-handler";
import { useDispatch, useSelector } from "react-redux";
import styles from "../styles/styles";
import { UPDATE_CART } from "./mutations/updateCart";
import { AddtoCart, NumberofItems, setShippingValue, setSubTotal, setTotalPrice, TotalQuantity } from "./redux/actions";
const { width, height } = Dimensions.get('window')

const Cart = ({navigation,ITEMS,onPress}) => {
    const [uId,setUid]=useState(null);
    const [display,setDisplay]=useState('none');
    const [Width,setWidth]=useState('70%')
    const [serverError,setServerErrorMsg] = useState('');
const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const [quantity,setQuantity]=useState({});
    const PRODUCT=useSelector(state=>state);
    const dispatch=useDispatch();
    const [updateCartItems]=useMutation(UPDATE_CART);
    const displayButton=(uid)=>{
           setUid(uid);
           setWidth('48%');
           setDisplay('flex');
    }
    const updateCart =async (cartId,uid,quantity)=>{
        setWidth('70%');
        setDisplay('none');
        
        try{
            const {error,data}=await updateCartItems({
                variables:{
                    cartId,
                    uid,
                    quantity
                }
            });
            dispatch(AddtoCart(data?.updateCartItems?.cart?.items));
            dispatch(NumberofItems(data?.updateCartItems?.cart?.items?.length));
            dispatch(TotalQuantity(data?.updateCartItems?.cart?.total_quantity));
            dispatch(setTotalPrice(data?.updateCartItems?.cart?.prices?.grand_total?.value));
            dispatch(setSubTotal(data?.updateCartItems?.cart?.prices?.subtotal_excluding_tax?.value));
            // dispatch(setShippingValue(data.updateCartItems.cart.shipping_addresses[0].selected_shipping_method.amount.value));
            // console.log(data.updateCartItems.cart.shipping_addresses[0]);
        }catch(error){
            console.log(error);
            setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message); 
        }
    }
    if (displayServerError) {
        setTimeout(() => {
          setDisplayServerErrorMsg(false);
       }, 12000);
    }
    const EmptyCart=()=>{
        return (
        <View style={{flex:1,justifyContent:'center'}}>
            <Text style={styles.emptyCart}>You have no items in your shopping cart.</Text>
        </View>
        );
   
    }
    return(
        <View style={styles.cartStatusContainer}>
            <View style={{flexDirection:'row',marginBottom:'5%'}}>
                <Image source={require('../assets/icons/shopping-cart.png')} 
                style={styles.basketIcon}/>
                <Text style={styles.yourBasketText}>Your Basket</Text>
            </View>
            {ITEMS.total_qty==0? <EmptyCart></EmptyCart>: 
            <>
            <ScrollView showsVerticalScrollIndicator={false} style={{marginBottom:'5%'}} keyboardShouldPersistTaps={'always'}>
            <View style={{flex:1}}>
            {ITEMS.items?.map((item,index)=>{
                return(
                    <>
                <View style={{flexDirection:'row',marginTop:'3%'}}>
                    <View style={{width:item.uid==uId? Width:'70%'}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('ProductPage',{sku:`"${item.product.sku}"`,uid:item.uid})}>
                            <Text numberOfLines={3} style={styles.itemName}>{item.product.name}</Text>
                        </TouchableOpacity>
                        <Text style={styles.itemPrice}>£{parseFloat(item.product.price_range.maximum_price.final_price.value).toFixed(2)}</Text>
                    </View>
                    <View style={styles.qtyContainer}>
                        <Text style={styles.qtyText}>Qty</Text>
                        <TextInput keyboardType='numeric' onChangeText={(newQuantity)=>setQuantity({quantity:newQuantity,index:index,uid:item.uid},displayButton(item.uid))} style={styles.input}>
                            {item.quantity}
                        </TextInput>
                        <View style={{width:width*0.16}}>
                            <TouchableOpacity onPress={()=>{updateCart(PRODUCT.cartId,uId,quantity.quantity);Keyboard.dismiss()}} style={[styles.qtyUpdate,{display:item.uid==uId?display:'none'}]}>
                                <Text style={styles.qtyUpdateText}>Update</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>    
                <View style={styles.itemSaperator}></View>
                {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                        <Text style={styles.serverError}>{serverError}</Text>  
                    </View>:<View></View>}
                </>
                )
                })}
                </View>
              
                </ScrollView>
                  <View style={{display:'flex'}}>
                  <TouchableOpacity onPress={()=>{navigation.navigate('CartPage');onPress()}} style={styles.proceedCheckoutBtn}>
                      <Text style={styles.proceedCheckout}>Proceed to Checkout</Text>
                  </TouchableOpacity>
              </View>
              </>
                }
        </View>
    )
}

export default Cart;