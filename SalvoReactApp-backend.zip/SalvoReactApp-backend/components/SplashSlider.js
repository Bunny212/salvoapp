import React, { Component, useState } from 'react';
import { Platform,AppRegistry, StyleSheet, Text, View, Image, Dimensions, TouchableOpacity,TextInput, ActivityIndicator, useWindowDimensions } from 'react-native';
import styles from '../styles/styles';
import stylesIpad from '../styles/stylesIpad';
import Swiper from 'react-native-swiper';
const { width, height } = Dimensions.get('window')

const SwiperComponent = ({navigation}) =>{
    if(Platform.isPad){
return(   
<View style={stylesIpad.container}>
  <CloseSlider navigation={navigation}/>
 <Swiper scrollEnabled={true} autoplay={false} alwaysBounceHorizontal={true} 
   index={1} activeDotStyle={{marginTop:useWindowDimensions().height*(-0.4),backgroundColor:'#ffffff'}} 
   dotStyle={{marginTop:useWindowDimensions().height*(-0.4)}} showsButtons={false} loop={true} dotColor='rgba(255,255,255,0.5)' style={stylesIpad.wrapper}
   >
   <View style={stylesIpad.slide1}>
     <View style={{bottom:useWindowDimensions().height*0.080,alignItems:'center'}}>
       <View style={{height: useWindowDimensions().height * 0.3,width: useWindowDimensions().width * 0.4}}>
         <Image
             source={require('../assets/images/salvo.png')}
             style={stylesIpad.logo}
         />
       </View>
       <Text style={[stylesIpad.slide1TextBold,{ fontSize: Platform.OS==='ios' ?useWindowDimensions().height * 0.035:useWindowDimensions().height * 0.04,}]}>The Italian Food</Text>
       <View style={{flexDirection:'row',alignItems:'center'}}>
         <Text style={[stylesIpad.slide1TextBold,{ fontSize: Platform.OS==='ios' ?useWindowDimensions().height * 0.035:useWindowDimensions().height * 0.04,}]}>Specialists</Text>
         <Text style={[stylesIpad.slide1Text,{fontSize: Platform.OS==='ios' ?useWindowDimensions().height * 0.030:useWindowDimensions().height * 0.04,marginLeft:useWindowDimensions().height*0.01}]}>Supplying the</Text>
       </View>
       <Text style={[stylesIpad.slide1Text,,{fontSize: Platform.OS==='ios' ?useWindowDimensions().height * 0.030:useWindowDimensions().height * 0.04}]}>restaurant and catering {'\n'} industry since 1968</Text>
     </View>
   </View>
   <View style={stylesIpad.slide2}>
     <Text style={[stylesIpad.text,{ fontSize: useWindowDimensions().height * 0.09}]}>Best {'\n'} Prices Everyday</Text>
     <Text style={[stylesIpad.Subtext,{fontSize: Platform.OS==='ios' ?useWindowDimensions().height * 0.035:useWindowDimensions().height * 0.04}]}>Guaranteed to give you {'\n'} our best prices daily</Text>
   </View>
   <View style={stylesIpad.slide3}>
     <Text style={[stylesIpad.text,{ fontSize: useWindowDimensions().height * 0.09}]}>Same Day Delivery</Text>
     <Text style={[stylesIpad.Subtext,{fontSize: Platform.OS==='ios' ?useWindowDimensions().height * 0.035:useWindowDimensions().height * 0.04}]}>Same day delivery {'\n'}across parts of London</Text>
   </View>
   <View style={stylesIpad.slide4}>
     <Text style={[stylesIpad.text,{ fontSize: useWindowDimensions().height * 0.09}]}>Click & Collect</Text>
     <Text style={[stylesIpad.Subtext,{fontSize: Platform.OS==='ios' ?useWindowDimensions().height * 0.035:useWindowDimensions().height * 0.04}]}>Get access to our Click & {'\n'} Collect locations</Text>
   </View>
</Swiper>

 <TouchableOpacity onPress={()=>navigation.navigate('TradeAccount',{params:'register'})} style={[stylesIpad.SignUp,{ 
 width: useWindowDimensions().width*0.5, 
 height: useWindowDimensions().height * 0.065,
 borderRadius: useWindowDimensions().height*0.01,
 bottom:  useWindowDimensions().height * 0.110,
 }]}>
           <Text style={[stylesIpad.signupText,{ fontSize: useWindowDimensions().height * 0.025,}]}>Sign up for free</Text>
 </TouchableOpacity>

 <View style={[stylesIpad.LoginContainer,{ marginTop: useWindowDimensions().height * 0.008,
 bottom:useWindowDimensions().height*0.06}]}>
   <Text style={[stylesIpad.loginText,{marginTop:useWindowDimensions().height * 0.01,
 fontSize:useWindowDimensions().height * 0.027}]}>Already signed up? </Text>
       <TouchableOpacity onPress={()=>navigation.navigate('Login',{params:'login'})} style={[stylesIpad.loginText,{marginTop:useWindowDimensions().height * 0.01,
 fontSize:useWindowDimensions().height * 0.027}]}>
           <Text style={[stylesIpad.Login,{fontSize:useWindowDimensions().height * 0.025}]}>Log in</Text>
       </TouchableOpacity>
   </View>
</View>
 
);

    }else{
      return (

        <View style={styles.container}>
           <CloseSlider navigation={navigation}/>
          <Swiper scrollEnabled={true} autoplay={true} alwaysBounceHorizontal={true} 
            index={0} activeDotStyle={{marginTop:width*(-0.7),backgroundColor:'#ffffff'}} 
            dotStyle={{marginTop:width*(-0.7)}} showsButtons={false} loop={true} dotColor='rgba(255,255,255,0.5)' style={styles.wrapper}
            >
            <View style={styles.slide1}>
              <View style={{bottom:height*0.080,alignItems:'center'}}>
                <View style={styles.logoContainer}>
                  <Image
                      source={require('../assets/images/salvo.png')}
                      style={styles.logo}
                  />
                </View>
                <Text style={styles.slide1TextBold}>The Italian Food</Text>
                <View style={{flexDirection:'row'}}>
                  <Text style={styles.slide1TextBold}>Specialists</Text>
                  <Text style={styles.slide1Text}>Supplying the</Text>
                </View>
                <Text style={styles.slide1Text}>restaurant and catering {'\n'} industry since 1968</Text>
              </View>
            </View>
            <View style={styles.slide2}>
              <Text style={styles.text}>Best {'\n'} Prices Everyday</Text>
              <Text style={styles.Subtext}>Guaranteed to give you {'\n'} our best prices daily</Text>
            </View>
            <View style={styles.slide3}>
              <Text style={styles.text}>Same Day Delivery</Text>
              <Text style={styles.Subtext}>Same day delivery {'\n'}across parts of London</Text>
            </View>
            <View style={styles.slide4}>
              <Text style={styles.text}>Click & Collect</Text>
              <Text style={styles.Subtext}>Get access to our Click & {'\n'} Collect locations</Text>
            </View>
        </Swiper>
    
          <TouchableOpacity onPress={()=>navigation.navigate('TradeAccount',{params:'register'})} style={styles.SignUp}>
                    <Text style={styles.signupText}>Sign up for free</Text>
          </TouchableOpacity>
    
          <View style={styles.LoginContainer}>
            <Text style={styles.loginText}>Already signed up? </Text>
                <TouchableOpacity onPress={()=>navigation.navigate('Login',{params:'login'})} style={styles.loginText}>
                    <Text style={styles.Login}>Log in</Text>
                </TouchableOpacity>
            </View>
        </View>
          
        );
    }
   
}
 
export default SwiperComponent;

function CloseSlider ({navigation}) {
  if(Platform.isPad){
    return(
      <View style={[stylesIpad.closeSlider,{ top:useWindowDimensions().height*0.030,
        right:useWindowDimensions().width*0.060}]}>
        <TouchableOpacity onPress={()=>{navigation.navigate('DrawerNavigation',{screen:'Default'})}}>
            <Image source={require('../assets/icons/close.png')} 
              style={[stylesIpad.closeSliderIcon,{  width:useWindowDimensions().width*0.050,
                height:useWindowDimensions().height*0.050,}]}/>
        </TouchableOpacity>
      </View>

    )
  }else{
  return(
      <View style={styles.closeSlider}>
        <TouchableOpacity onPress={()=>{navigation.navigate('DrawerNavigation',{screen:'Default'})}}>
            <Image source={require('../assets/icons/close.png')} 
              style={styles.closeSliderIcon}/>
        </TouchableOpacity>
      </View>
  )
  }
}