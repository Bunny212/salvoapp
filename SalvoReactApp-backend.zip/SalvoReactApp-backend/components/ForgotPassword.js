import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal, BackHandler} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { RESET_PASSWORD } from "./mutations/resetPassword";
import { useMutation } from "@apollo/client";
import { useRef } from "react";
import { ScrollView } from "react-native-gesture-handler";
import { useEffect } from "react";
import { useSelector } from "react-redux";
const ForgotPassword = ({navigation}) =>{
    const [resetPassword]=useMutation(RESET_PASSWORD);
    const CUSTOMER=useSelector(state=>state?.customer);
    const [email,setEmail]=useState('');
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const [errorsMsg, setErrorsMsg] = useState({});
    const [displayMessage,setDisplayMessage]=useState(false);
    
    const newErrors = {};
    if (displayServerError) {
        setTimeout(() => {
          setDisplayServerErrorMsg(false);
        }, 12000);
      }
      function handleBackButtonClick() {
        navigation.navigate('Login');
        return true;
      }
      useEffect(() => {
        BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
        return () => {
          BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
        };
      }, []);

      function ForgotPasswordSuccess () {
        return(
            <>
            <View style={{width:'100%'}}>
                <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
                    <Image source={require('../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
                    <View style={{marginHorizontal:width*0.020}}>
                    <Text style={{color:'#006400',fontSize:height*0.018}}> 
                        If there is an account associated with {email} you will receive an email with a link to reset your password.
                    </Text>
                    </View>
                </View>
            </View>
            </>
        )
}
const reset = async (email) =>{
    try{   
      const{
        data,errors,
      }= await resetPassword({
          variables:{
             email
          }
      });
      if(data!=undefined){
        setDisplayMessage(true);
        setTimeout(() => {
          setDisplayMessage(false);
        }, 10000);
      }
    }catch(error){
        if(Object.keys(newErrors).length==0){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
        }
    }
  }
  const scrollViewRef = useRef(null);

  const validate=()=>{
    if(!email){
        newErrors.email = "This is a required field";
    }else{
        reset(email);
    }
    setErrorsMsg(newErrors);
    scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });
    return Object.keys(newErrors).length === 0;  
  }
    return(
        <>
        <ScrollView ref={scrollViewRef}>
        <View style={styles.forgotPasswordTitle}>
            <Text style={styles.forgotPasswordTitleText}>Forgot Your Password</Text>
        </View>
        {displayMessage? <View><ForgotPasswordSuccess/></View> : <View></View>}

        {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
            <Text style={styles.serverError}>{serverError}</Text>  
        </View>:<View></View>}
        <View style={styles.entityContainer}>
            <Text style={{color:'#000'}}>Please enter your email address below to receive a password reset link.</Text>
        </View>

        <View style={styles.emailField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Email</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput value={email} onChangeText={(newEmail)=>{setEmail(newEmail)}} style={styles.textInput}/>
            {errorsMsg.email && <Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{errorsMsg.email}</Text>}

        </View>
        <View style={styles.entityContainer}>
            <Text style={{color:'red'}}>* Required Fields</Text>
        </View>

        <View style={styles.entityContainer}>
            <TouchableOpacity onPress={()=>validate()} style={styles.createAnAccount}>
                <Text style={styles.summaryButtonText}>Reset My Password</Text>
            </TouchableOpacity>
        </View>
        </ScrollView>
        </>
    )
}

export default ForgotPassword;