import React, { useEffect, useState } from 'react';
import {View, StyleSheet, ScrollView,Button } from 'react-native';
import { ApolloClient, ApolloProvider, InMemoryCache, useMutation } from '@apollo/client';
import { baseUrl } from '../Utils/constants';
import {gql, useQuery} from '@apollo/client';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import SwiperComponent from './SplashSlider';
import DrawerNavigation from './DrawerNavigation';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Cart from './list/ProductList';
import { CREATE_CART } from './mutations/createCart';
import Product from './ProductPage';
import Basket from './Basket';
import { Provider, useSelector } from 'react-redux';
import { myStore } from './redux/store';
import Login from './Login';
import Header from './Header';
import MainDrawerNavigation from './DrawerNavigation';
import CartPage from './CartPage';
import Checkout from './CheckoutPage';
import WishList from './list/WishList';
import ShopBrand from './ShopBrand';
import Register from './Register';
import Block from './drawer/Block';
  const Stack = createNativeStackNavigator();
  const Drawer=createDrawerNavigator();
 
  const Navigator = () => {
    const TOKEN=useSelector(state=>state.token);
   
      const STORE_VIEW=useSelector(state=>state.storeview);
      // const [storeview,setStoreView]=useState("");
      // const STORE_VIEW_REGISTER=useSelector(state=>state.storeview);
      // var store=null;
      //   if(STORE_VIEW=='London'){
      //     store='london_storeview';
      //   }else{
      //     store=STORE_VIEW;
      //   }
    console.log('My Store::::::::::::',STORE_VIEW);
    const client=new ApolloClient({
      uri:baseUrl,
      cache:new InMemoryCache(),
      headers:{
        authorization: TOKEN ? `Bearer ${TOKEN}` : "",
          store:'london_storeview' 
        }
    });
    console.log(baseUrl);
    return (
     <ApolloProvider client={client}> 
      <NavigationContainer>
        <Stack.Navigator initialRouteName='DrawerNavigation' screenOptions={{ orientation: 'portrait'}}>
          {/* <Stack.Screen name="SplashScreen" component={SwiperComponent} options={{ headerShown: false }} /> */}
          <Stack.Screen name="DrawerNavigation" component={DrawerNavigation} options={{ headerShown: false }} />
          {/* <Stack.Screen name="ProductPage" component={Product} options={{ headerShown: true }} /> */}
          <Stack.Screen name="Basket" component={Basket} options={{ headerShown: false }} />
          <Stack.Screen name="home" component={Block} options={{ headerShown: false }} />
          <Stack.Screen name="WishList" component={WishList} options={{ headerShown: false }} />
          <Stack.Screen name="MainDrawer" component={MainDrawerNavigation} options={{ headerShown: false }} />
        </Stack.Navigator>
      </NavigationContainer>
      </ApolloProvider>
    );
  };
    
export default Navigator;
