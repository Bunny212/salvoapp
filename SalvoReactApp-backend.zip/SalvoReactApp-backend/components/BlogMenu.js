import React from "react";
import { View,Text,TouchableOpacity,Image,Dimensions,ScrollView,TextInput,ActivityIndicator, TouchableHighlight } from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { gql, useQuery } from "@apollo/client";
import { FlatList } from "react-native-gesture-handler"
import { useState } from "react";
import { FlatGrid } from "react-native-super-grid";
import moment from "moment";

const BlogMenu = ({navigation,onPress}) => {
    const [color, setColor] = useState({});
    const [search,setSearch]=useState();
   
    const getBlogCategories=()=>{
        const GET_CATEGORIES=gql`
        {
            amBlogCategories {
              items {
                category_id
                created_at
                level
                meta_description
                meta_robots
                meta_tags
                meta_title
                name
                parent_id
                path
                post_count
                sort_order
                status
                store_id
                updated_at
                url_key
              }
            }
          }
        `;
        const { loading, error, data } = useQuery(GET_CATEGORIES);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        // console.log(':::::::::::::::::::::::::::::::',data.amBlogCategories.category_id);
        return data;
    }
    getBlogCategories();
        const getAllTags=()=>{
        const GET_TAGS=gql`
        {
            amBlogTagsWidget{
              items {
                meta_description
                meta_robots
                meta_tags
                meta_title
                name
                tag_id
                url_key
              }
            }
          }
        `;
        const { loading, error, data } = useQuery(GET_TAGS);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        // // console.log(':::::::::::::::::::::::::::::::',data);
        return data;
    }
    getAllTags();
    const getReadTime=(postDate)=>{
        let timePassed = moment(postDate).fromNow();
        return timePassed;
    }
    const getRecentPosts=()=>{
        const RECENT_POSTS=gql`
        {
            amBlogRecentPostsWidget {
              amasty_widget_categories
              amasty_widget_tags
              date_manner
              display_date
              display_short
              header_text
              items {
                author_id
                canonical_url
                categories
                comment_count
                comments_enabled
                created_at
                display_short_content
                full_content
                grid_class
                is_featured
                list_thumbnail
                list_thumbnail_alt
                meta_description
                meta_robots
                meta_tags
                meta_title
                notify_on_enable
                post_id
                post_thumbnail
                post_thumbnail_alt
                published_at
                related_post_ids
                short_content
                status
                title
                updated_at
                url_key
                user_define_publish
                views
              }
              posts_limit
              short_limit
              show_images
              title
            }
          }
        `;
        const { loading, error, data } = useQuery(RECENT_POSTS);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        console.log(data.amBlogRecentPostsWidget.items[0].views);  
        return data;
    }
    getRecentPosts();

    return(
        <>
        <View style={{padding:height*0.022,flex:1}}>
            <View style={styles.blogMenuTitle}>
                <Text style={styles.blogMenuTitleText}>Blog Menu</Text>
                <TouchableOpacity onPress={()=>{onPress()}}>
                    <Image source={require('../assets/icons/close.png')} 
                    style={styles.blogMenuCloseIcon}/>
                </TouchableOpacity>
            </View>
            <ScrollView>
            <View style={styles.blogMenuItemContainer}>
                <Collapse style={{}}>
                    <CollapseHeader>
                    <View style={[styles.accordinTitle,{borderBottomWidth:0}]}>
                        <Text style={styles.accordinTitleText}>Categories</Text>
                        <Image source={require('../assets/icons/down-arrow.png')} style={[styles.downArrow,{width:width*0.050,height:height*0.040}]}/>
                    </View>
                    </CollapseHeader>
                    <CollapseBody>
                    <View style={[styles.accordinInner,{borderBottomWidth:0}]}>
                        {/* {getBlogCategories()?.amBlogCategories?.items?.map((category)=>{
                            // console.log(category.category_id);
                            return(
                            <TouchableOpacity onPress={()=>{onPress();navigation.navigate('BlogsCategory',{brand_category_id:category.category_id,brand_category_name:category.name}); }}><Text style={styles.accordinInnerText}>{category.name} <Text style={{color:'#999DA3'}}>({category.post_count})</Text></Text></TouchableOpacity>
                            )
                        })} */}
                        <FlatList data={getBlogCategories()?.amBlogCategories?.items} renderItem={(category,index)=>{
                            return(
                                <TouchableOpacity style={{marginTop:height*0.010}} key={index} onPress={()=>{onPress();navigation.navigate('BlogsCategory',{brand_category_id:category.item.category_id,brand_category_name:category.item.name}); }}><Text style={styles.accordinInnerText}>{category.item.name} <Text style={{color:'#999DA3'}}>({category.item.post_count})</Text></Text></TouchableOpacity>
                            )
                        }}>
                            
                        </FlatList>
                      
                    </View>
                    </CollapseBody>
                </Collapse>
            </View>

            <View style={[styles.blogMenuItemContainer,{marginTop:height*0.030}]}>
                <Collapse style={{}}>
                    <CollapseHeader>
                    <View style={[styles.accordinTitle,{borderBottomWidth:0}]}>
                        <Text style={styles.accordinTitleText}>Search the blog</Text>
                        <Image source={require('../assets/icons/down-arrow.png')} style={[styles.downArrow,{width:width*0.050,height:height*0.040}]}/>
                    </View>
                    </CollapseHeader>
                    <CollapseBody>
                    <View style={[styles.accordinInner,{borderBottomWidth:0}]}>
                    <View style={{borderWidth:0.2,borderColor:'#999DA3',flexDirection:'row',alignItems:'center'}}>
                        <TextInput onChangeText={newSearch=>setSearch(newSearch)} placeholder="Find Some..." placeholderTextColor={'#999DA3'}
                        style={styles.blogMenuSearchBox}/>
                        <TouchableOpacity onPress={()=>{onPress(); navigation.navigate('BlogsSearch',{search:search})}}>
                        <Image source={require('../assets/icons/search.png')}
                        style={styles.blogMenuSearchIcon}/>
                        </TouchableOpacity>
                    </View>
                    </View>
                    </CollapseBody>
                </Collapse>
            </View>

            <View style={[styles.blogMenuItemContainer,{marginTop:height*0.030}]}>
                <Collapse style={{}}>
                    <CollapseHeader>
                    <View style={[styles.accordinTitle,{borderBottomWidth:0}]}>
                        <Text style={styles.accordinTitleText}>Tags</Text>
                        <Image source={require('../assets/icons/down-arrow.png')} style={[styles.downArrow,{width:width*0.050,height:height*0.040}]}/>
                    </View>
                    </CollapseHeader>
                    <CollapseBody>
                    <View style={[styles.accordinInner,{borderBottomWidth:0}]}>
                    {/* {getAllTags()?.amBlogTagsWidget?.items.map((tags)=>{
                        return(
                        <View style={{flexDirection:'row'}}>              
                            <TouchableHighlight
                                onPressIn={() => {setColor({id:tags.tag_id,text_color:'#fff',backgroundColor:'#000'})}}
                                onPressOut={() => {setColor({id:tags.tag_id,text_color:'#000',backgroundColor:'#F5F5F5'});}}
                                onPress={()=>{onPress();navigation.navigate('BlogsTags',{tag_id:tags?.tag_id,tag_name:tags?.name})}}
                            style={{
                            margin:height*0.006,
                                alignSelf: 'flex-start',
                            padding: height*0.012,
                            borderRadius: height*0.02,
                            alignItems: "center",
                            justifyContent: "center",
                            //   backgroundColor: "#F5F5F5",
                            backgroundColor:color.id==tags.tag_id?color.backgroundColor:'#F5F5F5',
                            }}
                        >
                            <Text
                          style={{ color:color.id==tags.tag_id?color.text_color:'#000'}}
                        >
                            {tags.name}
                        </Text>
                        </TouchableHighlight>
                    </View>
                        )
})} */}

<FlatGrid itemDimension={85} spacing={0.5} indicatorStyle={false} data={getAllTags()?.amBlogTagsWidget?.items} renderItem={(tags,index)=>{
                            return(
                                // <View style={{flexDirection:'row'}}>              
                                <TouchableHighlight
                                    onPressIn={() => {setColor({id:tags.item.tag_id,text_color:'#fff',backgroundColor:'#000'})}}
                                    onPressOut={() => {setColor({id:tags.item.tag_id,text_color:'#000',backgroundColor:'#F5F5F5'});}}
                                    onPress={()=>{onPress();navigation.navigate('BlogsTags',{tag_id:tags.item.tag_id,tag_name:tags.item.name})}}
                                style={{
                                margin:height*0.006,
                                    alignSelf: 'flex-start',
                                padding: height*0.010,
                                borderRadius: height*0.02,
                                alignItems: "center",
                                justifyContent: "center",
                                //   backgroundColor: "#F5F5F5",
                                backgroundColor:color.id==tags.item.tag_id?color.backgroundColor:'#F5F5F5',
                                }}
                            >
                                <Text
                              style={{ color:color.id==tags.item.tag_id?color.text_color:'#000'}}
                            >
                                {tags.item.name}
                            </Text>
                            </TouchableHighlight>
                        // </View>
                            )
                        }}>
                            
                        </FlatGrid>

                        {/* <View style={{flexDirection:'row'}}>
                            <TouchableOpacity><Text style={[styles.accordinInnerText,styles.blogMenuTag]}>San Benedetto</Text></TouchableOpacity>
                            <TouchableOpacity><Text style={[styles.accordinInnerText,styles.blogMenuTag]}>Burrata</Text></TouchableOpacity>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <TouchableOpacity><Text style={[styles.accordinInnerText,styles.blogMenuTag]}>Gnocchi</Text></TouchableOpacity>
                            <TouchableOpacity><Text style={[styles.accordinInnerText,styles.blogMenuTag]}>Mamma Emma</Text></TouchableOpacity>
                        </View> */}
                    </View>
                    </CollapseBody>
                </Collapse>
            </View>

            <View style={[styles.blogMenuItemContainer,{marginTop:height*0.030}]}>
                <View style={[styles.accordinTitle,{borderBottomWidth:0}]}>
                        <Text style={[styles.accordinTitleText,{fontWeight:'normal'}]}>Comments were not found</Text>
                </View>
            </View>

            <View style={[styles.blogMenuItemContainer,{marginTop:height*0.030}]}>
                <Collapse style={{}}>
                    <CollapseHeader>
                    <View style={[styles.accordinTitle,{borderBottomWidth:0}]}>
                        <Text style={styles.accordinTitleText}>{getRecentPosts()?.amBlogRecentPostsWidget?.header_text}</Text>
                        <Image source={require('../assets/icons/down-arrow.png')} style={[styles.downArrow,{width:width*0.050,height:height*0.040}]}/>
                    </View>
                    </CollapseHeader>
                    <CollapseBody>
                    {getRecentPosts()?.amBlogRecentPostsWidget?.items?.map((recent_post)=>{
                        return(
                        <View style={[styles.accordinInner,{borderBottomWidth:0}]}>
                                                <TouchableOpacity
                                                onPress={()=>{onPress();navigation.navigate('BlogPage',{post_id:recent_post.post_id,url_key:recent_post.url_key,
                                                    timePassed:getReadTime(recent_post.created_at),
                                                    views:recent_post   .views>1?  recent_post.views+' view(s)':recent_post.views==0? '':recent_post.views+'view',
                                                   })}}
                                                style={{justifyContent:'flex-start',width:'100%', marginLeft:height*0.010}}>
                                                <Image source={{uri:recent_post.post_thumbnail}}
                                                style={styles.blogMenuPostImg}/>
                                                </TouchableOpacity>
                                                <TouchableOpacity   onPress={()=>{onPress();navigation.navigate('BlogPage',{post_id:recent_post.post_id,url_key:recent_post.url_key,
                                                    timePassed:getReadTime(recent_post.created_at),
                                                    views:recent_post   .views>1?  recent_post.views+' view(s)':recent_post.views==0? '':recent_post.views+'view',
                                                   })}} style={styles.blogMenuPostTitle}><Text style={{color:'#000'}}>{recent_post.title}</Text></TouchableOpacity>
                                                <Text style={styles.blogMenuPostViews}>{recent_post.views>1?  recent_post.views+' view(s)':recent_post.views==0? '':recent_post.views+'view'}</Text>
                                            </View>
                        )
                    })}
                   
                    </CollapseBody>
                </Collapse>
            </View>

            </ScrollView>
        </View>
        </>
    )

}

export default BlogMenu;