import React, { useEffect } from "react";
import { View, Text, Dimensions } from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');

const SignOut = ({navigation}) => {

setTimeout(()=>{
    navigation.navigate('Default');
},5000)
    return(
        <>
        <View style={{padding:height*0.040}}>
            <Text style={styles.signoutText}>You are signed out</Text>
        </View>
        <View style={styles.signoutMessage}>
            <Text style={styles.signoutMessageText}>You have signed out and will go to our homepage in 5 seconds.</Text>
        </View>
        </>
    )
}

export default SignOut;