import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator} from "react-native";
import styles from "../styles/styles";

const { width, height } = Dimensions.get('window');
import React , { useEffect, useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch, useSelector } from "react-redux";
import CheckBox from "@react-native-community/checkbox";
import { gql, useMutation, useQuery } from "@apollo/client";

import { func } from "prop-types";
import { FlatGrid } from "react-native-super-grid";
import { CREATE_CART } from "./mutations/createCart";
import { ADD_TO_CART } from "./mutations/addToCart";
import { AddtoCart, CartIdSet, NumberofItems,setShippingMethods,setShippingValue,setSubTotal,setTotalPrice,TotalQuantity, WISH_LISTS } from "../components/redux/actions";

import CustomButton from '../components/list/ProductList'
import Modal from "react-native-modal";
import { setWishLists } from "./redux/actions";
import { DELETE_WISHLIST } from "./mutations/deleteWishlist";
import { UPDATE_PRODUCT } from "./mutations/updateProductInWishlist";
import { EDIT_NAME } from "./mutations/wishlistNameEdit";

const ViewLists = ({navigation,route}) => {
    const [load,setLoad]=useState(true);
    const TOKEN=useSelector(state=>state.token);
    const CUSTOMER=useSelector(state=>state.customer);
    const CUSTOMER_EMAIL=useSelector(state=>state.customer?.customer?.email);
    const [quantity,setQuantity]=useState(1);
    const units=[];
    const [displayMessage,setDisplayMessage]=useState(false);
    const dispatch=useDispatch();
    const [cartId,setCartId]=useState(null);
    const [newProductVisible, setNewProductVisible] = useState('none');
    const [wishlistId,setWishListId]=useState(null);
    const [fetchCartId]=useMutation(CREATE_CART);
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const [editable, setEditable] = useState(false);
    const [listName, setListName] = useState('');
    const createCart = async()=>{
        try{
          const{
            data,errors,
          }=await fetchCartId();
          setCartId(data.cartId);
          dispatch(CartIdSet(data.cartId));
        }catch(error){
          console.log(error);
          setDisplayServerErrorMsg(true);
          setServerErrorMsg(error.message);   
        }
      }
    console.log('MY WISHLIST',WISH_LISTS.wishList_id);
      const [addProductsToCart]=useMutation(ADD_TO_CART);
    const addToCart = async (sku,quantity) =>{
     
        try{   
          const{
            data,errors,
          }= await addProductsToCart({
              variables:{
                  cartId,
                  sku,
                  quantity
              }
          });
          // console.log('Minimum Order amount:::::::::::::::::::::',NAVISION_RESPONSE.minimum_order_value-data.addProductsToCart.cart.prices.grand_total.value)
          if(data!=undefined){
            // console.log('My Test:::::::::::::',data.addProductsToCart.cart.shipping_addresses[0].selected_shipping_method.amount.value)
          dispatch(TotalQuantity(data.addProductsToCart.cart.total_quantity));
          dispatch(NumberofItems(data.addProductsToCart.cart.items.length));
          dispatch(AddtoCart(data.addProductsToCart.cart.items));
          dispatch(setTotalPrice(data.addProductsToCart.cart.prices.grand_total.value));
          dispatch(setSubTotal(data.addProductsToCart.cart.prices.subtotal_excluding_tax.value))
          dispatch(setShippingValue(data.addProductsToCart.cart.shipping_addresses[0].selected_shipping_method.amount.value));
          setRemainingMinOrderValue(NAVISION_RESPONSE-data.addProductsToCart.cart.prices.grand_total.value.toFixed(2));
        setLoad(true);  
        }
          // console.log('hhhhhhhhhhh',NAVISION_RESPONSE)
          // console.log('Remaining sMinimum Order amount:::::::::::::::::::::',NAVISION_RESPONSE-data.addProductsToCart.cart.prices.grand_total.value)
         
        }catch(error){
          console.log(error);
          setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message);   
        }
      }
    const changeNewProductVisible = () =>{
        if(newProductVisible=='none'){
         setNewProductVisible('flex');
        }else{
         setNewProductVisible('none');
        }
    }
    const [sku,setSku]=useState({});
    const skus=[];
    const qty=[];
    const [productOptions, setProductOptions] = useState({sku:'',display:'none'});
    const productOptionsVisible = (sku) =>{
        if(productOptions.display=='none'){
         setProductOptions({sku:sku,display:'flex'});
        }else{
          setProductOptions({sku:sku,display:'none'});
        }
    }

    const [isDisabled, setIsDisabled] = useState(true);
    const [checked, setChecked] = useState(false);

    const canBeSubmitted = () => {
        return checked ? setIsDisabled(true) : setIsDisabled(false);
      };
    
      const onCheckboxClick = () => {
        setChecked(!checked);
        return canBeSubmitted();
      };

      useEffect(()=>{
       
        setTimeout(() => {
          setLoad(false);
      }, 12000);
      },[])
      const getUnit=()=>{
       
        const SALES_UNIT_OF_MEASURE=gql`
        {
          customAttributeMetadata(
            attributes: [
              {
                attribute_code: "sales_unit_of_measure"
                entity_type: "catalog_product"
              }
            ]
          ) {
            items {
              attribute_code
              attribute_type
              entity_type
              input_type
              attribute_options {
               value
               label
             }
            }
          }
        }
          `;
          const { loading, error, data } = useQuery(SALES_UNIT_OF_MEASURE);
          if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        // console.log(data.customAttributeMetadata.items[0].attribute_options);
        data?.customAttributeMetadata?.items[0]?.attribute_options.map((unit)=>{
          units.push(unit);
        })
      }
      getUnit();

      const [modalVisible, setModalVisible] = useState(false);

    function CustomModal(){
        return(
            <>
            <Modal
                transparent={true}
                visible={modalVisible}
                onBackdropPress={() => {
                setModalVisible(!modalVisible);
                }}
                >
              <View style={[styles.centeredView,{width:'100%'}]}>
                    <View style={{padding:height*0.026,backgroundColor:'#fff',shadowColor: "#000",shadowOffset: {width: 0,height: height*0.002},shadowOpacity: 0.25,shadowRadius: height*0.004,elevation: height*0.005}}>
                        <TouchableOpacity style={{right:width*0.050,position:'absolute',top:height*0.020}} onPress={() => { setModalVisible(false); }}>
                            <Image source={require('../assets/icons/close.png')} 
                                style={{width:width*0.040,height:height*0.040,resizeMode:'contain',tintColor:'#999DA3'}}/>
                        </TouchableOpacity>
                        <View style={{marginTop:height*0.040}}>
                            <Text style={{color:'#000',fontSize:height*0.020}}>Are you sure? This action can't be undone.</Text>
                        </View>
                        <View style={{marginTop:height*0.040,flexDirection:'row',justifyContent:'flex-end'}}>
                            <TouchableOpacity  onPress={() => { setModalVisible(false); }} style={{padding:height*0.010,backgroundColor:'#eee',borderRadius:height*0.004,borderWidth:0.4,borderColor:'#ccc',marginRight:width*0.020}}>
                                <Text style={{color:'#000',fontSize:height*0.020,fontWeight:'500'}}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={()=>{deleteWishlist(CUSTOMER_EMAIL,String(route.params.wishlist_id)),setModalVisible(!modalVisible)}} style={{padding:height*0.010,backgroundColor:'#317250',borderRadius:height*0.004,borderWidth:0.4,borderColor:'#ccc',width:width*0.16}}>
                                <Text style={{color:'#fff',fontSize:height*0.020,fontWeight:'500',textAlign:'center'}}>OK</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    </View>
                </Modal>
            </>
        )
    }

    const ProductOptions = ({sku,quantity,wishlist_id}) => {
        return(
            <View style={{width:width*0.35,backgroundColor:'#fff',borderRadius:height*0.006,padding:height*0.012, shadowOffset: {width: 0,
                height: height*0.002},
              shadowOpacity: 0.25,
              shadowRadius: height*0.004,
              elevation: height*0.003}}>
                <TouchableOpacity onPress={()=>{setProductOptions({sku:sku,display:'none'})}} style={{padding:height*0.004}}>
                    <Text style={{color:'#000'}}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>{setProductOptions({sku:sku,display:'none'})}} style={{padding:height*0.004}}>
                    <Text style={{color:'#000'}}>Copy</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>{setProductOptions({sku:sku,display:'none'})}} style={{padding:height*0.004}}>
                    <Text style={{color:'#000'}}>Move</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>{setProductOptions({sku:sku,display:'none'});}} style={{padding:height*0.004}}>
                    <Text style={{color:'#e02b27'}}>Delete</Text>
                </TouchableOpacity>
            </View>
        )
    }

    function SelectProduct () {    
        return(
            <>
                <View style={{padding:height*0.022,backgroundColor:'#fff',borderTopColor:'999DA3',borderTopWidth:0.4}}>
                <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}>
                    <TouchableOpacity onPress={onCheckboxClick}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>{checked? 'Unselect All' : 'Select All'}</Text>
                    </TouchableOpacity>
                    <View style={{flexDirection:'row'}}>
                        <TouchableOpacity disabled={isDisabled} style={{padding:height*0.012,borderWidth:0.2,borderRadius:height*0.005,marginRight:width*0.020,borderColor: checked ? '#4776f0' : '#999DA3'}}>
                            <Text style={[styles.otherOptions,{color: checked ? '#4776f0' : '#999DA3'}]}>Copy Selected</Text>
                        </TouchableOpacity>
                        <TouchableOpacity disabled={isDisabled} style={{padding:height*0.012,borderWidth:0.2,borderRadius:height*0.005,borderColor: checked ? '#4776f0' : '#999DA3'}}>
                            <Text style={[styles.otherOptions, {color: checked ? '#4776f0' : '#999DA3'}]}>Move Selected</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={{padding:height*0.010}}>
                    <TouchableOpacity style={{backgroundColor:'#317250',padding:height*0.014,alignItems:'center',borderRadius:height*0.005}}>
                        <Text style={styles.addToBasketText}>Add All to Cart</Text>
                    </TouchableOpacity>
                </View>
            </View>
            </>
        )
    }

  
    const GetProductSku=()=>{
      
      if(wishlistId==null){
        const GET_WISHLIST_PRODUCT=gql` query{AmastyMultiWishListView(
            customerEmail: "${CUSTOMER_EMAIL}"
            wishListId: "${route.params.wishlist_id}"
        ){
            output{
                wishlist_id
                product_id
                product_qty
                product_name
                product_sku
                product_price
            }
        }
        }`;
        const { loading, data, error} = useQuery(GET_WISHLIST_PRODUCT);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error</Text>;
      data.AmastyMultiWishListView.output.map((item)=>{
          skus.push(item.product_sku);
          qty.push(item.product_qty);
          console.log(item.product_qty);
      })
    }
    else{
      const GET_WISHLIST_PRODUCT=gql` query{AmastyMultiWishListView(
        customerEmail: "${CUSTOMER_EMAIL}"
        wishListId: "${wishlistId}"
    ){
        output{
            wishlist_id
            product_id
            product_qty
            product_name
            product_sku
            product_price
        }
    }
    }`;
    const { loading, data, error} = useQuery(GET_WISHLIST_PRODUCT);
if (loading) return <ActivityIndicator></ActivityIndicator>;
if (error) return <Text style={{color:'#000'}}>Error</Text>;
  data.AmastyMultiWishListView.output.map((item)=>{
      skus.push(item.product_sku);
      qty.push(item.product_qty);
      console.log(item.product_qty);
  })
    }
    }
    GetProductSku();
    const CustomButton=({data,quantity,item,index})=>{
        if(TOKEN==null){
          if(item.stock_status=="IN_STOCK"){
        return(
        <TouchableOpacity onPress={()=>navigation.navigate('Login')} style={styles.addProduct}>
        <Text numberOfLines={1} style={styles.loginTextButton}>Login/Create an Account</Text>
      </TouchableOpacity>
        )
          }else{
            return(
              <View style={styles.addProduct}>
              <Text style={styles.addProductText}>Out of Stock</Text>
            </View>
            )
          }
        }else{
          if(item.stock_status=="IN_STOCK"){
            return(
            <TouchableOpacity onPress={()=>{addToCart(data.products?.items[index].sku,quantity),setDisplayMessage(!displayMessage),createCart()}} style={styles.addProduct}>              
              <Text style={styles.addProductText}>Add to Basket</Text>
            </TouchableOpacity>
            )
          }else{
            return(
            <View style={styles.addProduct}>
            <Text style={styles.addProductText}>Out of Stock</Text>
          </View>
            )
          }
    
        }
      }
   


   const [amastyMultiWishListDelete]=useMutation(DELETE_WISHLIST);

    const deleteWishlist=async(email,wishlistId)=>{
        try {
            const{
                data,errors,
              }= await amastyMultiWishListDelete({
                  variables:{
                     email,
                     wishlistId
                  }
              });
              dispatch(setWishLists(data?.AmastyMultiWishListDelete?.wishlist_details));
              navigation.navigate('SavedLists');
        } catch (error) {
            console.log('errorrrrr',error);
            setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message);   
        }
    }
    if (displayServerError) {
      setTimeout(() => {
        setDisplayServerErrorMsg(false);
     }, 12000);
  }
  const [amastyMultiWishListNameEdit]=useMutation(EDIT_NAME);
  const EditListName=async (email,wishlist_id,wishlist_name)=>{
    try{   
      const{
        data,errors,
      }= await amastyMultiWishListNameEdit({
          variables:{
            email,
            wishlist_id,
            wishlist_name
          }
      });
      // EditListName(email,wishlist_id,wishlist_name);
      console.log(data.AmastyMultiWishListNameEdit.message);
      if(data.AmastyMultiWishListNameEdit.message!= wishlist_name+' already exists'){
        EditListName(email,wishlist_id,wishlist_name);
      }else{
        dispatch(setWishLists(data.AmastyMultiWishListNameEdit.wishlist_details));
        navigation.navigate('SavedLists');
      }
      
    }catch(error){
      console.log(error);
      setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message);   
    }
  //   if(wishlistId==null){
  // const EDIT_WISH_LIST_NAME = gql`
  // {
  //   AmastyMultiWishListNameEdit(
  //     customerEmail: "${CUSTOMER_EMAIL}", 
  //     wishlistId: "${route.params.wishlist_id}" wishlistName: "${listName}"
  //   ) {
  //     output
  //   }
  // }  
  // `;
  // const { loading, data, error} = useQuery(EDIT_WISH_LIST_NAME);
  // if (loading) return <ActivityIndicator></ActivityIndicator>;
  // if (error) return <Text style={{color:'#000'}}>Error</Text>;
  // console.log('AmastyMultiWishListNameEdittttttttttttttt',data);
  //     }
    } 
    
    const WISH_LIST_DETAILS = gql`
    query{
        products(
            filter: {
              sku:{in:[${skus}]}
              },
          )
           {
            sort_fields{
              options{
                label
              }
            }
            aggregations{
              attribute_code
              options{
                label
                value
              }
            }
            
              page_info{
              total_pages
            }
              items{
                sales_unit_of_measure
                brand_name
                stock_status
                is_frozen
                sku
                name
                stock_status
                small_image{
                  url
                }
               
                price_range{
                  maximum_price{
                    final_price{
                      value
                    }
                  }
                }
              }
          }
    }
    `;
    const { loading, data, error} = useQuery(WISH_LIST_DETAILS);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error</Text>;
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
            
            {displayMessage? <View style={{width:'100%'}}>
            <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
                <Image source={require('../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
                <View style={{}}>
                <Text style={{color:'#006400',fontSize:height*0.018}}>  You added {data?.products?.items[0]?.name} to your 
                    <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
                    <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> shopping cart.</Text></TouchableOpacity>
                </Text>
                </View>
            </View>
            </View> : null}
            {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
	<Text style={styles.serverError}>{serverError}</Text>  
</View>:<View></View>}

        </View>
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={[styles.myAccountMenuText,{fontWeight:'700'}]}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={{padding:height*0.022}}>
            <TouchableOpacity onPress={()=>{navigation.navigate('SavedLists');setWishListId(null);}} style={styles.backBtn}>
                <Image source={require('../assets/icons/back.png')}
                style={styles.backBtnIcon}/>
                <Text style={[styles.otherOptions,{color:'#999DA3'}]}> Back</Text>
            </TouchableOpacity>
        </View>

        <View style={styles.savedListContainer}>
            <View>
                <TextInput editable={editable} style={[styles.listName,{borderWidth:editable?0.9:0,borderColor:'#317250'}]} onChangeText={(newName) => setListName(newName)}>{route.params.wishlist_name}
                </TextInput>
                <Text style={styles.otherOptions}>{route.params.wishlist_items} items</Text>
            </View>
            <TouchableOpacity onPress={()=>{setEditable(!editable);}} style={{marginRight:width*0.040}}>
                {!editable?<Image source={require('../assets/icons/pen.png')}
                    style={styles.penIcon}/>:<TouchableOpacity onPress={()=>{setEditable(!editable);EditListName(CUSTOMER_EMAIL,route.params.wishlist_id,listName);}} style={{backgroundColor:'#317250',padding:height*0.020,borderRadius:height*0.004}}>
                      <Text style={{color:'#fff',fontSize:height*0.02,fontWeight:'500'}}>Save</Text>
                  </TouchableOpacity>}
            </TouchableOpacity>
        </View>
        {route.params.wishlist_name=='Wish List'?  <View style={[styles.savedListContainer,{justifyContent:'flex-end'}]}>
            <TouchableOpacity onPress={()=>{setWishListId(route.params.wishlist_id)}} style={{flexDirection:'row',alignItems:'center',marginRight:height*0.012}}>
                <Image source={require('../assets/icons/update.png')}
                style={[styles.listOptionIcon,{marginRight:height*0.005}]}/>
                <Text style={styles.listOptions}>Update List</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>navigation.navigate('ShareList')} style={{flexDirection:'row',alignItems:'center'}}>
                <Image source={require('../assets/icons/share.png')}
                style={[styles.listOptionIcon,{marginRight:height*0.005}]}/>
                <Text style={styles.listOptions}>Share List</Text>
            </TouchableOpacity>
            {/* onPress={()=>{deleteWishlist(CUSTOMER_EMAIL,String(route.params.wishlist_id))}} */}
            {/* <TouchableOpacity onPress={()=>{setModalVisible(!modalVisible)}} style={{flexDirection:'row',alignItems:'center'}}>
                <Image source={require('../assets/icons/bin.png')}
                style={[styles.listOptionIcon,{tintColor:'#e02b27'}]}/>
                <Text style={[styles.listOptions,{color:'#e02b27'}]}>Delete List</Text>
            </TouchableOpacity> */}

        </View>:
         <View style={[styles.savedListContainer,{justifyContent:'space-between'}]}>
         <TouchableOpacity onPress={()=>{setWishListId(route.params.wishlist_id)}} style={{flexDirection:'row',alignItems:'center'}}>
             <Image source={require('../assets/icons/update.png')}
           style={[styles.listOptionIcon,{marginRight:height*0.005}]}/>
             <Text style={styles.listOptions}>Update List</Text>
         </TouchableOpacity>

         <TouchableOpacity onPress={()=>navigation.navigate('ShareList')} style={{flexDirection:'row',alignItems:'center'}}>
             <Image source={require('../assets/icons/share.png')}
            style={[styles.listOptionIcon,{marginRight:height*0.005}]}/>
             <Text style={styles.listOptions}>Share List</Text>
         </TouchableOpacity>
         {/* onPress={()=>{deleteWishlist(CUSTOMER_EMAIL,String(route.params.wishlist_id))}} */}
         <TouchableOpacity onPress={()=>{setModalVisible(!modalVisible)}} style={{flexDirection:'row',alignItems:'center'}}>
             <Image source={require('../assets/icons/bin.png')}
             style={[styles.listOptionIcon,{tintColor:'#e02b27',marginRight:height*0.005}]}/>
             <Text style={[styles.listOptions,{color:'#e02b27'}]}>Delete List</Text>
         </TouchableOpacity>

     </View>}
       
        <CustomModal></CustomModal>
        <View style={{padding:height*0.022}}>
            <TouchableOpacity onPress={changeNewProductVisible} style={{width:width*0.4}}>
                <Text style={styles.addNewProduct}>Add New Products</Text>
            </TouchableOpacity>
        </View>
        <View style={[styles.accountInputField,{display:newProductVisible}]}>
            <View style={styles.searchProduct}>
            <TouchableOpacity>
            <Image source={require('../assets/icons/search.png')}
                style={styles.searchIcon}/>
            </TouchableOpacity>
                <TextInput placeholder="Search by SKU or Product Name" placeholderTextColor={'#999DA3'}
                 style={styles.searchProductInput}/>
            </View>
        </View>
       {route.params.wishlist_items==0?      <View style={[styles.accountInputField,{width:'100%'}]}>
        <View style={styles.defaultShipping}>
            <Image source={require('../assets/icons/danger.png')}
            style={[styles.dangerIcon,{marginLeft:width*0.020}]}/>
            <Text style={{color:'#6f4400',fontSize:height*0.018}}>  You have no items in your wish list</Text>
        </View>
      </View>
: <FlatGrid itemDimension={130} spacing={10} indicatorStyle={false} data={data.products?.items}
    renderItem={({index,item})=>(
        <>
      
      <View style={[styles.productContainer,{flex:1/data.products.items.length}]}>
                <View style={{flexDirection:'row',justifyContent:'space-between',marginTop:height*0.005}}>
                    <CheckBox style={styles.checkbox} tintColors={'#000'} value={checked} onValueChange={()=>{setChecked(!checked)}}/>
                    <TouchableOpacity onPress={()=>productOptionsVisible(item.sku)}>
                        <Image source={require('../assets/icons/dots.png')} style={{width:width*0.06,height:height*0.04,resizeMode:'contain',right:width*0.020}}/>
                    </TouchableOpacity>
                </View>
                <View  style={{display:productOptions.sku==item.sku? productOptions.display:'none',alignSelf:'center',position:'absolute',marginTop:height*0.010,zIndex:1}}>
                <ProductOptions sku={item.sku}/>
                </View>
                <View style={styles.productImage}>
    {load? <ActivityIndicator animating={load}></ActivityIndicator>:<Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:height*0.150,width:width*0.350}}></Image>}
  </View>
                <Text numberOfLines={1} style={[styles.productName,{marginTop:height*0.020}]}>
                {item.name}
                </Text>
                <View style={styles.priceContainer}>
                    <TextInput keyboardType='numeric' onChangeText={newQuantity=>setQuantity(newQuantity)} key={item} style={styles.input}>
                        {parseInt(qty[index])}
                    </TextInput>
                    <Text style={styles.productPrice}>£{item.price_range.maximum_price.final_price.value} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
                </View>
                <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
            </View>
  
        </>
    )}
    
    >
    </FlatGrid>}
       
        {/* <View style={{}}>
            <SelectProducts/>
        </View> */}
        </ScrollView>
        <View>
          {route.params.wishlist_items==0?
            <View></View>:<SelectProduct/>
          }
        </View>
        </>
    )
}

export default ViewLists;