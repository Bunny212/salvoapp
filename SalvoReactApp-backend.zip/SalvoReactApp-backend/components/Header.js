import { useMutation,gql, useQuery } from "@apollo/client";
import React,{useEffect, useState} from "react";
import { View, Text, StyleSheet, TouchableOpacity, Dimensions,Image,TextInput,ActivityIndicator, KeyboardAvoidingView, Platform, useWindowDimensions } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import styles from '../styles/styles';
import stylesIpad from '../styles/stylesIpad';
import Cart from "./CartStatus";
import { SIGN_OUT } from "./mutations/signOut";
import { CUSTOMER } from "./query/loggedInCustomer";
import { customerDetails } from "./redux/actions";
import Modal from "react-native-modal";
import DropDownPicker from "react-native-dropdown-picker";
import DropDown from "./DropDown";

const { width, height } = Dimensions.get('window')
const Header =  ({style,navigation,cartId}) =>{
     const [isLoggedIn, setIsLoggedIn] = useState(true);
     const ITEMS=useSelector(state=>state);
     const dispatch=useDispatch();
     const [search,setSearch]=useState("");
     const [searchBarVisible, setSearchBarVisible] = useState(false);
     const { loading, error, data } = useQuery(CUSTOMER);
     const [drawerActive, setDrawerActive]=useState(false);
     const [modalVisible, setModalVisible] = useState(false);
     const heightPad = useWindowDimensions().height;
     const widthPad = useWindowDimensions().width;
     const changeSearchBarVisible = () =>{
          if(searchBarVisible==false){
           setSearchBarVisible(true);
          }else{
           setSearchBarVisible(false);
          }
      }
      const [display,setDisplay]=useState('none');
     const action=()=>{
          if(ITEMS.token==null){
               navigation.navigate("Login");
          }else{
          //    SignOut();
               // getCustomer(data); 
               // navigation.navigate("MyAccount");
               if(display=='none'){
                    setDisplay('flex')
               }else{
                    setDisplay('none');
               }
             
          }
     }
     const onPress=()=>{
          setModalVisible(!modalVisible);
     }
     if(Platform.isPad){
          return(
               <View style={[stylesIpad.headerContainer,{height:heightPad*0.1}]}>
                    <TouchableOpacity onPress={()=>{navigation.openDrawer();setDrawerActive(!drawerActive)}} style={[styles.iconContainer,{left:widthPad*0.03,height:heightPad*0.02}]}>
                         <Image style={[stylesIpad.iconStyle,{ height:height*0.035,
                         width:width*0.035,}]} source={require('../assets/icons/menu.png')}></Image>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={()=>{navigation.navigate("Default");} } style={[stylesIpad.iconContainer,{left:widthPad*0.35,bottom:heightPad*0.003}]}>
                         <Image style={[stylesIpad.logoHeader,{  height:height*0.07,
                         width:width*0.21}]} source={require('../assets/images/salvo.png')}></Image>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={()=> {setModalVisible(true)}} style={[stylesIpad.iconContainer,{left:widthPad*0.67}]}>
                         <View style={[stylesIpad.counterItems,{ padding:heightPad*0.0022,
    width:widthPad*0.032,
    bottom:heightPad*0.020,
    right:widthPad*0.033,
    borderRadius:50,}]}><Text style={{color:'#fff',fontSize:height*0.015,textAlign:'center'}}>{ITEMS?.total_qty}</Text></View>
                         <Image style={[stylesIpad.iconStyle,{ height:height*0.040,
                         width:width*0.040}]} source={require('../assets/icons/shopping-cart.png')}></Image>
                    </TouchableOpacity>
                    <DropDown navigation={navigation} action={action} display={display}></DropDown>
                    <View style={{}}>
                         <Modal
                         visible={modalVisible}
                         avoidKeyboard={true}
                         onBackdropPress={() => {setModalVisible(false)}}
                         >
                         <View style={[stylesIpad.popupContainer,{zIndex:1,height:ITEMS?.items?.length==0? '30%': ITEMS?.items?.length==1? '40%': '56%'}]}>
                                   <Cart onPress={onPress} navigation={navigation} ITEMS={ITEMS}></Cart>
                         </View>
                         </Modal>
                    </View>
                    <TouchableOpacity onPress={()=> {action();}} style={[stylesIpad.iconContainer,{left:widthPad*0.55}]}>
                         <Image style={[stylesIpad.iconStyle,{ height:height*0.040,
                         width:width*0.040}]} source={require('../assets/icons/user.png')}></Image>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={()=>{changeSearchBarVisible()}} style={[stylesIpad.iconContainer,{left:widthPad*0.43}]}>
                         <Image style={[stylesIpad.iconStyle,{ height:height*0.040,
                         width:width*0.040}]} source={require('../assets/icons/search.png')}></Image>
                    </TouchableOpacity>
                    <View style={[stylesIpad.searchBarContainer,{display:searchBarVisible ? 'flex' : 'none'}]}>
                         <TextInput onChangeText={searchText=>setSearch(searchText)} returnKeyType='search' onSubmitEditing={()=>{navigation.navigate("SubProduct",{search:search}); setSearchBarVisible(false); setSearch('')}} placeholder=" Find a product..." 
                         style={[stylesIpad.searchBarInput,{ fontSize:heightPad*0.018,
                              left:'15%',
                              padding:height*0.017,
                              borderWidth:0.8,
                              borderRadius:height*0.008,marginTop:'25%'}]} placeholderTextColor={'#999DA3'}/>
                    </View>
              </View>
               
              );
     }else{
    return(
     <>
     <View style={styles.headerContainer}>
     <TouchableOpacity onPress={()=>{navigation.openDrawer();setDrawerActive(!drawerActive)}} style={[styles.iconContainer,{left:width*0.04}]}>
         <Image style={styles.iconStyle} source={require('../assets/icons/menu.png')}></Image>
    </TouchableOpacity>
    <TouchableOpacity onPress={()=>{navigation.navigate("Default");} } style={[styles.iconContainer,{left:width*0.3,bottom:height*0.006}]}>
         <Image style={styles.logoHeader} source={require('../assets/images/salvo.png')}></Image>
    </TouchableOpacity>
    <TouchableOpacity onPress={()=> {setModalVisible(true)}} style={[styles.iconContainer,{left:width*0.63}]}>
         <View style={styles.counterItems}><Text style={{color:'#fff',fontSize:width<600?height*0.015:height*0.018,textAlign:'center'}}>{ITEMS?.total_qty}</Text></View>
         <Image style={styles.iconStyle} source={require('../assets/icons/shopping-cart.png')}></Image>
    </TouchableOpacity>
     <DropDown navigation={navigation} action={action} display={display}></DropDown>
     <View style={{}}>
          <Modal
          visible={modalVisible}
          avoidKeyboard={true}
          onBackdropPress={() => {setModalVisible(false)}}
          >
          <View style={[styles.popupContainer,{zIndex:1,height:ITEMS?.items?.length==0? '30%': ITEMS?.items?.length==1? '40%': '56%'}]}>
                    <Cart onPress={onPress} navigation={navigation} ITEMS={ITEMS}></Cart>
          </View>
          </Modal>
     </View>

    <TouchableOpacity onPress={()=> {action();}} style={[styles.iconContainer,{left:width*0.45}]}>
    {/* <TouchableOpacity onPress={()=> isLoggedIn? navigation.navigate('Login'): navigation.navigate('SignOut')} style={[styles.iconContainer,{left:width*0.455}]}> */}
         <Image style={styles.iconStyle} source={require('../assets/icons/user.png')}></Image>
    </TouchableOpacity>
    <TouchableOpacity onPress={()=>{changeSearchBarVisible()}} style={[styles.iconContainer,{left:width*0.28}]}>
         <Image style={styles.iconStyle} source={require('../assets/icons/search.png')}></Image>
    </TouchableOpacity>
     </View>

     <View style={[styles.searchBarContainer,{display:searchBarVisible ? 'flex' : 'none'}]}>
          <TextInput onChangeText={searchText=>setSearch(searchText)} returnKeyType='search' onSubmitEditing={()=>{navigation.navigate("SubProduct",{search:search}); setSearchBarVisible(false); setSearch('')}} placeholder=" Find a product..." 
          style={styles.searchBarInput} placeholderTextColor={'#999DA3'}/>
     </View>

 </>
    );
}
}
export default Header;