import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal,ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useEffect, useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { gql, useMutation, useQuery } from "@apollo/client";
import { CUSTOMER } from "./query/loggedInCustomer";
import { COUNTRIES } from "./query/countriesList";
import { shallowEqual, useDispatch, useSelector } from "react-redux";
import { customerDetails } from "./redux/actions";
import { CUSTOMER_ADDRESS } from "./mutations/createCustomerAddress";


const MyAccount = ({navigation,route}) => {
        
        // const TOKEN=useSelector(state=>state.token);
        // const [SetCustomerAddress]=useMutation(CUSTOMER_ADDRESS);
        const CUSTOMER_DETAILS=useSelector(state=>state?.customer);
        const [displayMessage, setDisplayMessage] = useState('flex');
    // if(route?.params?.email){
    //     setDisplayMessage('flex')
    // }
    // else {
    //     setTimeout(() => {
    //       setDisplayMessage('none');
    //     }, 6000);
    // }

 
    
        const COUNTRY= gql`
        {
            country(id: "${CUSTOMER_DETAILS?.customer?.addresses[0]?.country_code}") {
            full_name_english
            full_name_locale
            id
            three_letter_abbreviation
            two_letter_abbreviation
          }
        }
          `;
          const { loading, error, data } = useQuery(COUNTRY);
          if (loading) return <View style={{alignItems:'center',justifyContent:'center'}}><ActivityIndicator></ActivityIndicator></View>;
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>My Account</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER_DETAILS?.customer?.email}</Text>
        </View>

        {/* {displayMessage=='flex'?<View><AccountInfoSuccess></AccountInfoSuccess></View>:<View></View>} */}

        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                    <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                    <View style={{}}>
                        <TouchableOpacity style={{padding:height*0.016}}><Text style={[styles.myAccountMenuText,{fontWeight:'700'}]}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Contact Information</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{CUSTOMER_DETAILS?.customer?.firstname} {CUSTOMER_DETAILS?.customer?.lastname}</Text>
                <Text style={styles.otherOptions}>{CUSTOMER_DETAILS?.customer?.email}</Text>
                <View style={{flexDirection:'row'}}>
                    <TouchableOpacity onPress={()=>navigation.navigate('EditAccount')}><Text style={[styles.otherOptions,{marginTop:height*0.006}]}>Edit</Text></TouchableOpacity>
                    <Text style={[styles.otherOptions,{marginTop:height*0.006}]}>   |   </Text>
                    <TouchableOpacity onPress={()=>navigation.navigate('ChangePassword')}><Text style={[styles.otherOptions,{marginTop:height*0.006}]}>Change Password</Text></TouchableOpacity>
                </View>
            </View>
        </View>
        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Newsletters</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>You aren't subscribed to our newsletter.</Text>
                <TouchableOpacity style={{width:width*0.16}} onPress={()=>navigation.navigate('Newsletter')}><Text style={[styles.otherOptions,{marginTop:height*0.006}]}>Edit</Text></TouchableOpacity>
                <View style={styles.addressBook}>
                    <Text style={styles.addressBookText}>Address Book</Text>
                    <TouchableOpacity onPress={()=>navigation.navigate('ManageAddress')}><Text style={[styles.otherOptions,{marginTop:height*0.006}]}>Manage Addresses</Text></TouchableOpacity>
                </View>
            </View>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Shipping Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            {CUSTOMER_DETAILS?.customer?.addresses?.length==0? <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>You have not set a default shipping address.</Text>
            </View>: <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{CUSTOMER_DETAILS?.customer?.firstname} {CUSTOMER_DETAILS?.customer?.lastname} </Text>
                <Text style={styles.otherOptions}>{CUSTOMER_DETAILS?.customer?.addresses[0]?.company}</Text>
                <Text style={styles.otherOptions}>{CUSTOMER_DETAILS?.customer?.addresses[0]?.street}</Text>
                <Text style={styles.otherOptions}>{CUSTOMER_DETAILS?.customer?.addresses[0]?.city}, {CUSTOMER_DETAILS?.customer?.addresses[0]?.region?.region}{CUSTOMER_DETAILS?.customer?.addresses[0]?.postcode}</Text>
                <Text style={styles.otherOptions}>{data?.country?.full_name_english}</Text>
                <Text style={styles.otherOptions}>T: {CUSTOMER_DETAILS?.customer?.addresses[0]?.telephone}</Text>
            </View>}
            <TouchableOpacity style={{marginTop:height*0.010}} onPress={()=>navigation.navigate('EditAddress')}><Text style={styles.otherOptions}>Edit Address</Text></TouchableOpacity>
           
        </View>

        {/* <View style={{padding:height*0.022}}>
            <View style={styles.promoBanner}>
                <Text style={styles.promoBannerText}>Promo Banner/Announcement</Text>
            </View>
        </View> */}
        </ScrollView>
        </>
    )
}
       
export default MyAccount;