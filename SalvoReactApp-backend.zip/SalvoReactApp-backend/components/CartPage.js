import { View,Image, Text, TouchableOpacity,TextInput,Dimensions,ActivityIndicator, BackHandler, Platform, useWindowDimensions } from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import DropDownPicker from 'react-native-dropdown-picker';
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import React , { useState, useRef } from "react";
import RadioButtonRN from 'radio-buttons-react-native';
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch, useSelector } from "react-redux";
import { useMutation,gql,useQuery } from "@apollo/client";
import { UPDATE_CART } from "./mutations/updateCart";
import { AddtoCart,ITEMS,NumberofItems,setOrderDateOfProccessingOrders,setOrderIdOfProccessingOrders,setShippingValue,setSubTotal,setTotalPrice,TotalQuantity } from "./redux/actions";
import { DELETE_ITEM } from "./mutations/deleteItem";
import { REWARD_POINTS } from "./mutations/useRewardPoints";
import { useEffect } from "react";
import { COUNTRIES } from "./query/countriesList";
import moment from "moment";
import stylesIpad from "../styles/stylesIpad";
const CartPage = ({navigation}) =>{
    const heightPad = useWindowDimensions().height;
    const widthPad = useWindowDimensions().width;
    const [open, setOpen] = useState(false);
    const [rewardPoints,setRewardPoints]=useState();
    const [points,setMyPoints]=useState(0);
    const [value, setValue] = useState(null);
    // const [items, setItems] = useState([
        // {label: 'A', value: 'a'},
    //     {label: 'B', value: 'b'},
    //     {label: 'C', value: 'c'},
    //     {label: 'D', value: 'd'},
    // ]);
    const order=[];
    const dispatch=useDispatch();
    const [open3, setOpen3] = useState(false);
    const [value3, setValue3] = useState(null);
    const [country, setCountry] = useState([
        {label: 'London', value: 'london'},
        {label: 'Manchester', value: 'manchester'}
    ]);

    const ShippingMethod = [
        {
        label: 'Shipping Method'
        }
    ];
   const [parentOrderId,setParentOrderId]=useState(null);
   const [orderDate,setOrderDate]=useState(null);
   const [addOrderId,setOrderId]=useState(null);
    const [displayAddToOrder,setDisplayAddToOrder]=useState(false);
    const [province, setProvince] = useState('');
    const scrollViewRef = useRef(null);
    const [zipCode, setZipCode] = useState('');
    // const [quantity,setQuantity]=useState([{}]);
    const quantity=[];
    const [quantity1,setQuantity]=useState({});
    // const [quantity,setQuantity]=useState({});
    const PRODUCT=useSelector(state=>state);
    const CART_ID=useSelector(state=>state.cartId);
    const SHIPPING_VALUE=useSelector(state=>state.shippingValue);
    const [updateCartItems]=useMutation(UPDATE_CART);
    const [removeItemFromCart]=useMutation(DELETE_ITEM);
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
   
    const updateCart =async (cartId,uid,quantity)=>{
        console.log('TEST:::::::::::::::::::',cartId);
        console.log('TEST:::::::::::::::::::',uid);
        console.log('TEST:::::::::::::::::::',quantity);
        if(uid.length!=0 && quantity.length!=0){
        try{
            const {error,data}=await updateCartItems({
                variables:{
                    cartId,
                    uid,
                    quantity
                }
            });
            dispatch(AddtoCart(data?.updateCartItems?.cart?.items));
            dispatch(NumberofItems(data?.updateCartItems?.cart?.items?.length));
            dispatch(TotalQuantity(data?.updateCartItems?.cart?.total_quantity));
            dispatch(setTotalPrice(data.updateCartItems.cart.prices.grand_total.value));
            dispatch(setSubTotal(data.updateCartItems.cart.prices.subtotal_excluding_tax.value));
            // dispatch(setShippingValue(data.updateCartItems.cart.shipping_addresses[0].selected_shipping_method.amount.value));
        }catch(error){
            console.log(error);
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);    
        }
    }
    }
    const deleteItem =async (cartId,uid)=>{
        try{
            const {error,data}=await removeItemFromCart({
                variables:{
                    cartId,
                    uid
                }
            });
            dispatch(AddtoCart(data?.removeItemFromCart?.cart?.items));
            dispatch(NumberofItems(data?.removeItemFromCart?.cart?.items?.length));
            dispatch(TotalQuantity(data?.removeItemFromCart?.cart?.total_quantity));
            dispatch(setTotalPrice(data.removeItemFromCart.cart.prices.grand_total.value));
            dispatch(setSubTotal(data?.removeItemFromCart.cart.prices.subtotal_excluding_tax.value))
            dispatch(setShippingValue(data?.removeItemFromCart?.cart?.shipping_addresses[0]?.selected_shipping_method?.amount?.value));
            console.log('Delete:::::::::::::::::;',data?.removeItemFromCart.cart.prices.subtotal_excluding_tax.value)

        }catch(error){
            console.log(error);
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);    
        }
    }
    const [useRewardPoints]=useMutation(REWARD_POINTS);
const applyRewardPoints=async(cartId,points)=>{
    try{
        const{
            data,errors,
          }= await useRewardPoints({
              variables:{
                  cartId,
                  points
              }
          });
          console.log('Order :::::::::::::::::::',data);
    }catch(error){
        console.log('::::::::',error);
        setDisplayServerErrorMsg(true);
        setServerErrorMsg(error.message);
    }
}
    // const updateData=()=>{
    //     {PRODUCT?.items?.map((item)=>{
    //         if(item.uid==quantity.uid){
    //             updateCart(PRODUCT?.cartId,item?.uid,quantity?.quantity);
    //             scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });
    //         }
    //     })}
    // }
    const deleteData=(uid)=>{
        {PRODUCT?.items?.map((item)=>{
            if(item.uid==uid){
                console.log('CSRTD::::::::::::::::::',PRODUCT);
              deleteItem(PRODUCT.cartId,item.uid);
            }
        })}
    }

    const [displayMessage,setDisplayMessage]=useState(false);  
    const NAVISION_RESPONSE=useSelector(state=>state.customer?.customer?.minimum_order_amount);
    function getOrders(){
        const ORDERS=gql`
        query {
            customer {
              orders(
                pageSize:100
                filter:{
                  status: {eq:"processing"}
                }
              ) {
                total_count
                items {
                  id
                  increment_id
                  order_date
                  amasty_delivery_date{
                    date
                  }
                  status
                  shipping_method
                  payment_methods {
                    name
                  }
                  total {
                    grand_total {
                      value
                      currency
                    }
                  }
                }
              }
            }
          }`;
          const {loading,error,data}=useQuery(ORDERS);
          if (loading) return <ActivityIndicator></ActivityIndicator>;
          if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
          data?.customer?.orders?.items.map((orders)=>{
            console.log(orders.amasty_delivery_date.date,'gggg', Date())
            if(moment(orders.amasty_delivery_date.date).format('MM/DD/YYYY')>moment(new Date()).format('MM/DD/YYYY')){
                if(moment(orders.amasty_delivery_date.date).format('DD/MM/YYYY')!='Invalid date'){
            order.push(    {label: 'Order #'+`${orders.increment_id}`+' for £'+`${orders.total.grand_total.value}`+' being delievered on '+`${moment(orders.amasty_delivery_date.date).format('DD/MM/YYYY')}`, value: orders.increment_id,date:moment(orders.amasty_delivery_date.date).format('MM/DD/YYYY')});
                }    
            }
          })
         
    }
getOrders();

const getSelectedOrder=(value)=>{
    setParentOrderId(value.value);
    setOrderDate(value.date)
}


const addToThisOrder=()=>{
//   setOrderId(parentOrderId);
  setDisplayAddToOrder(true);
  dispatch(setOrderDateOfProccessingOrders(moment(orderDate).format('MM/DD/YYYY')));
  dispatch(setOrderIdOfProccessingOrders(parentOrderId));  
}


 const Items=()=>{
    const SHIPPING_METHODS=gql`{  
        customerCart {
             shipping_addresses {
              
      available_shipping_methods {
        amount {
          currency
          value
        }
        available
        carrier_code
        carrier_title
        method_code
        method_title
        price_excl_tax {
          value
          currency
        }
        price_incl_tax {
          value
          currency
        }
      }
      selected_shipping_method {
        amount {
          value
          currency
        }
        carrier_code
        carrier_title
        method_code
        method_title
        
      }
    }
    available_payment_methods{
        code
      }
          prices{
            subtotal_excluding_tax{
                value
              }
            grand_total{
              value
            }
          }
        }
        
            rewards {
              balance
            }
          
}`;

function handleBackButtonClick() {
    navigation.navigate('Default');
    return true;
  }
  useEffect(() => {

    BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
    return () => {
      BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
    };
  }, []);

function MinimumOrderWarning () {
    return(
      <>
      <View style={{flexDirection:'row',padding:height*0.02,backgroundColor:'#fdf0d5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../assets/icons/danger.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <Text style={{color:'#6f4400',fontSize:height*0.018,marginLeft:width*0.024}}>
            Minimum order value for delivery is £{NAVISION_RESPONSE} (excluding VAT) please add £{NAVISION_RESPONSE-data?.customerCart?.prices?.grand_total?.value} to your basket.
        </Text>
      </View>
      </>
    )
  }


  if (displayMessage) {
    setTimeout(() => {
      setDisplayMessage(!displayMessage)
    }, 12000);
  }
  if (displayServerError) {
    setTimeout(() => {
      setDisplayServerErrorMsg(false);
    }, 12000);
  }


  const country=[];
  function getCountries(){
      const { loading, error, data } = useQuery(COUNTRIES);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
  if(data!=undefined){
  {data?.countries?.map((name)=>{
      country.push({label: name.full_name_english, value: name.id});
  })}
  }
  }
  getCountries();
  const setQuantityArray=()=>{
    PRODUCT.items.map((items)=>{
        quantity.push({sku:items.product.sku,qty:items.quantity})
    })
    console.log(quantity[0]);
}
    setQuantityArray();
    const [inputs, setInputs] = useState([{ value: '' }, { value: '' }]);
const { loading, error, data } = useQuery(SHIPPING_METHODS);
if (loading) return <ActivityIndicator></ActivityIndicator>;
if (error) return <Text style={{color:'#000'}}>Error :(</Text>;

    if(Platform.isPad){
        if(PRODUCT.total_qty>0){
            return(
                <View style={{height:'100%'}}>
                      {displayMessage && PRODUCT?.total_qty<=1?<View><MinimumOrderWarning/></View>:null}
            {displayServerError==true?<View style={{paddingHorizontal:heightPad*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}
            <View style={{flexDirection:'row'}}>
                <View style={{width:'50%',padding:'1%'}}>
                        {order.length==0?<View></View>:<View>
                    <Text style={{marginTop:'5%',fontSize:heightPad*0.020,color:'#000'}}>
                        Would you like to add to an existing order?
                    </Text>
                    <Text style={{marginTop:'1%',fontSize:heightPad*0.015,color:'#000',lineHeight:heightPad*0.026}}>
                        You can add items to an existing order up to 12pm the day before delivery. Simply select an order 
                        below and confirm by clicking the "Add to this order" button below.
                    </Text>
                    <Text style={{marginTop:'5%',fontSize:heightPad*0.015,color:'#000',lineHeight:heightPad*0.026}}>
                        Adding items to an existing order will remove the minimum order requirement.
                    </Text>
                    <View style={{zIndex:1}}>
                        <DropDownPicker
                            // placeholder="Order #000000000 for £price.00 being delievered on YYYY/MON/DD"
                            placeholder={order[0]?.label}
                            placeholderStyle={{fontSize:heightPad*0.015}}
                            dropDownContainerStyle={stylesIpad.dropdownContainerStyle}
                            style={[stylesIpad.dropdownStyle,{backgroundColor:'#fff',borderRadius:heightPad*0.005}]}     
                            containerStyle={[stylesIpad.filterButtonContainerStyle,{marginTop:'2%',width:'100%',}]}
                            open={open}
                            value={value}
                            items={order}
                            setOpen={setOpen}
                            setValue={setValue}
                            listMode='MODAL'
                            onSelectItem={(value)=>getSelectedOrder(value)}
                        />
                    </View>
                    <View style={{marginTop:'5%'}}>
                        <TouchableOpacity onPress={()=>{addToThisOrder()}} style={[stylesIpad.summaryButton,{width:'45%',borderRadius:heightPad*0.005}]}>
                            <Text style={[stylesIpad.summaryButtonText,{fontSize:heightPad*0.015}]}>{displayAddToOrder==false?'Add to this Order':'Confirm'}</Text>
                        </TouchableOpacity>
                    </View>
                    </View>}
                    <Text style={{marginTop:'4%',fontSize:height*0.015,color:'#ca2426',fontWeight:'600'}}>
                        Salvo can only deliver to business addresses so please ensure the address on your acount is 
                        a valid registered business address.
                    </Text>
                    <Text style={{fontSize:height*0.015,color:'#ca2426',fontWeight:'600'}}>
                        Please contact us if your address is incorrect as otherwise your order may not be processed.
                    </Text>
                </View>

                <View style={{width:'50%',backgroundColor:'#f5f5f5',marginTop:'2.5%',padding:'2%'}}>
                        <View style={[stylesIpad.summaryContainer,{paddingHorizontal:'1%',backgroundColor:'#f5f5f5'}]}>
                        <Text style={[stylesIpad.summaryTitle,{fontSize:heightPad*0.022}]}>Summary</Text>
                        {/* <Text style={[styles.cartDesc,{marginTop:height*0.010,fontWeight:'500'}]}>You can earn 50 Reward Points for completing your purchase!</Text> */}
                        {/* <View style={[styles.summarySaperator,{marginTop:height*0.020}]}></View> */}
                    
                            <View style={[stylesIpad.shippingPriceContainer,{padding:0}]}>
                                <Text style={[stylesIpad.shippingPrice,{fontSize:heightPad*0.018}]}>Subtotal</Text>
                                <Text style={[stylesIpad.shippingPrice,{fontSize:heightPad*0.018}]}>£ {PRODUCT.subTotal==0? data?.customerCart?.prices?.subtotal_excluding_tax?.value:PRODUCT.subTotal}</Text>
                            </View>
                            {/* {console.log(data.customerCart.shipping_addresses[0].available_shipping_methods[0].amount.value)} */}
                            {data?.customerCart?.shipping_addresses?.map((shipping)=>{
                                console.log('::::::::::::::::',SHIPPING_VALUE);
                                return(                   
                                        <View style={stylesIpad.shippingPriceContainer}>
                                            {shipping?.available_shipping_methods?.map((method)=>{
                                                return(
                                                    <>
                                                    <Text style={[stylesIpad.shippingPrice,{fontSize:heightPad*0.018}]}>Shipping ({method.carrier_title} - {method.method_title})</Text>
                                                    
                                                    <Text style={[stylesIpad.shippingPrice,{fontSize:heightPad*0.018}]}>£ {SHIPPING_VALUE==undefined?0 :SHIPPING_VALUE}</Text>
                                                    </>
                                                )
                                            })}
                                    
                                    </View>
                                )
                            })}
                        
                        <View style={[stylesIpad.summarySaperator,{marginTop:'4%'}]}></View>
                        <View style={{marginTop:'4%'}}>
                            <View style={stylesIpad.shippingPriceContainer}>
                                <Text style={[stylesIpad.shippingPrice,{fontWeight:'bold',fontSize:heightPad*0.018}]}>Order Total</Text>
                                <Text style={[styles.shippingPrice,{fontWeight:'bold',fontSize:heightPad*0.018}]}>£ {parseFloat(PRODUCT.total_price).toFixed(2)}</Text>
                            </View>
                            <Text style={stylesIpad.rewardAmount}>Enter discount code</Text>
                        <View style={[stylesIpad.applyDiscount,{width:'100%',marginTop:'5%'}]}> 
                            <TextInput placeholder="Enter discount code" placeholderTextColor={'#000'} keyboardType={'numeric'} style={{fontSize:height*0.018}} />
                            <TouchableOpacity style={[stylesIpad.summaryButton,{width:'45%'}]}>

                                <Text style={[stylesIpad.summaryButtonText,{fontSize:heightPad*0.015}]}>Apply Discount</Text>
                            </TouchableOpacity>
                        </View>
                        </View>
                        </View>

                        
                        <View style={{marginTop:'10%',padding:'2%'}}>
                            <Text style={{color:'#000',fontSize:height*0.018}}>You Have {data.rewards.balance} points left</Text>
                            <Text style={{color:'#000',fontSize:height*0.018}}>10 for every 1GBP</Text>

                            <Text style={stylesIpad.rewardAmount}>Enter Reward Amount</Text>
                            <View style={[stylesIpad.applyDiscount,{width:'100%',marginTop:'5%'}]}> 
                                <TextInput value={rewardPoints} placeholderTextColor={'#000'} onChangeText={(newPoint)=>setRewardPoints(newPoint)} keyboardType={'numeric'} style={{color:'#000'}}/>
                                <TouchableOpacity onPress={()=>applyRewardPoints(CART_ID,rewardPoints)} style={[stylesIpad.summaryButton,{width:'40%'}]}>
                                    <Text style={[stylesIpad.summaryButtonText,{fontSize:height*0.015}]}>Apply</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                        <View style={{marginTop:'10%',padding:'2%'}}>
                            <TouchableOpacity onPress={()=>{PRODUCT?.total_price>NAVISION_RESPONSE?navigation.navigate('CheckoutPage',{rewardPoints:data.rewards.balance,order_date:orderDate!=null?orderDate:null,cart_subtotal:data?.customerCart?.prices?.subtotal_excluding_tax?.value,cart_shipping:data?.customerCart?.shipping_addresses[0]?.available_shipping_methods[0]?.amount?.value}):setDisplayMessage(!displayMessage);}} 
                            style={[stylesIpad.summaryButton,{width:'100%',padding:'5%'}]}>
                                    <Text style={[stylesIpad.proceedCheckout,{fontSize:height*0.015, fontWeight:'500'}]}>Proceed to Checkout</Text>
                            </TouchableOpacity> 
                        </View>
                    </View>
                </View>
                <Text style={[stylesIpad.cartTitle,{fontSize:heightPad*0.020,fontWeight:'600'}]}>Current Cart Items</Text>
                <ScrollView>
                {PRODUCT?.items?.map((items,index)=>{
                console.log(items);
                 return(

    <View key={items} style={{borderBottomWidth:0.8,padding:'1%',flexDirection:'row',alignItems:'center',maxWidth:'100%'}}>
            <Text style={[stylesIpad.prodInfo,{fontSize:heightPad*0.015}]}>{items.product.sku}</Text>
            <TouchableOpacity style={{width:'43%'}} onPress={()=>navigation.navigate('ProductPage',{sku:`"${items.product.sku}"`,uid:items.uid})}>
                <Text style={[stylesIpad.prodInfo,{fontSize:heightPad*0.015,marginLeft:'5%',width:'100%'}]}>{items.product.name}</Text>
            </TouchableOpacity>
               <Text style={[stylesIpad.prodQtyText,{fontSize:heightPad*0.015,marginLeft:'15%'}]}>Qty</Text>
               {/* <TextInput keyboardType='numeric' style={styles.prodQtyInput} onChangeText={newQuantity=>setQuantity({quantity:newQuantity,index:index,uid:items.uid})}>{items.quantity}</TextInput> */}
                              {/* <TextInput keyboardType='numeric' style={styles.prodQtyInput} placeholder={PRODUCT.items[index].uid==quantity1.uid?quantity1.quantity:String(items.quantity)} placeholderTextColor={"#000000"} 
                              onEndEditing={(e) => {setQuantity({uid:items.uid,quantity:e.nativeEvent.text});updateCart(PRODUCT.cartId,items.uid,e.nativeEvent.text);}}></TextInput> */}

                    <TextInput key={index} keyboardType='numeric' style={[stylesIpad.prodQtyInput,{height:'20%',width:'5%',marginLeft:'1%'}]} placeholderTextColor={"#000000"} 
                                 onChangeText={text=>setInputs(
                                PRODUCT?.items?.map((input, i) =>
                                  i === index ? { ...input, quantity: text } : input
                                
                              ))}>{items.quantity}</TextInput>             
               <Text style={[stylesIpad.priceInfo,{fontSize:heightPad*0.015,left:'40%'}]}>£ {parseFloat(items.product.price_range.maximum_price.final_price.value).toFixed(2)}</Text>
          
          
           <TouchableOpacity style={{left:'80%'}} onPress={()=>navigation.navigate('ProductPage',{sku:`"${items.product.sku}"`,uid:items.uid})}>
               <Image source={require('../assets/icons/edit.png')} 
               style={[stylesIpad.updateIcon,{width:widthPad*0.035,
                height:heightPad*0.035}]}/>
           </TouchableOpacity>
           <TouchableOpacity style={{left:'130%'}} onPress={()=>{deleteData(items.uid)}}>
               <Image source={require('../assets/icons/bin.png')} 
                 style={[stylesIpad.updateIcon,{width:widthPad*0.035,
                    height:heightPad*0.035}]}/>
           </TouchableOpacity>
            </View>
                )
            })}
            </ScrollView>
                </View>
            )
        }else{
            return(
                <View style={{alignItems:'center',width:'100%'}}>
                <Text style={{marginTop:'5%',color:'#000',fontSize:height*0.020}}>You have no items in your shopping cart.</Text>
                    <View style={{marginTop:'2%'}}>
                    <Text style={{color:'#000',fontSize:height*0.020}}>Click <TouchableOpacity onPress={()=>{navigation.navigate('Default')}}><Text style={{textDecorationLine: 'underline',color:'#000',top:'4%',fontSize:height*0.020}}>here</Text></TouchableOpacity> to continue shopping.</Text>
                </View>
            </View>
            )
        }
     
    }
    else{
        //Mobile View
    if(PRODUCT.total_qty>0){

        return(
            <>
            
            <View style={{backgroundColor:'#fff'}}>
            {displayMessage && PRODUCT?.total_qty<=1?<View><MinimumOrderWarning/></View>:null}
            {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}
            
            <View style={{marginTop:height*0.028}}>
                <TouchableOpacity onPress={()=>{PRODUCT?.total_price>NAVISION_RESPONSE?navigation.navigate('CheckoutPage',{rewardPoints:data.rewards.balance,order_date:orderDate!=null?orderDate:null,cart_subtotal:data?.customerCart?.prices?.subtotal_excluding_tax?.value,cart_shipping:data?.customerCart?.shipping_addresses[0]?.available_shipping_methods[0]?.amount?.value}):setDisplayMessage(!displayMessage);scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });}} style={[styles.summaryButton,{width:'100%',padding:height*0.022}]}>
                        <Text style={[styles.proceedCheckout]}>Proceed to Checkout</Text>
                </TouchableOpacity> 
            </View>

            {order.length==0?<View></View>:<View>
            <Text style={{marginTop:height*0.02,fontSize:height*0.026,color:'#000'}}>
                Would you like to add to an existing order?
            </Text>
            <Text style={{marginTop:height*0.01,fontSize:height*0.020,color:'#000',lineHeight:height*0.026}}>
                You can add items to an existing order up to 12pm the day before delivery. Simply select an order 
                below and confirm by clicking the "Add to this order" button below.
            </Text>
            <Text style={{marginTop:height*0.01,fontSize:height*0.020,color:'#000',lineHeight:height*0.026}}>
                Adding items to an existing order will remove the minimum order requirement.
            </Text>
            <View style={{zIndex:1}}>
                <DropDownPicker
                    // placeholder="Order #000000000 for £price.00 being delievered on YYYY/MON/DD"
                    placeholder={order[0]?.label}
                    placeholderStyle={{fontSize:height*0.018}}
                    dropDownContainerStyle={styles.dropdownContainerStyle}
                    style={[styles.dropdownStyle,{backgroundColor:'#fff'}]}     
                    containerStyle={[styles.filterButtonContainerStyle,{marginTop:height*0.020,width:'100%'}]}
                    open={open}
                    value={value}
                    items={order}
                    setOpen={setOpen}
                    setValue={setValue}
                    listMode='MODAL'
                    onSelectItem={(value)=>getSelectedOrder(value)}
                />
            </View>
            <View style={{marginTop:height*0.020}}>
                <TouchableOpacity onPress={()=>{addToThisOrder()}} style={styles.summaryButton}>
                    <Text style={styles.summaryButtonText}>{displayAddToOrder==false?'Add to this Order':'Confirm'}</Text>
                </TouchableOpacity>
            </View>
            </View>}
            <Text style={{marginTop:height*0.04,fontSize:height*0.020,color:'#ca2426',fontWeight:'600'}}>
                Salvo can only deliver to business addresses so please ensure the address on your acount is 
                a valid registered business address.
            </Text>
            <Text style={{fontSize:height*0.020,color:'#ca2426',fontWeight:'600'}}>
                Please contact us if your address is incorrect as otherwise your order may not be processed.
            </Text>

            <View style={{marginTop:height*0.014}}>
                <View style={styles.summarySaperator}></View>
            {PRODUCT?.items?.map((items,index)=>{
                console.log(items);
                 return(

    <View key={items} style={{borderBottomWidth:0.8,padding:height*0.014}}>
            <Text style={styles.prodInfo}>{items.product.sku}</Text>
            <TouchableOpacity onPress={()=>navigation.navigate('ProductPage',{sku:`"${items.product.sku}"`,uid:items.uid})}>
                <Text style={styles.prodInfo}>{items.product.name}</Text>
            </TouchableOpacity>
            <View style={{flexDirection:'row'}}>
           <View style={styles.prodQty}>
               <Text style={styles.prodQtyText}>Qty</Text>
               {/* <TextInput keyboardType='numeric' style={styles.prodQtyInput} onChangeText={newQuantity=>setQuantity({quantity:newQuantity,index:index,uid:items.uid})}>{items.quantity}</TextInput> */}
                              {/* <TextInput keyboardType='numeric' style={styles.prodQtyInput} placeholder={PRODUCT.items[index].uid==quantity1.uid?quantity1.quantity:String(items.quantity)} placeholderTextColor={"#000000"} 
                              onEndEditing={(e) => {setQuantity({uid:items.uid,quantity:e.nativeEvent.text});updateCart(PRODUCT.cartId,items.uid,e.nativeEvent.text);}}></TextInput> */}

                    <TextInput key={index} keyboardType='numeric' style={styles.prodQtyInput} placeholderTextColor={"#000000"} 
                                 onChangeText={text=>setInputs(
                                PRODUCT?.items?.map((input, i) =>
                                  i === index ? { ...input, quantity: text } : input
                                
                              ))}>{items.quantity}</TextInput>             
               <Text style={styles.priceInfo}>£ {parseFloat(items.product.price_range.maximum_price.final_price.value).toFixed(2)}</Text>
           </View>
          
       </View>
       <View style={{flexDirection:'row',justifyContent:'flex-end'}}>
           <TouchableOpacity style={{right:width*0.08}} onPress={()=>navigation.navigate('ProductPage',{sku:`"${items.product.sku}"`,uid:items.uid})}>
               <Image source={require('../assets/icons/edit.png')} 
               style={styles.updateIcon}/>
           </TouchableOpacity>
           <TouchableOpacity onPress={()=>{deleteData(items.uid)}}>
               <Image source={require('../assets/icons/bin.png')} 
               style={[styles.updateIcon]}/>
           </TouchableOpacity>
            </View>
    </View>
                )
            })}
         </View>
            <View style={styles.continueShopping}>
                    <TouchableOpacity onPress={()=>{navigation.navigate('Default')}} style={{flexDirection:'row'}}>
                        <Image source={require('../assets/icons/back.png')} 
                                style={styles.backIcon}/>
                        <Text style={{color:'#000',fontSize:height*0.020}}> Continue Shopping</Text>
                    </TouchableOpacity>
            </View>
            <View style={{alignItems:'center',marginTop:'5%'}}>
                <TouchableOpacity onPress={()=>{inputs.map((details)=>{
                    updateCart(CART_ID,details.uid,details.quantity)
                })}} style={[styles.summaryButton,{padding:height*0.018,width:width*0.60}]}>
                    <Text style={styles.summaryButtonText}>Update Shopping Cart</Text>
                </TouchableOpacity>         
            </View>
            <View style={styles.summaryContainer}>
                <Text style={styles.summaryTitle}>Summary</Text>
                {/* <Text style={[styles.cartDesc,{marginTop:height*0.010,fontWeight:'500'}]}>You can earn 50 Reward Points for completing your purchase!</Text> */}
                {/* <View style={[styles.summarySaperator,{marginTop:height*0.020}]}></View> */}
               
                <View style={{padding:height*0.008}}>
                    <View style={styles.shippingPriceContainer}>
                        <Text style={styles.shippingPrice}>Subtotal</Text>
                        <Text style={styles.shippingPrice}>£ {PRODUCT.subTotal==0? data?.customerCart?.prices?.subtotal_excluding_tax?.value:PRODUCT.subTotal}</Text>
                    </View>
                    {/* {console.log(data.customerCart.shipping_addresses[0].available_shipping_methods[0].amount.value)} */}
                    {data?.customerCart?.shipping_addresses?.map((shipping)=>{
                        return(                   
                                <View style={styles.shippingPriceContainer}>
                                    {shipping?.available_shipping_methods?.map((method)=>{
                                        return(
                                            <>
                                            <Text style={styles.shippingPrice}>Shipping ({method.carrier_title} - {method.method_title})</Text>
                                            
                                            <Text style={styles.shippingPrice}>£ {SHIPPING_VALUE}</Text>
                                            </>
                                        )
                                    })}
                              
                            </View>
                        )
                    })}
                   
                </View>
                <View style={[styles.summarySaperator,{marginTop:height*0.014}]}></View>
                <View style={{padding:height*0.008,marginTop:height*0.020}}>
                    <View style={styles.shippingPriceContainer}>
                        <Text style={[styles.shippingPrice,{fontWeight:'bold',right:width*0.020}]}>Order Total</Text>
                        <Text style={[styles.shippingPrice,{fontWeight:'bold'}]}>£ {parseFloat(PRODUCT.total_price).toFixed(2)}</Text>
                    </View>
                </View>
                <Text style={styles.rewardAmount}>Enter discount code</Text>
                <View style={[styles.applyDiscount,{width:width<600?width*0.49:width*0.88}]}> 
                    <TextInput placeholder="Enter discount code" placeholderTextColor={'#000'} keyboardType={'numeric'} style={{left:width*-0.010,fontSize:height*0.020}} />
                    <TouchableOpacity style={[styles.summaryButton,{marginLeft:width*0.040}]}>

                        <Text style={styles.summaryButtonText}>Apply Discount</Text>
                    </TouchableOpacity>
                </View>
                <View style={{marginTop:height*0.040}}>
                    <Text style={{color:'#000',fontSize:height*0.020}}>You Have {data.rewards.balance} points left</Text>
                    <Text style={{color:'#000',fontSize:height*0.020}}>10 for every 1GBP</Text>

                    <Text style={styles.rewardAmount}>Enter Reward Amount</Text>
                    <View style={[styles.applyDiscount,{width:'100%'}]}> 
                        <TextInput value={rewardPoints} placeholderTextColor={'#000'} onChangeText={(newPoint)=>setRewardPoints(newPoint)} keyboardType={'numeric'} style={{color:'#000'}}/>
                        <TouchableOpacity onPress={()=>applyRewardPoints(CART_ID,rewardPoints)} style={[styles.summaryButton,{}]}>
                            <Text style={styles.summaryButtonText}>Apply</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={{marginTop:height*0.028}}>
                    <TouchableOpacity onPress={()=>{PRODUCT?.total_price>NAVISION_RESPONSE?navigation.navigate('CheckoutPage',{rewardPoints:data.rewards.balance,order_date:orderDate!=null?orderDate:null,cart_subtotal:data?.customerCart?.prices?.subtotal_excluding_tax?.value,cart_shipping:data?.customerCart?.shipping_addresses[0]?.available_shipping_methods[0]?.amount?.value}):setDisplayMessage(!displayMessage);scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });}} style={[styles.summaryButton,{width:'100%',padding:height*0.022}]}>
                            <Text style={[styles.proceedCheckout]}>Proceed to Checkout</Text>
                    </TouchableOpacity> 
                </View>
            </View>

            </View>
            </>
        )
    }else{
        return(
            <View style={{backgroundColor:'#fff'}}>
                <Text style={{marginTop:height*0.02,color:'#000',fontSize:height*0.020}}>You have no items in your shopping cart.</Text>
                    <View style={{marginTop:height*0.01}}>
                    <Text style={{color:'#000',fontSize:height*0.020}}>Click <TouchableOpacity onPress={()=>{navigation.navigate('Default')}}><Text style={{textDecorationLine: 'underline',color:'#000',top:height*0.004,fontSize:height*0.020}}>here</Text></TouchableOpacity> to continue shopping.</Text>
                </View>
            </View>
        )
    }
 }
 }
 if(Platform.isPad){
    return(
        <>
            <View style={{padding:'2%',alignItems:'center'}}>
                <Text style={[stylesIpad.cartTitle,{fontSize:heightPad*0.020,fontWeight:'600'}]}>Shopping Cart</Text>
            <Items></Items>
            </View>
        </>
    )
 }else{
    return(
        <>
        <ScrollView ref={scrollViewRef} style={{backgroundColor:"#fff"}}>
            <View style={{padding:height*0.020}}>
                <Text style={styles.cartTitle}>Shopping Cart</Text>
            <Items></Items>
            </View>
        </ScrollView>
        </>
    )
 }
 
}

export default CartPage;

{/* <View style={{marginTop:height*0.0010}}>
<Collapse>
    <CollapseHeader style={{width:'100%'}}>
    <View style={styles.estimateContainer}>
        <Text style={styles.estimateText}>Estimate Shipping and Tax</Text>
        <Image source={require('../assets/icons/down-filled-arrow.png')} style={styles.estimateDownIcon}/>
    </View>
    </CollapseHeader>
    <CollapseBody>
    <View style={{padding:height*0.010}}>
        <Text style={styles.estimateDesc}>Enter your destination to get a shipping estimate.</Text>
        <View style={{marginTop:height*0.010}}>
           <Text style={styles.shippindAdress}>Country</Text>
           <View style={{zIndex:1}}>
                <DropDownPicker
                placeholder="United Kingdom"
                style={[styles.dropdownStyle,{backgroundColor:'#fff'}]}     
                dropDownContainerStyle={styles.dropdownContainerStyle}
                containerStyle={[styles.filterButtonContainerStyle,{marginTop:height*0.010,width:'100%'}]}
                open={open3}
                value={value3}
                items={country}
                setOpen={setOpen3}
                setValue={setValue3}
                setItems={setCountry}
                listMode={'MODAL'}
                />
            </View>
        </View>
        <View style={{marginTop:height*0.010}}>
           <Text style={styles.shippindAdress}>State/Province</Text>
           <TextInput style={[styles.regInput,{width:'100%',backgroundColor:'#fff'}]} value={province} onChange={setProvince}/>
        </View>
        <View style={{marginTop:height*0.010}}>
           <Text style={styles.shippindAdress}>Zip/Postal Code</Text>
           <TextInput style={[styles.regInput,{width:'100%',backgroundColor:'#fff'}]} value={zipCode} onChange={setZipCode}/>
        </View>
        <View style={{marginTop:height*0.020}}>
            <Text style={styles.shippindAdress}>Flat Rate</Text>
            <View style={styles.radioContainer}>
            <View style={[styles.radioOuter,{marginLeft:width*0.012}]}>
                {/* <View style={styles.radioInner}></View> */}
    //             <RadioButtonRN
    //                 data={ShippingMethod}
    //                 circleSize={6}
    //                 boxStyle={{backgroundColor:'#e5e5e5',borderWidth:0}}
    //                 activeColor={'#000'}
    //                 deactiveColor={'#000'}                
    //             />
    //         </View>
    //         <Text style={styles.fixedText}>Fixed <Text style={{fontWeight:'bold'}}> £15.00</Text></Text>
    //         </View>
    //     </View>
    // </View>
    // </CollapseBody>
// </Collapse>
// </View> */}