import { gql,useQuery } from "@apollo/client";
import React, { useEffect } from "react";
import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator } from "react-native";
import { useSelector } from "react-redux";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window')

const Basket = ({navigation,cartId}) => {
    
 
    const ITEMS=useSelector(state=>state);
    return(
        <View style={styles.basketContainer}>
        <View style={styles.basketTotal}>
            <Image source={require('../assets/icons/shopping-cart.png')} style={styles.basketIcon}/>
            <Text style={styles.basketTotalText}>Basket Total</Text>
            <Text style={styles.basketTotalPrice}>£{parseFloat(ITEMS?.total_price).toFixed(2)}</Text>
            {console.log(ITEMS)}
        </View>
        <View style={styles.totalItems}>
            <View style={styles.totalItemsQuantity}>
                <Text style={styles.totalItemsText}>Total Items </Text>
                <View  style={styles.input}>
                <Text style={{textAlign:'center',color:'#000',fontSize:height*0.020}}>
                    {ITEMS.total_qty}
                </Text>
                </View>
            </View>
            <TouchableOpacity onPress={()=>navigation.navigate('CartPage')} style={[styles.proceedCheckoutBtn,{right:width*0.036}]}>
                <Text style={[styles.proceedCheckout,{fontSize:height*0.018}]}>Proceed to Checkout</Text>
            </TouchableOpacity>
        </View>
    </View>
    )
}

export default Basket;