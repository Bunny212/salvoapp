
import {ITEMS,SET_CART_ID,ADD_TO_CART, TOTAL_QUANTITY, CATEGORY,SUB_CATEGORY,TOTAL_PRICE,CUSTOMER_TOKEN,CUSTOMER_DETAILS, ADDRESS, PAYMENT_METHOD,CUSTOMER_ADDRESS, PARENT_ORDER_ID, NAVISION_RESPONSE, STORE_VIEW,PARENT_ORDER_DATE,SHIPPING_METHODS,PAYMENT_METHODS, SUB_TOTAL_PRICE, WISH_LISTS, SHIPPING_VALUE, WISHLIST_ITEMS_COUNT, PREVIOUS_ORDERS} from "./actions";

const initialState={

    payment:[],
    cartId:null,
    items:[],
    count:0,
    total_qty:0,
    category:[],
    subCategory:[],
    total_price:0,
    subTotal:0,
    token:null,
    customer:[],
    address:[],
    customer_address:[],
    parentOrderId:null,
    parentOrderDate:null,
    navisionResponse:[],
    storeview:null,
    shippingMethods:[],
    paymentMethods:[],
    wishlist:[],
    wishListItems:[],
    shippingValue:0,
    previousOrders:[],
}

export function Reducers(state=initialState,action){
    switch(action.type){
        case SET_CART_ID:
            return {...state,cartId:action.payload};
        case ADD_TO_CART:
            return {...state,items:action.payload};
        case ITEMS:
            return {...state,count:action.payload};
        case TOTAL_QUANTITY:
            return {...state,total_qty:action.payload}
        case CATEGORY:
            return {...state,category:action.payload}
        case SUB_CATEGORY:
            return {...state,subCategory:action.payload}
        case TOTAL_PRICE:
            return {...state,total_price:action.payload}
        case CUSTOMER_TOKEN:
            return {...state,token:action.payload}
        case CUSTOMER_DETAILS:
            return {...state,customer:action.payload}
        case ADDRESS:
            return {...state,address:action.payload}
        case PAYMENT_METHOD:
            return {...state,payment:action.payload}
        case CUSTOMER_ADDRESS:
            return {...state,customer_address:action.payload}
        case PARENT_ORDER_ID:
            return {...state,parentOrderId:action.payload}
        case PARENT_ORDER_DATE:
            return {...state,parentOrderDate:action.payload}     
        case NAVISION_RESPONSE:
            return {...state,navisionResponse:action.payload}
        case STORE_VIEW:
            return {...state,storeview:action.payload}
        case SHIPPING_METHODS:
            return {...state,shippingMethods:action.payload}
        case PAYMENT_METHODS:
            return {...state,paymentMethods:action.payload}
        case SUB_TOTAL_PRICE:
            return {...state,subTotal:action.payload}
        case WISH_LISTS:
            return {...state,wishlist:action.payload}
        case SHIPPING_VALUE:
            return {...state,shippingValue:action.payload}
        case WISHLIST_ITEMS_COUNT:
            return {...state,wishListItems:action.payload}
        case PREVIOUS_ORDERS:
            return {...state,previousOrders:action.payload}
        default:
            return initialState;
    }
}