import { createStore,applyMiddleware,compose } from "redux";
import thunk from "redux-thunk";
import { Reducers } from "./Reducers";

// export const myStore=createStore(reducers,applyMiddleware(thunk));
export const myStore = createStore(
    Reducers, // your reducers
    compose(
      applyMiddleware(thunk)
    )
  )