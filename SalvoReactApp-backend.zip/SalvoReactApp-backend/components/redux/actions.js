export const SET_CART_ID='SET_CART_ID';
export const ADD_TO_CART='ADD_TO_CART';
export const ITEMS='NUMBER_OF_ITEMS';
export const TOTAL_QUANTITY='TOTAL_QUANTITY';
export const CATEGORY='CATEGORY';
export const SUB_CATEGORY='SUB_CATEGORY';
export const TOTAL_PRICE='TOTAL_PRICE';
export const SUB_TOTAL_PRICE='SUB_TOTAL_PRICE';
export const CUSTOMER_TOKEN='CUSTOMER_TOKEN';
export const CUSTOMER_DETAILS='CUSTOMER_DETAILS';
export const ADDRESS='ADDRESS';
export const PAYMENT_METHOD='PAYMENT_METHOD';
export const CUSTOMER_ADDRESS='CUSTOMER_ADDRESS';
export const PARENT_ORDER_ID='PARENT_ORDER_ID';
export const PARENT_ORDER_DATE='PARENT_ORDER_DATE';
export const NAVISION_RESPONSE='NAVISION_RESPONSE';
export const STORE_VIEW='STORE_VIEW';
export const SHIPPING_METHODS='SHIPPING_METHODS';
export const PAYMENT_METHODS='PAYMENT_METHODS';
export const WISH_LISTS='WISH_LISTS';
export const SHIPPING_VALUE='SHIPPING_VALUE';
export const WISHLIST_ITEMS_COUNT='WISHLIST_ITEMS_COUNT';
export const PREVIOUS_ORDERS='PREVIOUS_ORDERS';
export function CartIdSet(cartId) {
    return {
    type: SET_CART_ID,
    payload: cartId
    }
}
export function AddtoCart(items) {
    return {
    type: ADD_TO_CART,
    payload: items
    }
}
export function NumberofItems(count) {
    return {
    type: ITEMS,
    payload: count
    }
}
export function TotalQuantity(total_qty) {
    return {
    type: TOTAL_QUANTITY,
    payload: total_qty
    }
}
export function AddCategoryList(category) {
    return {
    type: CATEGORY,
    payload: category
    }
}
export function AddSubCategoryList(subCategory) {
    return {
    type: SUB_CATEGORY,
    payload: subCategory
    }
}
export function setTotalPrice(totalPrice) {
    return {
    type: TOTAL_PRICE,
    payload: totalPrice
    }
}
export function customerToken(token) {
    return {
    type: CUSTOMER_TOKEN,
    payload: token
    }
}
export function customerDetails(customer) {
    return {
    type: CUSTOMER_DETAILS,
    payload: customer
    }
}
export function setAddress(address){
    return{
        type:ADDRESS,
        payload:address
    }
}
export function setPaymentMethod(payment){
    return{
        type:PAYMENT_METHOD,
        payload:payment
    }
}
export function setCustomerAddress(customerAddress){
    return{
        type:CUSTOMER_ADDRESS,
        payload:customerAddress
    }
}
export function setOrderIdOfProccessingOrders(parentOrderId){
    return {
        type:PARENT_ORDER_ID,
        payload:parentOrderId
    }
}
export function setOrderDateOfProccessingOrders(parentOrderDate){
    return {
        type:PARENT_ORDER_DATE,
        payload:parentOrderDate
    }
}
export function setnavisionResponse(navisionResponse){
    return {
        type:NAVISION_RESPONSE,
        payload:navisionResponse
    }
}
export function setStoreView(storeview){
    return {
        type:STORE_VIEW,
        payload:storeview
    }
}
export function setShippingMethods(shippingMethods){
    return{
        type:SHIPPING_METHODS,
        payload:shippingMethods
    }
}
export function setPaymentMethods(paymentMethods){
    return{
        type:PAYMENT_METHODS,
        payload:paymentMethods
    }
}
export function setSubTotal(subTotal){
    return{
        type:SUB_TOTAL_PRICE,
        payload:subTotal
    }
}
export function setWishLists(wishlist){
    return{
        type:WISH_LISTS,
        payload:wishlist
    }
}
export function setShippingValue(shippingValue){
    return{
        type:SHIPPING_VALUE,
        payload:shippingValue
    }
}
export function setWishListItemCount(wishListItems){
    return{
        type:WISHLIST_ITEMS_COUNT,
        payload:wishListItems
    }
}
export function setPreviousOrders(previousOrders){
    return{
        type:PREVIOUS_ORDERS,
        payload:previousOrders
    }
}