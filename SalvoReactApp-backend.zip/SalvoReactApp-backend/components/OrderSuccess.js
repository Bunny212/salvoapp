import { gql, useQuery } from "@apollo/client";
import React from "react";
import { useState } from "react";
import { View,Text,TouchableOpacity,Image,Dimensions,ScrollView, ActivityIndicator } from "react-native";
import { useDispatch } from "react-redux";
import styles from "../styles/styles";
import Items from "./drawer/Items";
import { AddtoCart, TotalQuantity } from "./redux/actions";

const { width, height } = Dimensions.get('window')

const OrderSuccess = ({navigation,route}) =>{
    const dispatch=useDispatch();
    if(route.params.orderNumber1!=null){
        dispatch(TotalQuantity(0));
        dispatch(AddtoCart([]));
    }   
//     const GET_ORDER=gql`
//     {
//       customer {
//          firstname
//           lastname
//         orders(filter: {number:{eq:"${route.params.orderNumber}"}}, currentPage: 1, pageSize: 20) {
          
//           items{
//             items{
//                 product_name
//                 product_sku
//               }
//             shipping_address{
//                 firstname
//                 lastname
//                 street
//                 city
//                 country_code
//                 telephone
//                 company
//                 postcode
//                 region
//               }
//               billing_address{
//                 firstname
//                 lastname
//                 street
//                 city
//                 country_code
//                 telephone
//                 company
//                 postcode
//                 region
//                 }
//                 payment_methods{
//                     name
//                   }
//             shipping_method
//             order_date
//             number
//             total{
//               grand_total{
//                 value
//               }
//             }
//             status
//           }
          
//         }
      
//        }
//        currency{
//         default_display_currency_symbol
//       }
//       country(id:"US"){
//         full_name_english
//     }
  
//     }
//     `;
//     const { loading, error, data } = useQuery(GET_ORDER);
//     if (loading) return <ActivityIndicator></ActivityIndicator>;
//   if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
// //   console.log(data.customer.orders.items[0].shipping_method);
// console.log(':::::::::::::::::::',route.params.orderNumber);    
  return(
        <>
        <ScrollView>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>Thank you for your purchase!</Text>
        </View>
        <View style={[styles.accountInputField,{flexDirection:'row'}]}>
            <Text style={{fontSize:height*0.02,color:'#000'}}>
                Your order number is: 
            </Text>
            <TouchableOpacity style={{marginLeft:height*0.008}} onPress={()=>navigation.navigate('ViewOrder',{order_number:route.params.orderNumber1})}>
                
                   {route.params.orderNumber2!=''?<Text style={{fontSize:height*0.018,color:'#000',top:height*0.003}}>
                        {route.params.orderNumber1} and {route.params.orderNumber2}.
                        </Text>:
                        <Text style={{fontSize:height*0.018,color:'#000',top:height*0.003}}>
                        {route.params.orderNumber1}.
                        </Text>
                    }
                    
            </TouchableOpacity>
        </View>
        
        {/* <View style={styles.accountInputField}>
            <Text style={[styles.myAccountGreeting,{fontSize:height*0.024}]}>We'll email you an order confirmation with details and tracking info.</Text>
        </View>

        <View style={[styles.orderSummary,{paddingTop:height*0.022,paddingBottom:height*0}]}>
            <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Order details:</Text>
        </View>
        <View style={[styles.orderSummary,{paddingTop:height*0.022,paddingBottom:height*0}]}>
            <Text style={[styles.otherOptions,{fontSize:height*0.022}]}>Order Date: {data.customer.orders.items[0].order_date}</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.022}]}></View>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Shipping Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.firstname} {data.customer.orders.items[0].shipping_address.lastname}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.company}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.street}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.city}, {data.customer.orders.items[0].shipping_address.region}, {data.customer.orders.items[0].shipping_address.postcode}</Text>
                <Text style={styles.otherOptions}>{data.country.full_name_english}</Text>
                <Text style={styles.otherOptions}>T: {data.customer.orders.items[0].shipping_address.telephone}</Text>            
            </View>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Shipping Method</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_method}</Text>
            </View>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Billing Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.firstname} {data.customer.orders.items[0].billing_address.lastname}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.company}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.street} </Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.city}, {data.customer.orders.items[0].billing_address.region}, {data.customer.orders.items[0].billing_address.postcode}</Text>
                <Text style={styles.otherOptions}>{data.country.full_name_english}</Text>
                <Text style={styles.otherOptions}>T: {data.customer.orders.items[0].billing_address.telephone}</Text>
            </View>
        </View>

        <View style={{paddingLeft:height*0.022,paddingRight:height*0.022}}>
            <Text style={styles.headingTitle}>Payment Method</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>Credit Card</Text>
            </View>
            <View style={styles.creditCardContainer}>
                <View style={styles.creditCard}>
                    <Text style={[styles.detailsText,{fontWeight:'700'}]}>cc_type</Text>
                    <Text style={[styles.detailsText,{marginLeft:width*0.20}]}>{data.customer.orders.items[0].payment_methods[0].name}</Text>
                </View>
                <View style={styles.creditCard}>
                    <Text style={[styles.detailsText,{fontWeight:'700'}]}>cc_number</Text>
                    <Text style={[styles.detailsText,{marginLeft:width*0.16}]}>xxxx-1111</Text>
                </View>
            </View>
        </View>

        <View style={{paddingLeft:height*0.022,paddingRight:height*0.022}}>
            <View style={styles.orderDetailsContainer}>
                    <Text style={styles.otherOptions}>Items Ordered</Text>
                    <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                    <Text style={styles.ordersText}>Choose Dates Below</Text>
                    <Text style={styles.ordersText}>Choose Dates Below: YYYY-MM-DD</Text>
                    <View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Product Name:</Text>
                            <Text style={styles.ordersText}>  Name</Text>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>SKU:</Text>
                            <Text style={styles.ordersText}>  sku</Text>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Price:</Text>
                            <Text style={styles.ordersText}>  price/each</Text>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Qty:</Text>
                            <View>
                                <Text style={styles.ordersText}>  Ordered: 1</Text>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Subtotal:</Text>
                            <Text style={styles.ordersText}>  £Price</Text>
                        </View>
                        <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                    </View>

                    <View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Product Name:</Text>
                            <Text style={styles.ordersText}>  Name</Text>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>SKU:</Text>
                            <Text style={styles.ordersText}>  sku</Text>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Price:</Text>
                            <Text style={styles.ordersText}>  price/each</Text>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Qty:</Text>
                            <View>
                                <Text style={styles.ordersText}>  Ordered: 1</Text>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Subtotal:</Text>
                            <Text style={styles.ordersText}>  £Price</Text>
                        </View>
                    </View>
                    <View style={styles.orderPriceDetail}>
                        <View style={styles.orderPriceTotal}>
                        <Text style={styles.ordersText}>Subtotal</Text>
                        <Text style={styles.ordersText}>£Price</Text>
                        </View>
                        <View style={styles.orderPriceTotal}>
                        <Text style={styles.ordersText}>Shipping & Handling</Text>
                        <Text style={styles.ordersText}>£Price</Text>
                        </View>
                        <View style={styles.orderPriceTotal}>
                        <Text style={[styles.ordersText,{fontWeight:'500'}]}>Grand Total</Text>
                        <Text style={[styles.ordersText,{fontWeight:'500'}]}>£Price</Text>
                        </View>
                    </View>
                </View>
            </View> */}

            <View style={styles.accountInputField}>
                <TouchableOpacity onPress={()=>navigation.navigate('Default')} style={[styles.addToBasket,{width:'100%',padding:height*0.012}]}>
                    <Text style={styles.addToBasketText}>Continue Shopping</Text>
                </TouchableOpacity>
            </View>

        </ScrollView>
        </>
    )
}

export default OrderSuccess;