import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useSelector } from "react-redux";
import { gql, useQuery } from "@apollo/client";
const ManageAddress = ({navigation}) => {
    const [toggleCheckBox, setToggleCheckBox] = useState(false);
    const [deleteActionOpen,setDeleteActionOpen] = useState('none');
    const changeDeleteActionOpen = () =>{
        if(deleteActionOpen=='none'){
            setDeleteActionOpen('flex');
        }
    }
    const close=()=>{
        setDeleteActionOpen('none');
      }
    const [tooltipVisible, setTooltipVisible] = useState('none');
    const changeTooltipVisible = () =>{
        if(tooltipVisible=='none'){
         setTooltipVisible('flex');
        }else{
         setTooltipVisible('none');
        }
    } 

    const CUSTOMER=useSelector(state=>state.customer);
    const ADDITIONAL_ADDRESSES = gql`
    {
        customer {
          addresses{
            firstname
            lastname
            company
            street
            city
            region{
              region
            }
            postcode
            telephone
          }
         }
        country(id:"US"){
            full_name_english
        }
      }`;
      const { loading, error, data } = useQuery(ADDITIONAL_ADDRESSES);
      if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    console.log(data.customer.addresses[0].postcode);
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>Address Book</Text>
            <Text style={[styles.myAccountGreeting,{marginTop:height*0.022}]}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={[styles.accountInputField,{paddingTop:height*0.022,paddingBottom:height*0}]}>
            <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Default Addresses</Text>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Default Billing Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].firstname} {data.customer.addresses[0].lastname}</Text>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].company}</Text>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].street}</Text>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].city}, {data.customer.addresses[0].postcode}</Text>
                <Text style={styles.otherOptions}>{data.country.full_name_english}</Text>
                <Text style={styles.otherOptions}>T: {data.customer.addresses[0].telephone}</Text>
                <TouchableOpacity onPress={()=>navigation.navigate('EditAddress')}><Text style={styles.otherOptions}>Change Billing Address</Text></TouchableOpacity>
            </View>
        </View>

        <View style={styles.accountInputField}>
            <Text style={styles.headingTitle}>Default Shipping Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].firstname} {data.customer.addresses[0].lastname}</Text>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].company}</Text>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].street}</Text>
                <Text style={styles.otherOptions}>{data.customer.addresses[0].city}, {data.customer.addresses[0].postcode}</Text>
                <Text style={styles.otherOptions}>{data.country.full_name_english}</Text>
                <Text style={styles.otherOptions}>T: {data.customer.addresses[0].telephone}</Text>
                <TouchableOpacity onPress={()=>navigation.navigate('EditAddress')}><Text style={styles.otherOptions}>Change Shipping Address</Text></TouchableOpacity>
            </View>
        </View>

        <View style={[styles.accountInputField,{paddingBottom:height*0}]}>
            <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Additional Address Entries</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>

        <View style={styles.accountInputField}>
            {data.customer?.addresses.slice(1).reverse().map((address)=>{
                return(
                    <>
                    <View style={{padding:height*0.030,backgroundColor:'#fff',width:width*0.800,alignSelf:'center',display:deleteActionOpen,marginTop:height*0.020,
                    elevation: 10, shadowOpacity: 0.25,shadowOffset: { width: 0, height: 2 },shadowRadius: 6, position:'relative',}}>
                        <TouchableOpacity style={{position:'absolute',right:width*0.05}} onPress={()=>close()}>
                            <Image source={require('../assets/icons/close.png')} 
                            style={styles.wishListCloseIcon}/>
                        </TouchableOpacity>
                        <View style={{marginTop:height*0.02}}>
                            <Text style={styles.otherOptions}>Are you sure you want to delete this address?</Text>
                        </View>
                        <View style={{marginTop:height*0.03,flexDirection:'row'}}>
                            <TouchableOpacity onPress={()=>{close()}} style={{backgroundColor:'#eee',padding:height*0.010,width:width*0.18,borderRadius:height*0.005,borderWidth:0.2}}>
                                <Text style={[styles.addListText,{color:'#000'}]}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={[styles.addList,{borderRadius:height*0.005}]}>
                                <Text style={styles.addListText}>OK</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={{padding:height*0.022}}>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>First Name: </Text>
                        <Text style={styles.otherOptions}>    {address.firstname}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>Last Name: </Text>
                        <Text style={styles.otherOptions}>    {address.lastname}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>Street Address: </Text>
                        <Text style={styles.otherOptions}>    {address.street}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>City: </Text>
                        <Text style={styles.otherOptions}>    {address.city}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>Country: </Text>
                        <Text style={styles.otherOptions}>    {data.country.full_name_english}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>State: </Text>
                        <Text style={styles.otherOptions}>    {address.region.region}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>Zip/Postal Code: </Text>
                        <Text style={styles.otherOptions}>    {address.postcode}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>Phone: </Text>
                        <Text style={styles.otherOptions}>    {address.telephone}</Text>
                    </View>
                    <View style={{flexDirection:'row',marginTop:height*0.008}}>
                        <Text style={[styles.otherOptions,{fontWeight:'500'}]}>Actions: </Text>
                        <TouchableOpacity onPress={()=>navigation.navigate('EditAddress')}><Text style={styles.otherOptions}>    Edit</Text></TouchableOpacity>
                        <Text style={styles.otherOptions}>   |   </Text>
                        <TouchableOpacity onPress={()=>changeDeleteActionOpen()}><Text style={[styles.otherOptions,{color:'#d10029'}]}>Delete</Text></TouchableOpacity>
                    </View>
                </View>
              <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
              </>
                )
            })}
        </View>

        <View style={[styles.accountInputField,{paddingTop:height*0.022}]}>
            {/* <Text style={[styles.otherOptions,{fontSize:height*0.018,marginBottom:height*0.010}]}>You have no other address entries in your address book.</Text> */}
            <TouchableOpacity onPress={()=>navigation.navigate('NewAddress')} style={styles.saveBtn}>
                <Text style={styles.saveBtnText}>
                    Add New Address
                </Text>
            </TouchableOpacity>
        </View>

        </ScrollView>
        </>
    )
}

export default ManageAddress;