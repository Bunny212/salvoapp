import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useEffect, useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import DropDownPicker from 'react-native-dropdown-picker';
import CheckBox from '@react-native-community/checkbox';
import { useDispatch, useSelector } from "react-redux";
import { gql, useMutation, useQuery } from "@apollo/client";
import { COUNTRIES } from "./query/countriesList";
import { SET_SHIPPING_ADDRESS } from "./mutations/setShippingAddress";
import { SET_BILLING_ADDRESS } from "./mutations/setBillingAddress";
import { setAddress, setPaymentMethod } from "./redux/actions";


const NewAddress = ({navigation}) => {
    const [toggleCheckBox, setToggleCheckBox] = useState(false);
    const [open3, setOpen3] = useState(false);
    const [value3, setValue3] = useState("US");
    const country=[];
    const CUSTOMER=useSelector(state=>state.customer);
    const CART_ID=useSelector(state=>state.cartId);
    const [open2, setOpen2] = useState(false);
    const [value2, setValue2] = useState(null);
    const province=[];
    const [firstName,setFirstName]=useState(CUSTOMER.customer.firstname);
    const [lastName,setLastName]=useState(CUSTOMER.customer.lastname);
    const [company,setCompany]=useState('');
    const [telephone,setTelephone]=useState('');
    const [addressLine1,setAddressLine1]=useState('');
    const [addressLine2,setAddressLine2]=useState('');
    const [regionCode,setRegionCode]=useState('');
    const [regionId,setRegionId]=useState(0);
    const [city,setCity]=useState('');
    const [postalCode,setPostalCode]=useState('');
    const dispatch=useDispatch();
    const [setShippingAddress]=useMutation(SET_SHIPPING_ADDRESS);
    const [setBillingAddress]=useMutation(SET_BILLING_ADDRESS);
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);

   function getCountries(){
    const { loading, error, data } = useQuery(COUNTRIES);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    {data.countries.map((name)=>{ 
        country.push({label: name.full_name_english, value: name.id});    
    })}
   }
    
    const saveShippingAddress= async(cartId,firstName,lastName,company,street,city,region,region_id,postcode,country_code,telephone)=>{

        try{
            const{
                data,errors,
              }= await setShippingAddress({
                  variables:{
                      cartId,
                      firstName,
                      lastName,
                      company,
                      street,
                      city,
                      region,
                      region_id,
                      postcode,
                      country_code,
                      telephone
                  }
              });
             
              dispatch(setAddress(data.setShippingAddressesOnCart.cart.shipping_addresses[0]));
              dispatch(setPaymentMethod(data.setShippingAddressesOnCart.cart.available_payment_methods))
              navigation.navigate('CheckoutPage'); 
        }catch(error){
            console.log(error);
            setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message);   
        }
    }
    const saveBillingAddress=async(cartId,firstName,lastName,company,street,city,region,region_id,postcode,country_code,telephone)=>{
        try{
            const{
                data,errors,
              }= await setBillingAddress({
                  variables:{
                      cartId,
                      firstName,
                      lastName,
                      company,
                      street,
                      city,
                      region,
                      region_id,
                      postcode,
                      country_code,
                      telephone
                  }
              });            
        }catch(error){
            console.log(error);
            setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message);   
        }
    }
    if (displayServerError) {
        setTimeout(() => {
          setDisplayServerErrorMsg(false);
       }, 12000);
    }
    function getRegion(){
        console.log(value2);
        const REGION=gql`
        {
          country(id: ${value3}) {
            available_regions {
              code
              id
              name
            }
            full_name_english
            full_name_locale
            id
            three_letter_abbreviation
            two_letter_abbreviation
          }
        }`;
        const {loading,error,data}=useQuery(REGION);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if(data!=undefined){
            if(data.country.available_regions!=null){
            data.country.available_regions.map((region)=>{
                province.push({label: region.name, value: region.id, code:region.code})
            })
        }
        }
        
    }
    getRegion();
   const getRegionCode=()=>{
        province.map((region)=>{
            if(value2==region.value){
                console.log('Region Code :::::::::::::::::::::::::::::::',region.code)
                setRegionCode(region.code);
            }
        })
    }
    const getRegionId=()=>{
        
        province.map((region)=>{
            if(value2==region.value){
                // console.log('Region ID :::::::::::::::::::::::::::::::',region.value)
                setRegionId(region.value);
            }
        })
    }
    getCountries();
    useEffect(()=>{
        getRegionCode();
        getRegionId();
    })
    return(
        <>
        <ScrollView>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>Add New Address</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                    <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={{padding:height*0.022}}>
            <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Contact Information</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>
        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>First Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput onChangeText={fn=>setFirstName(fn)} style={styles.textInput}>{CUSTOMER.customer.firstname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Last Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput onChangeText={ln=>setLastName(ln)} style={styles.textInput}>{CUSTOMER.customer.lastname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Company</Text>
            </View>
            <TextInput onChangeText={com=>setCompany(com)} style={styles.textInput}/>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Phone Number</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput onChangeText={ph=>setTelephone(ph)} style={styles.textInput} keyboardType={"numeric"}/>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={{color:'#000',fontSize:height*0.028}}>Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Street Address</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput onChangeText={line1=>setAddressLine1(line1)} style={styles.textInput}/>
            <TextInput onChangeText={line2=>setAddressLine2(line2)} style={styles.textInput}/>
        </View>

        <View style={[styles.accountInputField]}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Country</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <DropDownPicker
                placeholder="United Kingdom"
                placeholderStyle={{fontSize:height*0.018}}
                style={styles.dropdownStyle}     
                dropDownContainerStyle={styles.dropdownContainerStyle}
                containerStyle={[styles.filterButtonContainerStyle,{width:'100%'}]}
                open={open3}
                value={value3}
                listMode={'MODAL'}
                items={country}
                setOpen={setOpen3}
                setValue={setValue3}
                />
                </View>

        <View style={[styles.accountInputField]}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>State/Province</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <DropDownPicker
                placeholder="Please Select a region, state or province."
                placeholderStyle={{fontSize:height*0.018}}
                style={styles.dropdownStyle}     
                dropDownContainerStyle={styles.dropdownContainerStyle}
                containerStyle={[styles.filterButtonContainerStyle,{width:'100%'}]}
                open={open2}
                value={value2}
                listMode={'MODAL'}
                items={province}
                setOpen={setOpen2}
                setValue={setValue2}
                />
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>City</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput onChangeText={ci=>setCity(ci)} style={styles.textInput}/>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Zip/Postal Code</Text>
            </View>
            <TextInput onChangeText={pc=>setPostalCode(pc)} style={styles.textInput} keyboardType={"numeric"}/>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setToggleCheckBox(!toggleCheckBox)}}>
                    <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleCheckBox} onValueChange={()=>{setToggleCheckBox(!toggleCheckBox)}}></CheckBox>
                    <Text style={styles.showPassword}>Use as my default billing address</Text>
                </TouchableOpacity>
            </View>

            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setToggleCheckBox(!toggleCheckBox)}}>
                    <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleCheckBox} onValueChange={()=>{setToggleCheckBox(!toggleCheckBox)}}></CheckBox>
                    <Text style={styles.showPassword}>Use as my default shipping address</Text>
                </TouchableOpacity>
            </View>

        </View>

        {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
            <Text style={styles.serverError}>{serverError}</Text>  
        </View>:<View></View>}
        <View style={styles.accountInputField}>
            <View style={{}}>
                <TouchableOpacity onPress={()=>{
                    saveShippingAddress(CART_ID,firstName,lastName,company,addressLine1+" "+addressLine2,city,regionCode,regionId,postalCode,value3,telephone); 
                    saveBillingAddress(CART_ID,firstName,lastName,company,addressLine1+" "+addressLine2,city,regionCode,regionId,postalCode,value3,telephone);
            }} style={styles.saveBtn}>
                    <Text style={styles.saveBtnText}>
                        Save Address
                    </Text>
                </TouchableOpacity>
            </View>
        </View>
        </ScrollView>
        </>
    )
}

export default NewAddress;