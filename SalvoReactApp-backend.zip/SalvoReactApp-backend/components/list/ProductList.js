import React,{useState,useEffect,useRef} from "react";
import { View, Text, StyleSheet, TouchableOpacity, Dimensions,Image,Platform,ScrollView ,ActivityIndicator, Button, KeyboardAvoidingView, FlatList} from "react-native";
import { TextInput } from "react-native-gesture-handler";
import styles from '../../styles/styles';
import {gql, useQuery,useMutation } from '@apollo/client';
import { FlatGrid } from "react-native-super-grid";
import { CREATE_CART } from "../mutations/createCart";
import { ADD_TO_CART } from "../mutations/addToCart";
import { useDispatch, useSelector } from "react-redux";
import { AddtoCart, CartIdSet, NumberofItems,setShippingMethods,setShippingValue,setSubTotal,setTotalPrice,TotalQuantity } from "../redux/actions";
import WishList from "./WishList";
import SubProduct from "../drawer/SubProduct";
import Basket from "../Basket";

const { width, height } = Dimensions.get('window')
const ProductList = ({navigation,search,filterByStock,filterByBrand,filterByNew,filterBySpecial,value,filterByPiceOne,filterByPiceTwo,id,pageNo,title,dynamicFilter}) =>{
  const [cartId,setCartId]=useState(null);
  const [quantity,setQuantity]=useState(1);
  const [sku,setSku]=useState('');
  const dispatch=useDispatch();
  const TOKEN=useSelector(state=>state.token);
  const NAVISION_RESPONSE=useSelector(state=>state?.customer?.customer?.minimum_order_amount);
  const ITEMS=useSelector(state=>state);
  const pages=[];
  const [currentPage,setCurrentPage]=useState(1);
  const units=[];
  const [minOrdervalue,setMinOrdervalue] = useState('');
  const [remainingMinOrdervalue, setRemainingMinOrderValue] = useState('');
  const [displayMessage,setDisplayMessage]=useState(false);
  const [load,setLoad]=useState(true);
  const [fetchCartId]=useMutation(CREATE_CART);
  const [serverError,setServerErrorMsg] = useState('');
  const [displayServerError,setDisplayServerErrorMsg] = useState(false);
// console.log('List Page',dynamicFilter);
  const createCart = async()=>{
    try{
      const{
        data,errors,
      }=await fetchCartId();
      setCartId(data.cartId);
      dispatch(CartIdSet(data.cartId));
    }catch(error){
      console.log(error);
        setDisplayServerErrorMsg(true);
        setServerErrorMsg(error.message);    

    }
  }

  const [addProductsToCart]=useMutation(ADD_TO_CART);
const addToCart = async (sku,quantity) =>{
 
    try{   
      const{
        data,errors,
      }= await addProductsToCart({
          variables:{
              cartId,
              sku,
              quantity
          }
      });
      // console.log('Minimum Order amount:::::::::::::::::::::',NAVISION_RESPONSE.minimum_order_value-data.addProductsToCart.cart.prices.grand_total.value)
      if(data!=undefined){
        // console.log('My Test:::::::::::::',data.addProductsToCart.cart.shipping_addresses[0].selected_shipping_method.amount.value)
        dispatch(TotalQuantity(data?.addProductsToCart?.cart?.total_quantity));
        dispatch(NumberofItems(data?.addProductsToCart?.cart?.items?.length));
        dispatch(AddtoCart(data?.addProductsToCart?.cart?.items));
        dispatch(setTotalPrice(data?.addProductsToCart?.cart?.prices?.grand_total?.value));
        dispatch(setSubTotal(data?.addProductsToCart?.cart?.prices?.subtotal_excluding_tax?.value));
        dispatch(setShippingValue(data?.addProductsToCart?.cart?.shipping_addresses[0]?.selected_shipping_method?.amount?.value));
        setMinOrdervalue(NAVISION_RESPONSE);
        setRemainingMinOrderValue(NAVISION_RESPONSE-data?.addProductsToCart?.cart?.prices?.grand_total?.value.toFixed(2));
      setLoad(true);  
    }
      // console.log('hhhhhhhhhhh',NAVISION_RESPONSE)
      // console.log('Remaining sMinimum Order amount:::::::::::::::::::::',NAVISION_RESPONSE-data.addProductsToCart.cart.prices.grand_total.value)
     
    }catch(error){
      console.log(error);
      setDisplayServerErrorMsg(true);
      setServerErrorMsg(error.message);    
    }
  }
  if (displayServerError) {
    setTimeout(() => {
      setDisplayServerErrorMsg(false);
    }, 12000);
  }

  useEffect(()=>{
    if(!cartId){
    createCart();
    }
    checkFilter();
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  },[])

  
  const CustomButton=({data,quantity,item,index})=>{
    if(TOKEN==null){
      if(item.stock_status=="IN_STOCK"){
    return(
    <TouchableOpacity onPress={()=>navigation.navigate('Login')} style={styles.addProduct}>
    <Text style={styles.loginTextButton}>Login/Create an Account</Text>
  </TouchableOpacity>
    )
      }else{
        return(
          <View style={styles.addProduct}>
          <Text style={styles.loginTextButton}>Out of Stock</Text>
        </View>
        )
      }
    }else{
      if(item.stock_status=="IN_STOCK"){
        return(
        <TouchableOpacity onPress={()=>{addToCart(data.products?.items[index].sku,quantity),setDisplayMessage(!displayMessage),createCart()}} style={styles.addProduct}>
          
          <Text style={styles.addProductText}>Add to Basket</Text>
        </TouchableOpacity>
        )
      }else{
        return(
        <View style={styles.addProduct}>
        <Text style={styles.addProductText}>Out of Stock</Text>
      </View>
        )
      }

    }
  }
  const setFilter=()=>{
    if(filterByNew==true && filterBySpecial==true){
        return `"4","5"`;
    }else if(filterByNew==true && filterBySpecial==false){
        return `"5"`;
    }else if(filterByNew==false && filterBySpecial==true){
      return `"4"`;    
    }else{
      return `"${id}"`
    }
  }
  const GetBrand=({data})=>{
    return(
      <View>
      {data.products.aggregations.map((brand_array)=>{
       return(
        <>
        {
        brand_array.attribute_code=="brand_name"? <Text style={styles.rummoText}>
          {brand_array.options[0].label}
        </Text>:<Text style={{height:0}}></Text>
      }
      </>
       )
      })}
      </View>
    )
  }
  // function ProductSuccess ({data,quantity,item,index}) {
  //   return(
  //     <>
      
  //     <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
  //       <Image source={require('../../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
  //       <View style={{}}>
  //         <Text style={{color:'#006400',fontSize:height*0.018,textAlign:'auto'}}>  You added product to your 
  //           <TouchableOpacity onPress={()=>console.log(item)}>
  //           <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> shopping cart.</Text></TouchableOpacity>
  //         </Text>
  //       </View>
  //     </View>
  //     </>
  //   )
  // }
  function MinimumOrderWarning () {
    return(
      <>
      <View style={{flexDirection:'row',padding:height*0.02,backgroundColor:'#fdf0d5',alignItems:'center'}}>
        <Image source={require('../../assets/icons/danger.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.020}}>
        <Text style={{color:'#6f4400',fontSize:height*0.018,marginLeft:width*0.010}}>
            Minimum order value for delivery is £{minOrdervalue} (excluding VAT) please add £{remainingMinOrdervalue} to your basket.
        </Text>
        </View>
      </View>
      </>
    )
  }
  const getUnit=()=>{
    const SALES_UNIT_OF_MEASURE=gql`
    {
      customAttributeMetadata(
        attributes: [
          {
            attribute_code: "sales_unit_of_measure"
            entity_type: "catalog_product"
          }
        ]
      ) {
        items {
          attribute_code
          attribute_type
          entity_type
          input_type
          attribute_options {
           value
           label
         }
        }
      }
    }
      `;
      const { loading, error, data } = useQuery(SALES_UNIT_OF_MEASURE);
      if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    // console.log(data.customAttributeMetadata.items[0].attribute_options);
    data?.customAttributeMetadata?.items[0]?.attribute_options.map((unit)=>{
      units.push(unit);
    })
  }
  getUnit();
  const scrollViewRef = useRef(null);
  if (displayMessage) {
    setTimeout(() => {
      setDisplayMessage(!displayMessage)
    }, 12000);
  }
  function checkFilter(){
    if(pageNo!=0){
      setCurrentPage(pageNo);
    }
  }


  const [wishListVisible, setWishListVisible] = useState('none');
  const [wishlistMessage,setWishlistMessage]=useState(false);
  const changeWishListVisible = (sku) =>{
    setSku(sku);
   if(wishListVisible=='none'){
    setWishListVisible('flex');
   }
  }
  const close=()=>{
    setWishListVisible('none');
  }
  const onPress=()=>{
    setWishListVisible('none');
    setWishlistMessage(!wishlistMessage);
  }
  const selectedPage=(pageNo)=>{
    setLoad(true)
    setCurrentPage(pageNo);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }
  const toNextPage = (pageNo) => {
    if(currentPage!=pageNo){
    setCurrentPage(currentPage+1)
    scrollViewRef.current.scrollTo({x:width/currentPage, animated: true});
    setLoad(true);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }else{
    setCurrentPage(pageNo);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }

 };
 const toPreviousPage = () => {
  if(currentPage!=1){
  setCurrentPage(currentPage-1);
  setLoad(true)
  setTimeout(() => {
    setLoad(false);
}, 5000);
  }else{
    setCurrentPage(1);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }
  // scrollViewRef.current.scrollTo({y: currentPage,x:currentPage, animated: true});
};
  if(search==undefined || search==""){
    const GET_PRODUCTS = 
    gql`
    {
      products(
        filter: {
          category_id:{eq:${id}
          },
          price:{
            from:${filterByPiceOne}
            to:${filterByPiceTwo}
          }
          ${dynamicFilter?.map((filter)=>{
            return filter?.id;
          })}
        }
        sort:{
        ${value}:ASC
        }
        pageSize: 15
        currentPage:${currentPage}
      )
       {
        sort_fields{
          options{
            label
          }
        }
        aggregations{
          attribute_code
          options{
            label
            value
          }
        }
        
          page_info{
          total_pages
        }
          items{
            sales_unit_of_measure
            brand_name
            stock_status
            is_frozen
            sku
            name
            stock_status
            small_image{
              url
            }
           
            price_range{
              maximum_price{
                final_price{
                  value
                }
              }
            }
          }
      }
      }
  `;
  const { loading, error, data } = useQuery(GET_PRODUCTS);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
if (error) return <Text style={{color:'#000'}}>{setCurrentPage(pageNo)}</Text>;
  for(let i=1;i<=data.products.page_info.total_pages;i++){
    pages.push(i);
  }
  if(data.products.items.length!=0){
  return(
    <>
    {/* {displayMessage && remainingMinOrdervalue<=minOrdervalue  && ITEMS?.total_qty<=1? <View><MinimumOrderWarning/></View> : null} */}
    {displayMessage? <View style={{width:'100%'}}>
    <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.020}}>
          <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  You added {data?.products?.items[0]?.name} to your 
            <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
            <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> shopping cart.</Text></TouchableOpacity>
          </Text>
        </View>
      </View>
    </View> : null}
    {wishlistMessage? <View style={{width:'100%'}}>
    <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.022}}>
          <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  {data?.products?.items[0]?.name} has been added to 
            <TouchableOpacity>
            <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> WishList.</Text></TouchableOpacity>
          </Text>
        </View>
      </View>
    </View> : null}
    
    {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}

    <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
   
    <FlatGrid itemDimension={130} spacing={10} indicatorStyle={false} data={data.products?.items}
    renderItem={({index,item})=>(
      <>
    <View style={{minHeight:height*0.46}}>
<View style={[styles.productContainer,{flex:1/data.products.items.length}]}>
<TouchableOpacity  onPress={()=>navigation.navigate('ProductPage',{sku:`"${item.sku}"`,category_sub_id:id,title:title})}>
  <View style={{flexDirection:'row',justifyContent:'space-between'}}>
  <Text numberOfLines={1} style={styles.skuText}>{item.sku}</Text>
  <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible(item.sku):navigation.navigate('Login')}} style={{paddingRight:width*0.022}}>
    <Image style={{height:height*0.045,width:width*0.045,resizeMode:'contain',tintColor:'#999DA3'}} source={require('../../assets/icons/tasks.png')}></Image>
  </TouchableOpacity>
 
    
  </View>
  <View style={styles.productImage}>
    {load? <ActivityIndicator animating={load}></ActivityIndicator>:<Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:height*0.150,width:width*0.350}}></Image>}
  </View>
  <GetBrand data={data}></GetBrand>
  <Text numberOfLines={3} style={styles.productName}>
    {item.name}
  </Text>
  </TouchableOpacity>

  <View style={styles.priceContainer}>
    <TextInput keyboardType="numeric" onChangeText={newQuantity=>setQuantity(newQuantity)} key={item} style={styles.input}>
        1
    </TextInput>

    <Text style={styles.productPrice}>£{parseFloat(item.price_range.maximum_price.final_price.value).toFixed(2)} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
  </View>
    <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
  
</View>
</View>
      </>
    )}
    
    >
    </FlatGrid>
    <View style={{justifyContent:'center',alignItems:'center'}}>
    {pages.length!=0 && pages.length!=1? <View style={{flexDirection:'row',width:'50%',justifyContent:'center',alignItems:'center'}}>
    <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.04,tintColor:'#999DA3'}}></Image>
      </TouchableOpacity>
    <View style={styles.paginationContainer}>
      <ScrollView ref={scrollViewRef}
 horizontal pagingEnabled={true} scrollEnabled={true} showsHorizontalScrollIndicator={false} >
    {pages.map((pageNo)=>{
      return(
        <>
        
        <TouchableOpacity onPress={()=>selectedPage(pageNo)} style={[styles.pageNumber,{borderColor:currentPage==pageNo? '#000000':'#999DA3'}]}>
          <Text style={{textAlign:'center',color:currentPage==pageNo? '#000000':'#999DA3',fontWeight:currentPage==pageNo? '700':'600'}}>
            {pageNo}
          </Text>
        </TouchableOpacity>
        </>
      )
    })}
    </ScrollView>
    </View>
    
    <TouchableOpacity style={{backgroundColor:'#999da3',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toNextPage(data.products.page_info.total_pages)}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.02,tintColor:'#fff',transform:[{rotate:"180deg"}]}}></Image>
      </TouchableOpacity>
    </View>:<View></View>}
    </View>
    </ScrollView>
    {TOKEN!=null?<View style={{height:'20%',top:height*0.022}}>
        <Basket navigation={navigation}></Basket>
    </View>:<View></View>}

    <KeyboardAvoidingView behavior='height' keyboardVerticalOffset={110} style={[styles.wishListOuterContainer,{display:wishListVisible}]}>
        <View style={styles.wishListClose}>
            <TouchableOpacity onPress={()=>{close()}}>
                <Image source={require('../../assets/icons/close.png')} 
                style={styles.wishListCloseIcon}/>
            </TouchableOpacity>
        </View>
        <WishList onPress={onPress} sku={sku} quantity={quantity} navigation={navigation} id={id}/>
  </KeyboardAvoidingView>
</>
  )
  }else{
    return (
      <View style={[styles.accountInputField,{width:'100%'}]}>
        <View style={styles.defaultShipping}>
            <Image source={require('../../assets/icons/danger.png')}
            style={[styles.dangerIcon,{marginLeft:width*0.020}]}/>
            <Text style={{color:'#6f4400',fontSize:height*0.018}}>  No Products Found !</Text>
        </View>
      </View>
    )
  }
  }else{
    const GET_PRODUCTS = 
    gql`
    {
      products(
        search:${search}
        filter: {
          category_id:{eq:${id}
          },
          price:{
            from:${filterByPiceOne}
            to:${filterByPiceTwo}
          }
          ${dynamicFilter?.map((filter)=>{
            return filter?.id;
          })}
        }
        sort:{
        ${value}:DESC
        }
        pageSize: 15
        currentPage:${currentPage}
      )
       {
        sort_fields{
          options{
            label
          }
        }
        aggregations{
          attribute_code
          options{
            label
            value
          }
        }
        page_info{
          total_pages
        }
          items{
            sales_unit_of_measure
            brand_name
            stock_status
            is_frozen
            sku
            name
            stock_status
            small_image{
              url
            }
           
            price_range{
              maximum_price{
                final_price{
                  value
                }
              }
            }
          }
      }
      }
  `;
  const { loading, error, data } = useQuery(GET_PRODUCTS);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
for(let i=1;i<=data.products.page_info.total_pages;i++){
  pages.push(i);
}
if(data.products.items.length!=0){
  return(
    <>
    <FlatGrid itemDimension={130} spacing={10} indicatorStyle={false}  data={data.products?.items}
    renderItem={({index,item})=>(
      <>
    <View style={{minHeight:height*0.46}}>
    <View style={[styles.productContainer,{flex:1/data.products.items.length}]}>
<TouchableOpacity  onPress={()=>navigation.navigate('ProductPage',{sku:`"${item.sku}"`,category_sub_id:id,title:title})}>
  <View style={{flexDirection:'row',justifyContent:'space-between'}}>
  <Text style={styles.skuText}>{item.sku}</Text>
  <TouchableOpacity onPress={()=>{changeWishListVisible()}} style={{paddingRight:width*0.022}}>
    <Image style={styles.tasksIcon} source={require('../../assets/icons/tasks.png')}></Image>
  </TouchableOpacity>
 
    
  </View>
  <View style={styles.productImage}>
    {load? <ActivityIndicator animating={load}></ActivityIndicator>:<Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:height*0.150,width:width*0.350}}></Image>}
  </View>
  <GetBrand data={data}></GetBrand>
  <Text numberOfLines={3} style={styles.productName}>
    {item.name}
  </Text>
  <View style={styles.priceContainer}>
    <TextInput keyboardType="numeric" onChangeText={newQuantity=>setQuantity(newQuantity)} style={styles.input}>
        1
    </TextInput>
    <Text style={styles.productPrice}>£{parseFloat(item.price_range.maximum_price.final_price.value).toFixed(2)} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
  </View>
  </TouchableOpacity>
  <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
</View>
</View>
      </>
    )}
    >
       
    </FlatGrid>
    <View style={{justifyContent:'center',alignItems:'center'}}>
    {pages.length!=0 && pages.length==1? <View style={{flexDirection:'row',width:'50%',justifyContent:'center',alignItems:'center'}}>
    <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.04,tintColor:'#999DA3'}}></Image>
      </TouchableOpacity>
    <View style={styles.paginationContainer}>
      <ScrollView ref={scrollViewRef}
 horizontal pagingEnabled={true} scrollEnabled={true} showsHorizontalScrollIndicator={false} >
    {pages.map((pageNo)=>{
      return(
        <>
        
        <TouchableOpacity onPress={()=>selectedPage(pageNo)} style={[styles.pageNumber,{borderColor:currentPage==pageNo? '#000000':'#999DA3'}]}>
          <Text style={{textAlign:'center',color:currentPage==pageNo? '#000000':'#999DA3',fontWeight:currentPage==pageNo? '700':'600'}}>
            {pageNo}
          </Text>
        </TouchableOpacity>
        </>
      )
    })}
    </ScrollView>
    </View>
    
    <TouchableOpacity style={{backgroundColor:'#999da3',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toNextPage(data.products.page_info.total_pages)}}>
        <Image source={require('../../assets/icons/back.png')} style={{height:height*0.02,width:width*0.02,tintColor:'#fff',transform:[{rotate:"180deg"}]}}></Image>
      </TouchableOpacity>
    </View>:<View></View>}
    </View>


    <KeyboardAvoidingView behavior='height' keyboardVerticalOffset={110} style={[styles.wishListOuterContainer,{display:wishListVisible}]}>
        <View style={styles.wishListClose}>
            <TouchableOpacity onPress={()=>{close()}}>
                <Image source={require('../../assets/icons/close.png')} 
                style={styles.wishListCloseIcon}/>
            </TouchableOpacity>
        </View>
        <WishList onPress={onPress} sku={sku} quantity={quantity} navigation={navigation} id={id}/>
  </KeyboardAvoidingView>
</>
  )
  }else{
    return (
      <View style={[styles.accountInputField,{width:'100%'}]}>
        <View style={styles.defaultShipping}>
            <Image source={require('../../assets/icons/danger.png')}
            style={[styles.dangerIcon,{marginLeft:width*0.020}]}/>
            <Text style={{color:'#6f4400',fontSize:height*0.018}}>    Your search returned no results.</Text>
        </View>
      </View>
    )
  }
}

}

export default ProductList;