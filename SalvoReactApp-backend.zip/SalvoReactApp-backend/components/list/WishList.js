import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal, SafeAreaView, ActivityIndicator, FlatList} from "react-native";
import styles from "../../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useEffect, useState } from "react";
import { ScrollView } from "react-native-gesture-handler";
import { gql, useMutation, useQuery } from "@apollo/client";
import { useDispatch, useSelector } from "react-redux";
import { FlatGrid } from "react-native-super-grid";
import { CREATE_WISHLIST } from "../mutations/createWishList";
import { setWishLists } from "../redux/actions";
import { ADD_TO_WISHLIST } from "../mutations/addToWishlist";

const WishList = ({sku,quantity,navigation,id,onPress}) => {
    const [newListVisible, setNewListVisible] = useState('none');
    const CUSTOMER_EMAIL=useSelector(state=>state.customer?.customer?.email);
    const WISHLIST=useSelector(state=>state.wishlist);
    const [count,setCount]=useState({});
    const [listName,setListName]=useState('');
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
  
    const changeNewListVisible = () =>{
        if(newListVisible=='none'){
         setNewListVisible('flex');
        }else{
         setNewListVisible('none');
        }
    }
    const dispatch=useDispatch();
   const [wishListCreate]=useMutation(CREATE_WISHLIST);
   const [selected,setSelected]=useState({});
   const createWishList=async(email,wishlistName)=>{
    console.log(email)
    console.log(wishlistName)
    try {
        const{
            data,errors,
          }= await wishListCreate({
              variables:{
                 email,
                 wishlistName
              }
          });
          console.log(data);
          dispatch(setWishLists(data?.AmastyMultiWishListCreate?.wishlist_details));
    } catch (error) {
            console.log(error);
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);    
    
    }
   }
   const selectedList=(wishllist_id)=>{
    
     WISHLIST.map((wishlist)=>{
        
        if(wishllist_id==wishlist.wishList_id){
            setSelected({id:wishllist_id,borderWidth:1});
        }
     })
   }
   
   const [amastyMultiWishListAddProduct]=useMutation(ADD_TO_WISHLIST);
   const addProductToWishList=async(email,wishlistId,productSku,productqty)=>{
    console.log(email);
    console.log(wishlistId);
    console.log(sku);
    console.log(productqty);
    
    try {
        const{
            data,errors,
          }= await amastyMultiWishListAddProduct({
              variables:{
                 email,
                 wishlistId,
                 productSku,
                 productqty
              }
          });
          dispatch(setWishLists(data?.AmastyMultiWishListAddProduct?.wishlist_details));
          
    } catch (error) {
        console.log(error);
        setDisplayServerErrorMsg(true);
        setServerErrorMsg(error.message);    

    }
   }
   if (displayServerError) {
    setTimeout(() => {
      setDisplayServerErrorMsg(false);
    }, 12000);
  }

console.log(count);
   
    return(
        <>
        <View style={styles.chooseList}>
            <Text style={styles.chooseListText}>Choose the List for Selected Products</Text>
        </View>
        <View style={{padding:height*0.020}}>
            <TouchableOpacity onPress={changeNewListVisible}>
                <Text style={styles.createNewWishList}>Create New List</Text>
            </TouchableOpacity>
        </View>
        <View style={[styles.addWishList,{display:newListVisible}]}>
            <TextInput onChangeText={(newlistName)=>setListName(newlistName)} placeholder="Enter List name" placeholderTextColor={'#999DA3'} style={styles.newWishListName}/>
            <TouchableOpacity onPress={()=>{createWishList(CUSTOMER_EMAIL,listName)}} style={styles.addWishListBtn}>
                <Text style={styles.addWishListBtnText}>Add</Text>
            </TouchableOpacity>
        </View>
        {/* <ScrollView showsVerticalScrollIndicator={false}>
            {data.AmastyMultiWishListRetrive.output.map((list)=>{
                return(
                <View style={styles.wishListContainer}>
                <TouchableOpacity>
                    <View style={styles.wishListTitle}>
                        <Text style={styles.wishListTitleText}>T</Text>
                    </View>
                    <Text style={styles.wishListName}>List Name</Text>
                    <Text style={{marginTop:height*0.010}}>1 items</Text>
                </TouchableOpacity>
                </View>
                )
            })}
           
        </ScrollView> */}
        <FlatList numColumns={2} style={{width:width<600?width*6.3:width*3.9,marginLeft:width<600?width*0.020:width*0.04}} indicatorStyle={false}  data={WISHLIST}
    renderItem={(list,index)=>{
        var string=list.item.wishList_name.toUpperCase();
        var alphabet=string.substring(0,1);
        return(
            <View style={[styles.wishListContainer,{borderWidth:selected.id==list.item.wishList_id? selected.borderWidth:0,borderColor:'#4776f0',borderRadius:height*0.006}]}>
            <TouchableOpacity onPress={()=>{selectedList(list.item.wishList_id)}}>
                {list.item.wishList_count==0?
                   <View style={[styles.wishListTitle,{backgroundColor:'#fff'}]}>
                   <Text style={[styles.wishListTitleText,{color:'#000',fontSize:height*0.016}]}>The folder is empty.</Text>
               </View>
             :   <View style={styles.wishListTitle}>
             <Text style={styles.wishListTitleText}>{alphabet}</Text>
         </View>
                 
                    }
              
                <Text style={styles.wishListName}>{list.item.wishList_name}</Text>
                <Text style={{marginTop:height*0.010,color:'#999DA3'}}>{list.item.wishList_count} items</Text>
            </TouchableOpacity>
            </View>
            )
    }}></FlatList>
            {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}

        <View style={styles.addToListBtn}>
            {selected.id?<TouchableOpacity onPress={()=>{addProductToWishList(CUSTOMER_EMAIL,selected.id,sku,quantity);onPress()}} style={styles.addToBasket}>
                <Text style={styles.addToBasketText}>Add to List</Text>
            </TouchableOpacity>:<View style={styles.addToBasket}>
                <Text style={styles.addToBasketText}>Add to List</Text>
            </View>}

        </View>
        </>
    )
}

export default WishList;