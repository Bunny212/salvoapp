import { gql, useQuery } from '@apollo/client';
import React, {useState, useRef, useEffect} from 'react';
import {StyleSheet,ScrollView,View,Text,TouchableOpacity,Image,Dimensions} from 'react-native';
import { useSelector } from 'react-redux';
const { width, height } = Dimensions.get('window');


function CustomDrawerContent(props,navigation) {
  const drawerItemsMain = [];
  const subChildren=[];
  const routes=[];
  const subRoutes=[];
  const [mainDrawer, setMainDrawer] = useState(true);
  const [subDrawer,setSubDrawer]=useState(false);
  const [filteredItems, setFilteredItems] = useState([]);
  const CATEGORY=useSelector(state=>state);
  const [activeCategory,setActiveCategory]=useState(null);
  const toggleMainDrawer = () => {
    setMainDrawer(true);
    setFilteredItems([]);
  };

  CATEGORY.category.map((categoryName)=>{
    drawerItemsMain.push({
      key: categoryName.name,
      title: categoryName.name,
      routes: routes,
    })
  });


  CATEGORY.category.map((categoryName)=>{
    categoryName.children?.map((child)=>{
       subChildren.push({
         key: child.name,
         title:child.name,
         routes: subRoutes,
         id:child.id
       })
    })
   });

const getSubCategory=(parent,id)=>{
  
  CATEGORY.category.map((item)=>{
    
    if(parent==item.name){
    
      setActiveCategory(item.name);
     
      routes.push(
      {nav: 'MainDrawer', routeName: item.name, title: 'View All '+item.name,children:item.children,id:id}
      )
     
    item.children.map((child)=>{
      routes.push(
        {nav: 'MainDrawer', routeName: child.name, title: child.name,id:id},
      )
    })
  }
  });
}

const getSubCategoryItem=(parent)=>{
  
  CATEGORY.category.map((item)=>{
    item.children.map((child)=>{
      if(parent==child.name){
      //  console.log(parent);
        setActiveCategory(parent);
        subRoutes.push(
          {nav: 'SubDrawer', routeName: child.name, title: 'View All '+child.name,children:child.children}
        )
      child.children.map((child)=>{
       
        subRoutes.push(
          {nav: 'SubDrawer', routeName: child.name, title: child.name,id:child.id},
        )
      })
     
    }
    })

  });


}

// console.log(subChildren);
  const onItemParentPress = (key) => {
   
    const filteredMainDrawerRoutes = drawerItemsMain.find((e) => {
      return e.key === key;
    });
    console.log('Clicked');
    if (filteredMainDrawerRoutes.routes.length === 1) {
      
      const selectedRoute = filteredMainDrawerRoutes.routes[0];
      props.navigation.toggleDrawer();
      props.navigation.navigate(selectedRoute.nav, {
        screen: selectedRoute.routeName=='Deliveries'? 'Delivery':'Delivery' && selectedRoute.routeName=='Community'?'Communities':"Communities",
      });
    } else {
      setMainDrawer(false);
      setSubDrawer(false)
      setFilteredItems(filteredMainDrawerRoutes);
    }
  };
  const onItemSubChildrenPress=(key,id)=>{
    const filteredMainDrawerRoutes = subChildren.find((e) => {
      return e.key === key;
    });
      if(filteredMainDrawerRoutes!=undefined){
        if(filteredMainDrawerRoutes.routes.length===0){
          const selectedRoute = filteredItems.routes[0];
          if(selectedRoute.children.length!=0){
          if(selectedRoute.routeName==key){
            props.navigation.navigate("SubProduct",{title:filteredMainDrawerRoutes.key,category_sub_id:filteredMainDrawerRoutes.id});
          }else{
            setSubDrawer(true);
            setFilteredItems(filteredMainDrawerRoutes);
          }
          }
        }
      }else{
         const selectedRoute = filteredItems.routes[0];
        props.navigation.toggleDrawer();
        if(selectedRoute.nav!=undefined){
         
          const selectedRouteSub = filteredItems.routes[0].children;
          selectedRouteSub.map((item)=>{
              if(item.name==key){
                console.log(key);
                props.navigation.navigate("SubProduct",{title:item.name,category_sub_id:item.id});
              }else{
                props.navigation.navigate("SubProduct",{title:key,category_sub_id:id})
              }
          })
        }else{
         
            props.navigation.navigate("SubProduct",{title:key,category_sub_id:id});
        }
      }
    
  }

  const Blogs =()=> {
    props.navigation.navigate('Blogs');
  }
  const Brands =()=> {
    props.navigation.navigate('Brands');
  }

  function renderMainDrawer() {
    return (
      <View>
        {CATEGORY.category.map((parent) => (
          
          <View key={parent.name}>
            
            <TouchableOpacity
              key={parent.name}
              testID={parent.name}
              onPress={() => {
                getSubCategory(parent.name,parent.id);
                onItemParentPress(parent.name);
              }}>
              <View style={styles.parentItem}>
                <Text style={styles.title}>{parent.name}</Text>
                    {parent.children.length!=0? <Image style={{height:height*0.040, width:width*0.080,resizeMode:'contain'}} source={require('../assets/icons/next.png')}></Image>:<View></View>}
              
              
              </View>
            </TouchableOpacity>
          </View>
        ))}
        {renderBlogs()}
        {renderBrands()}
      </View>
    );
  }
  function renderFilteredItemsDrawer() {
    return (
      <View>
        <TouchableOpacity
          onPress={() => toggleMainDrawer()}
          style={styles.backButtonRow}>
            <Image style={{height:'30%', width:'8%',resizeMode:'contain'}} source={require('../assets/icons/left-arrow.png')}></Image>
            <Text style={[styles.backButtonText, styles.title]}>{'All Categories'}</Text>
        </TouchableOpacity>
        <Text style={[styles.title,{marginLeft:width*0.040,fontWeight:'700',fontSize:height*0.022}]}>{activeCategory}</Text>
        {filteredItems.routes.map((route) => {
         
          return (
            <>
 <TouchableOpacity
              key={route.routeName}
              testID={route.routeName}
              onPress={() =>     
                  {{ onItemSubChildrenPress(route.name==undefined ? route.routeName:route.name,route.id);
                   getSubCategoryItem(route.routeName);
                   console.log(route);
                 
                  }}
                  
              }
              style={styles.item}>
            <View style={styles.parentItem}>
           
            <Text style={styles.title}>{subDrawer==false? route.title:route.title}</Text>
            {route.children==undefined && route.children?.length!=0? <Image style={{height:'100%', width:'8%',resizeMode:'contain',display:subDrawer==true?'none':'flex'}} source={require('../assets/icons/next.png')}></Image>:<View></View>}   
            </View>
            
            <View style={{borderBottomWidth:1,width:width*0.720,alignSelf:'center',borderBottomColor:'#F0F0F0'}}></View> 
            </TouchableOpacity>
      
            </>

          );
})}
       
      </View>
    );
  }

  function renderBlogs() {
    return (
      <View>
        <TouchableOpacity onPress={Blogs} testID="customDrawer-blogs">
          <View style={styles.parentItem}>
            <Text style={styles.title}>Blog</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  }
  
  function renderBrands() {
    // To be done later.
    return (
      <View>
        <TouchableOpacity onPress={Brands} testID="customDrawer-brands">
          <View style={styles.parentItem}>
            <Text style={styles.title}>Brands</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView showsVerticalScrollIndicator={false} style={styles.drawerContainer}>
      <View style={{marginTop:width*0.105,borderBottomWidth: 1,borderBottomColor: '#F0F0F0',height:height*0.090}}>
          <TouchableOpacity onPress={()=>{props.navigation.toggleDrawer();}} style={{left:width*0.040,width:'15%'}}>
            <Image source={require('../assets/icons/back-arrow.png')} style={{height:height*0.040, width:width*0.060,resizeMode:'contain'}}/>
        </TouchableOpacity>
      </View>
      <View
        style={styles.container}
        forceInset={{top: 'always', horizontal: 'never'}}>
        {mainDrawer ? renderMainDrawer() : renderFilteredItemsDrawer()}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  drawerContainer: {
    backgroundColor: '#fff',
  },
  container: {
    flex: 1,
    zIndex: 1000,
    paddingTop:height*0.010,
  },
  centered: {
    alignItems: 'center',
  },
  parentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent:'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    paddingTop: height*0.008,
    paddingBottom: height*0.008,
    paddingRight:width*0.012,
  },
  title: {
    margin: height*0.020,
    fontWeight: '500',
    color: '#000',
    textAlign: 'left',
    fontSize:height*0.022
  },
  backButtonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: height*0.017,
    paddingLeft: width*0.028,
    borderBottomColor: '#F0F0F0',
    borderBottomWidth: 1,
  },
  backButtonText: {
    marginLeft: width*0.020,
    color: '#F0F0F0',
  },
});

export default CustomDrawerContent;