import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import DropDownPicker from 'react-native-dropdown-picker';
import CheckBox from '@react-native-community/checkbox';
import { useQuery } from "@apollo/client";
import { COUNTRIES } from "./query/countriesList";
import { useSelector } from "react-redux";

const EditAddress = ({navigation}) => {
    const [open3, setOpen3] = useState(false);
    const [value3, setValue3] = useState(null);
    const initialValue = [
        { label: "Select a Value", value: " --- Select a State ---" }];
        const country=[];
    const [values, setValues] = useState(initialValue);
    const CUSTOMER=useSelector(state=>state.customer);
    const { loading, error, data } = useQuery(COUNTRIES);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    {data.countries.map((name)=>{
        country.push({label: name.full_name_english, value: name.id});
    })}
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>Edit Address</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                    <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Contact Information</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>First Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.firstname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Last Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.lastname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Company</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.addresses[0].company}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Phone Number</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.addresses[0].telephone}</TextInput>
        </View>

        <View style={[styles.accountInputField,{marginTop:height*0.022}]}>
            <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Street Address</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.addresses[0].street}</TextInput>
            <TextInput style={styles.textInput}/>
        </View>

        <View style={[styles.accountInputField,{zIndex:1}]}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Country</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <DropDownPicker
                placeholder="United Kingdom"
                placeholderStyle={{fontSize:height*0.018}}
                style={styles.dropdownStyle}     
                dropDownContainerStyle={styles.dropdownContainerStyle}
                containerStyle={[styles.filterButtonContainerStyle,{width:'100%'}]}
                zIndex={1}
                open={open3}
                value={value3}
                items={country}
                setOpen={setOpen3}
                setValue={setValue3}
                />
                </View>

                <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>State/Province</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.addresses[0].region.region}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>City</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.addresses[0].city}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Zip/Postal Code</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.addresses[0].postcode}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={styles.defaultShipping}>
                <Image source={require('../assets/icons/danger.png')}
                style={styles.dangerIcon}/>
                <Text style={{color:'#6f4400',fontSize:height*0.020}}>    It's a default shipping address.</Text>
            </View>
        </View>

        <View style={styles.accountInputField}>
        <View style={styles.defaultShipping}>
                <Image source={require('../assets/icons/danger.png')}
                style={styles.dangerIcon}/>
                <Text style={{color:'#6f4400',fontSize:height*0.020}}>    It's a default shipping address.</Text>
            </View>
        </View>

        <View style={styles.accountInputField}>
            <View style={{}}>
                <TouchableOpacity style={styles.saveBtn}>
                    <Text style={styles.saveBtnText}>
                        Save Address
                    </Text>
                </TouchableOpacity>
            </View>
        </View>
        </ScrollView>
        </>
    )
}

export default EditAddress;