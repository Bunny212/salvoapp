import { gql, useQuery } from "@apollo/client";
import { getVariableValues } from "graphql";
import React from "react";
import { useRef } from "react";
import { useState } from "react";
import { View,Text,TouchableOpacity,Image,Dimensions,ScrollView,ActivityIndicator } from "react-native";
import { DrawerLayout } from "react-native-gesture-handler";
import RenderHTML, { RenderHTMLConfigProvider, TRenderEngineProvider } from "react-native-render-html";
import styles from "../styles/styles";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
import BlogMenu from "./BlogMenu";


const { width, height } = Dimensions.get('window')

const BlogPage = ({navigation,route}) => {
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const drawerRef = useRef(null);
    const [sideBar,setSideBar] = useState('none');
    const handleSideBarVisible = () =>{
        if(sideBar=='none'){
         setSideBar('flex');
        }    
    }
    const close=()=>{
        setSideBar('none');
    }
    const openDrawer = () => {
        setIsDrawerOpen(true);
    };
    
    const closeDrawer = () => {
        setIsDrawerOpen(false);
    };
    const getValues=()=>{
        const GET_POST=gql`
        {
            amBlogPost(id: ${route.params.post_id}, urlKey: "${route.params.url_key}") {
              author_id
              canonical_url
              categories
              comment_count
              comments_enabled
              created_at
              display_short_content
              full_content
              grid_class
              is_featured
              list_thumbnail
              list_thumbnail_alt
              meta_description
              meta_robots
              meta_tags
              meta_title
              notify_on_enable
              post_id
              post_thumbnail
              post_thumbnail_alt
              published_at
              related_post_ids
              short_content
              status
              tag_ids
              title
              updated_at
              url_key
              user_define_publish
              views
            }
          }
        `;
        const { loading, error, data } = useQuery(GET_POST);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        return data;
    }
    const getPost=()=>{
        const GET_POST=gql`
        {
            amBlogPost(id: ${route.params.post_id}, urlKey: "${route.params.url_key}") {
              author_id
              canonical_url
              categories
              comment_count
              comments_enabled
              created_at
              display_short_content
              full_content
              grid_class
              is_featured
              list_thumbnail
              list_thumbnail_alt
              meta_description
              meta_robots
              meta_tags
              meta_title
              notify_on_enable
              post_id
              post_thumbnail
              post_thumbnail_alt
              published_at
              related_post_ids
              short_content
              status
              tag_ids
              title
              updated_at
              url_key
              user_define_publish
              views
            }
          }
        `;
        const { loading, error, data } = useQuery(GET_POST);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        return data;
    }
    const html={
        html:getPost()?.amBlogPost?.full_content
    }
    return(
        <>
         <DrawerLayout
        drawerBackgroundColor="#ffffff"
        ref={drawerRef}
        onDrawerSlide={isDrawerOpen}
        drawerType="front"
        onDrawerOpen={openDrawer}
        onDrawerClose={closeDrawer}
    drawerWidth={300}
    drawerPosition={DrawerLayout.positions.Right}
    renderNavigationView={() =>  <BlogMenu navigation={navigation} onPress={()=>{drawerRef.current.closeDrawer()}}/>}
>

        <ScrollView>
            
        <View style={styles.blogHeading}>
            <Text style={[styles.blogHeadingText,{width:width*0.70}]}>{getPost()?.amBlogPost?.title}</Text>
            <TouchableOpacity onPress={()=>{drawerRef.current.openDrawer()}}><Image source={require('../assets/icons/blog-menu.png')}/></TouchableOpacity>
        </View>
        <View style={[styles.blogArticle,{marginBottom:height*0.040}]}> 
            <View style={styles.blogDetailsContainer}>
                <View style={{padding:height*0.020}}>
                    <View style={styles.blogPublishDate}>
                        <Text style={styles.blogPublishDateText}>{route.params.timePassed}</Text>
                        <Text style={{color:'#999'}}>{route.params.views}</Text>                       
                    </View>
                    <TRenderEngineProvider>
            <RenderHTMLConfigProvider>
              <ScrollView style={{padding:height*0.020,marginBottom:height*0.030,backgroundColor:'#fff'}}>
                <RenderHTML 
                    classesStyles={stylesClass} 
                    tagsStyles={stylesTags} 
                    contentWidth={width} 
                    source={html!=null? html:'<p></p>'}>
                </RenderHTML>
              </ScrollView>
            </RenderHTMLConfigProvider>
        </TRenderEngineProvider> 
                </View>
            </View>
        </View>
        </ScrollView>
        </DrawerLayout>
        </>
    )
}
export default BlogPage;