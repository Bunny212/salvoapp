import { gql, useQuery } from "@apollo/client";
import moment from "moment";
import React from "react";
import { useEffect } from "react";
import { useState,useRef } from "react";
import { View,Text,TouchableOpacity,Image,Dimensions,ScrollView,ActivityIndicator, Touchable, TouchableOpacityBase } from "react-native";
import { DrawerLayout, TouchableHighlight } from "react-native-gesture-handler";
import RenderHTML, { RenderHTMLConfigProvider, TRenderEngineProvider } from "react-native-render-html";
import styles from "../styles/styles";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
import BlogMenu from "./BlogMenu";


const { width, height } = Dimensions.get('window')

const BlogsCategory = ({navigation,route}) => {
    const [sideBar,setSideBar] = useState('none');
    const [color, setColor] = useState({});
    const categories=[];
    const tags=[];
    const [load,setLoad]=useState(true);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const drawerRef = useRef(null);
    const posts=[];
    const [showNoPosts,setShowNoPosts]=useState();
    const [currentPage,setCurrentPage]=useState(0);
    const handleSideBarVisible = () =>{
        if(sideBar=='none'){
         setSideBar('flex');
        }    
    }
    const pages=[];
    const close=()=>{
        if(sideBar=='flex'){
            setSideBar('none');
        }
    }
    const openDrawer = () => {
        setIsDrawerOpen(true);
    };
    
    const closeDrawer = () => {
        setIsDrawerOpen(false);
    };
    const getReadTime=(postDate)=>{
        let timePassed = moment(postDate).fromNow();
        return timePassed;
    }
    
    const getAllCategories=()=>{  
        const BLOG_CATEGORIES=gql`
            {
                amBlogCategories {
                items {
                    category_id
                    created_at
                    level
                    meta_description
                    meta_robots
                    meta_tags
                    meta_title
                    name
                    parent_id
                    path
                    post_count
                    sort_order
                    status
                    store_id
                    updated_at
                    url_key
                }
                }
            }
        `;
        const { loading, error, data } = useQuery(BLOG_CATEGORIES);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        data.amBlogCategories.items.map((category)=>{
            categories.push({cat_id:category.category_id,label:category.name});
        })
    
    }
    getAllCategories();

       
const getTags=()=>{
    const GET_TAGS=gql`
    {
        amBlogTagsWidget{
          items {
            meta_description
            meta_robots
            meta_tags
            meta_title
            name
            tag_id
            url_key
          }
          title
        }
      }
          `;
      const { loading, error, data } = useQuery(GET_TAGS);
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    //   console.log(data.amBlogTagsWidget);
      data?.amBlogTagsWidget?.items?.map((tag)=>{
        tags.push({tag_id:tag.tag_id,tag_name:tag.name});
      })
}
getTags();
setTimeout(() => {
    if(posts.length!=0 || posts.length==0){
        setLoad(false);
    }
}, 5000);
const getPosts=(category_id)=>{
       
    const BLOG_POSTS=gql`
    {
        amBlogSetting {
            list_count_per_page
          }
        amBlogPosts(type: CATEGORY, entityId:${category_id}) {
          all_post_size
          items {
            author_id
            canonical_url
            categories
            comment_count
            comments_enabled
            created_at
            display_short_content
            full_content
            grid_class
            is_featured
            list_thumbnail
            list_thumbnail_alt
            meta_description
            meta_robots
            meta_tags
            meta_title
            notify_on_enable
            post_id
            post_thumbnail
            post_thumbnail_alt
            published_at
            related_post_ids
            short_content
            status
            tag_ids
            title
            updated_at
            url_key
            user_define_publish
            views
          }
        }
      }
    `;
    const { loading, error, data } = useQuery(BLOG_POSTS);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    if(data.amBlogPosts.all_post_size/data.amBlogSetting.list_count_per_page>parseInt(data.amBlogPosts.all_post_size/data.amBlogSetting.list_count_per_page)){
        // console.log(parseInt(data.amBlogPosts.all_post_size/data.amBlogSetting.list_count_per_page)+1);
        for(let i=1;i<=parseInt(data.amBlogPosts.all_post_size/data.amBlogSetting.list_count_per_page)+1;i++){
            pages.push(i);
          }
    }else{
        for(let i=1;i<=parseInt(data.amBlogPosts.all_post_size/data.amBlogSetting.list_count_per_page);i++){
            pages.push(i);
          }
    }
        data.amBlogPosts?.items?.map((item)=>{
            posts.push(item);
        });
}
getPosts(route?.params?.brand_category_id);

console.log('My Values:::::::::::::::',posts);

const selectedPage=(pageNo)=>{
    setLoad(true)
    setCurrentPage(pageNo);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }
  const toNextPage = (pageNo) => {
    if(currentPage!=pageNo){
    setCurrentPage(currentPage+1);
    setLoad(true);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }else{
    setCurrentPage(pageNo);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }

 };
 const toPreviousPage = () => {
  if(currentPage!=1){
  setCurrentPage(currentPage-1);
  setLoad(true)
  setTimeout(() => {
    setLoad(false);
}, 5000);
  }else{
    setCurrentPage(1);
    setTimeout(() => {
      setLoad(false);
  }, 5000);
  }

  // scrollViewRef.current.scrollTo({y: currentPage,x:currentPage, animated: true});
};

    return(
        <>
            <DrawerLayout
        ref={drawerRef}
        drawerBackgroundColor="#ffffff"
        onDrawerSlide={isDrawerOpen}
        drawerType="front"
        onDrawerOpen={openDrawer}
        onDrawerClose={closeDrawer}
    drawerWidth={300}
    drawerPosition={DrawerLayout.positions.Right}
    renderNavigationView={() =>  <BlogMenu navigation={navigation} onPress={()=>{drawerRef.current.closeDrawer()}}/>}
>
        <ScrollView style={{backgroundColor:'#fff'}}>
           
                    <View style={styles.blogHeading}>
            <Text style={styles.blogHeadingText}>{route.params.brand_category_name}</Text>
            <TouchableOpacity onPress={()=>{drawerRef.current.openDrawer()}}><Image source={require('../assets/icons/blog-menu.png')}/></TouchableOpacity>
        </View>
        
        {load? <ActivityIndicator animating={load}></ActivityIndicator>:posts?.length==0? 
        <View style={[styles.defaultShipping,{paddingHorizontal:width*0.050,display:load==true?'none':'flex'}]}>
        <Image source={require('../assets/icons/danger.png')}
        style={styles.dangerIcon}/>
        <Text style={{color:'#6f4400',fontSize:height*0.020}}>  There are no posts yet.</Text>
    </View>:posts.map((post_data)=>{
       
       return(
           <>
               <View style={styles.blogArticle}>
                   <TouchableOpacity onPress={()=>{navigation.navigate('BlogPage',{post_id:post_data.post_id,url_key:post_data.url_key,
                    timePassed:getReadTime(post_data.created_at),
                    views:post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view',
                   })}}>
                       <Image style={styles.blogArticleImg} source={{uri:post_data.post_thumbnail,height:height*0.4}}
                      />
                    </TouchableOpacity>
                   <View style={styles.blogDetailsContainer}>
                       <View style={{padding:height*0.020}}>
                           <View style={styles.blogPublishDate}>
                               <Text style={styles.blogPublishDateText}>{getReadTime(post_data.created_at)}</Text>
                               <Text style={{color:'#999'}}>{post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view'}</Text>
                           </View>
                           <TouchableOpacity onPress={()=>{navigation.navigate('BlogPage',{post_id:post_data.post_id
                               ,url_key:post_data.url_key,
                               timePassed:getReadTime(post_data.created_at),
                               views:post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view',
                               })}}>
                               <Text style={styles.blogArticleTitle}>
                                   {post_data.title}
                               </Text>
                           </TouchableOpacity>
                           <View style={{ flexDirection:'row'}}>
                       {tags.map((tag)=>{
                           return(
                           post_data.tag_ids.split(',').map((id)=>{
                               if(parseInt(id.replace(' ',''))==parseInt(tag.tag_id)){
                                   return(
                                   <TouchableHighlight
                                   onPressIn={() => {setColor({id:tag.tag_id,text_color:'#fff',backgroundColor:'#000'});}}
                                   onPressOut={() => {setColor({id:tag.tag_id,text_color:'#000',backgroundColor:'#F5F5F5'});}}
                                   onPress={()=>navigation.navigate('BlogsTags',{tag_id:tag.tag_id,tag_name:tag.tag_name})}
                               style={{
                                  margin:height*0.006,
                                   alignSelf: 'flex-start',
                                 padding: height*0.012,
                                 borderRadius: height*0.02,
                                 alignItems: "center",
                                 justifyContent: "center",
                               //   backgroundColor: "#F5F5F5",
                                 backgroundColor:color.id==tag.tag_id?color.backgroundColor:'#F5F5F5',
                               }}
                             >
                               <Text
                                 style={{ color:color.id==tag.tag_id?color.text_color:'#000'}}
                               >
                                   {tag.tag_name}
                               </Text>
                             </TouchableHighlight>
                                   )
                           }
                           })
                           )
                       })}
                     
                     </View>
                           <Text style={styles.blogArticlePara}>
                             {post_data.short_content}
                           </Text>
                           <View style={styles.blogArticlePosted}>
                            
                              
                               {
                                categories.map((category)=>{
                   
                                   if(category.cat_id==post_data.categories){
                                       return (
                                           <>
                                           <Text style={styles.blogArticlePostedIn}>Posted in: </Text>
                                           <TouchableOpacity><Text style={styles.blogArticleCategoty}>{category.label}</Text></TouchableOpacity>
                                           </>
                                       )
                                   }
                               })
                               }
                           </View>
                           <View style={{marginTop:height*0.020}}>
                               <TouchableOpacity onPress={()=>{navigation.navigate('BlogPage',{post_id:post_data.post_id,url_key:post_data.url_key,
                                timePassed:getReadTime(post_data.created_at),
                                views:post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view',
                               })}} style={styles.readMoreBtn}>
                                   <Text style={styles.readMoreBtnText}>Read More</Text>
                               </TouchableOpacity>
                           </View>
                       </View>
                   </View>
               </View>
               </>
       )
           })}
              

             <View style={{justifyContent:'center',alignItems:'center',padding:height*0.02, display:load?'none':'flex'}}>
           {pages.length!=0 && pages.length!=1? <View style={{flexDirection:'row',width:'50%',justifyContent:'center',alignItems:'center'}}>
    <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
        <Image source={require('../assets/icons/back.png')} style={{height:height*0.02,width:width*0.04,tintColor:'#999DA3'}}></Image>
      </TouchableOpacity>
    <View style={styles.paginationContainer}>
      <ScrollView
 horizontal pagingEnabled={true} scrollEnabled={true} showsHorizontalScrollIndicator={false} >
    {pages.map((pageNo)=>{
      return(
        <>
        
        <TouchableOpacity onPress={()=>selectedPage(pageNo)} style={[styles.pageNumber,{borderColor:currentPage==pageNo? '#000000':'#999DA3'}]}>
          <Text style={{textAlign:'center',color:currentPage==pageNo? '#000000':'#999DA3',fontWeight:currentPage==pageNo? '700':'600'}}>
            {pageNo}
          </Text>
        </TouchableOpacity>
        </>
      )
    })}
    </ScrollView>
    </View>
    
    <TouchableOpacity style={{backgroundColor:'#999da3',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toNextPage(pages.length)}}>
        <Image source={require('../assets/icons/back.png')} style={{height:height*0.02,width:width*0.02,tintColor:'#fff',transform:[{rotate:"180deg"}]}}></Image>
      </TouchableOpacity>
    </View>:<View></View>}
    </View>
        </ScrollView>
        </DrawerLayout>
        </>
    )
}

export default BlogsCategory;