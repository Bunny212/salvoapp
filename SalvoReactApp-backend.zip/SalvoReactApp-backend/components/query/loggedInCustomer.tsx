import { gql } from "@apollo/client";
export const CUSTOMER= gql`{
      customer {
        id
        firstname
        lastname
        suffix
        email
        created_in
        store_id
        website_id
        minimum_order_amount
        shipment_days
        addresses {
          firstname
          lastname
          street
          city
          region {
            region_code
            region
            region_id
          }
          postcode
          country_code
          telephone
          company
        }
      }
    }
  `;
