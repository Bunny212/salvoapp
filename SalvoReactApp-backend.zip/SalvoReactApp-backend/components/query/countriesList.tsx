import { gql } from "@apollo/client";

export const COUNTRIES=gql`
{
  countries {
    available_regions {
      code
      id
      name
    }
    full_name_english
    full_name_locale
    id
    three_letter_abbreviation
    two_letter_abbreviation
  }
}
`;





