import React,{useState,useEffect} from 'react';
import {View, StyleSheet, ScrollView,Button,ActivityIndicator,Text} from 'react-native';
import { ApolloClient, ApolloProvider, InMemoryCache } from '@apollo/client';
import {baseUrl} from './Utils/constants';
import Header from './Header'
import {gql, useQuery,useMutation } from '@apollo/client';

import { createDrawerNavigator, DrawerContent } from '@react-navigation/drawer';
import Default from './drawer/Block';
import Category from './drawer/Product';
import styles from '../styles/styles';
import { CREATE_CART } from './mutations/createCart';
import CustomDrawerContent from './CustomDrawerContent';
import Login from './Login';
import Register from './Register';
import { useDispatch, useSelector } from 'react-redux';
import { AddCategoryList, AddSubCategoryList, customerDetails, setStoreView } from './redux/actions';
import ProductPage from './ProductPage';
import CartPage from './CartPage';
import Checkout from './CheckoutPage';
import MyAccount from './MyAccount';
import EditAccountInfo from './EditAccountInfo';
import ChangePassword from './ChangePassword';
import Newsletter from './NewsletterSubscription';
import EditAddress from './EditAddress';
import ManageAddress from './ManageAddress.js';
import NewAddress from './NewAddress';
import ForgotPassword from './ForgotPassword';
import PreviousOrders from './PreviousOrders';
import ViewOrder from './ViewOrder';
import MyRewards from './MyRewards';
import Help from './Help';
import PreviousPurchases from './PreviousPurchases';
import SavedLists from './SavedLists';
import ViewLists from './ViewLists';
import ShareList from './ShareList';
import SignOut from './SignOut';
import Blogs from './Blogs';
import BlogPage from './BlogPage';
import TradeAccount from './TradeAccount';
import Brands from './BrandsPage';
import Callipo from './CallipoBrand';
import Castelli from './CastelliBrand';
import Colussi from './ColussiBrand';
import Dolce from './DolceBrand';
import Rovagnati from './RovagnatiBrand';
import Banedetto from './BenedettoBrand';
import Sapori from './SaporiBrand';
import ShopBrand from './ShopBrand';
import Community from './Community';
import Delivery from './Delivery';
import OrderSuccess from './OrderSuccess';
import AddToOrder from './AddtoOrder';
import BlockList from './drawer/BlockList';
import SwiperComponent from './SplashSlider';
import SubProductList from './list/SubProductList';
import SubProduct from './drawer/SubProduct';
import { CUSTOMER } from './query/loggedInCustomer';
import BlogsTags from './BlogsTags';
import BlogsCategory from './BlogsCategory';
import BlogsSearch from './BlogsSearch';
import Brand from './Brand';

const Drawer = createDrawerNavigator();
  const categoryArray=[];
  const DrawerNavigation = ({route}) => {
    const [cartId,setCartId]=useState(null);
    const [sku,setSku]=useState(null);
    const [quantity,setQuantity]=useState(0);
    const dispatch=useDispatch();
    const TOKEN=useSelector(state=>state.token);


    const { loading, error, data } = useQuery(CUSTOMER);

  function getCustomer(data){ 
          if (loading) return <ActivityIndicator></ActivityIndicator>;
          if(data!=undefined){
            // console.log('My Customer:::::::::::::::::',data.customer.created_in)
               dispatch(setStoreView(data.customer.created_in));
               dispatch(customerDetails(data));
              //  console.log('Default Customer:::::: ',data.customer);
          }
     }
     getCustomer(data);

    function getCategories(){
      const GET_CATEGORIES = gql`
      {
        categories{
          items{
            name
            children{
              id
              name
              children{
                id
                name
                children{
                  id
                  name
                }
              }
            }
          }
        }
      }
    `;
    const { loading, error, data } = useQuery(GET_CATEGORIES);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    dispatch(AddCategoryList(data.categories.items[0].children));
    data.categories.items.map((item)=>{
        dispatch(AddSubCategoryList(item.children));
    })
    return data;  
    }
     
  return (
    <>
    <Drawer.Navigator drawerContent={(props)=>(
      // <CustomDrawerContent drawerItems={drawerItemsMain} {...props}></CustomDrawerContent>
      <CustomDrawerContent {...props}></CustomDrawerContent>
  )} 
  // initialRouteName={route.params.params=="register"?'Register':'Login'} 
  initialRouteName={TOKEN!=null? "Default":"SplashScreen"} 
  screenOptions={{headerShown:true, 
    // initialRouteName={route.params.params=="register"?'Register':'Login'},

      header:(({navigation})=>{
      return(<Header style={styles.headerContainer} navigation={navigation} ></Header>);
    })
    }} useLegacyImplementation>
      <Drawer.Screen name={"SplashScreen"} options={{
        headerShown:false,
          drawerItemStyle:{display:'none'},
          }} component={SwiperComponent} />
       <Drawer.Screen name={"Default"} options={{
          drawerItemStyle:{display:'none'},
          }} component={Default} />
        <Drawer.Screen name={"Login"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Login} />
        <Drawer.Screen name={"Register"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Register} />
        <Drawer.Screen name={"ProductPage"} options={{
            drawerItemStyle:{display:'none'},
            headerLeft:(props)=>{
              return(
              <TouchableOpacity style={{backgroundColor:'#f6f6f6',padding:height*0.010,width:width*0.07,height:height*0.035,borderRadius:height*0.006,alignItems:'center',justifyContent:'center'}} onPress={()=>{toPreviousPage()}}>
              <Image source={require('../assets/icons/back.png')} style={{height:height*0.02,width:width*0.04,tintColor:'#999DA3'}}></Image>
            </TouchableOpacity>
              )
            }
          }} component={ProductPage} />
        <Drawer.Screen name={"CartPage"} options={{
            drawerItemStyle:{display:'none'},
          }} component={CartPage} />
         <Drawer.Screen name={"CheckoutPage"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Checkout} />
        <Drawer.Screen name={"ForgotPassword"} options={{
            drawerItemStyle:{display:'none'},
          }} component={ForgotPassword} />
        <Drawer.Screen name={"ChangePassword"} options={{
            drawerItemStyle:{display:'none'},
          }} component={ChangePassword} />
        <Drawer.Screen name={"EditAccount"} options={{
            drawerItemStyle:{display:'none'},
          }} component={EditAccountInfo} />
        <Drawer.Screen name={"EditAddress"} options={{
            drawerItemStyle:{display:'none'},
          }} component={EditAddress} />
        <Drawer.Screen name={"Help"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Help} />
        <Drawer.Screen name={"ManageAddress"} options={{
            drawerItemStyle:{display:'none'},
          }} component={ManageAddress} />
        <Drawer.Screen name={"MyAccount"} options={{
            drawerItemStyle:{display:'none'},
          }} component={MyAccount} />
        <Drawer.Screen name={"MyRewards"} options={{
            drawerItemStyle:{display:'none'},
          }} component={MyRewards} />
        <Drawer.Screen name={"NewAddress"} options={{
            drawerItemStyle:{display:'none'},
          }} component={NewAddress} />
        <Drawer.Screen name={"Newsletter"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Newsletter} />
        <Drawer.Screen name={"PreviousOrders"} options={{
            drawerItemStyle:{display:'none'},
          }} component={PreviousOrders} />
        <Drawer.Screen name={"PreviousPurchases"} options={{
            drawerItemStyle:{display:'none'},
          }} component={PreviousPurchases} />   
        <Drawer.Screen name={"SavedLists"} options={{
            drawerItemStyle:{display:'none'},
          }} component={SavedLists} />    
        <Drawer.Screen name={"ViewOrder"} options={{
            drawerItemStyle:{display:'none'},
          }} component={ViewOrder} />
        <Drawer.Screen name={"ViewLists"} options={{
            drawerItemStyle:{display:'none'},
          }} component={ViewLists} />
        <Drawer.Screen name={"ShareList"} options={{
            drawerItemStyle:{display:'none'},
          }} component={ShareList} />
          <Drawer.Screen name={"SignOut"} options={{
            drawerItemStyle:{display:'none'},
          }} component={SignOut} />
          <Drawer.Screen name={"Blogs"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Blogs} />
          <Drawer.Screen name={"BlogPage"} options={{
            drawerItemStyle:{display:'none'},
          }} component={BlogPage} />
          <Drawer.Screen name={"TradeAccount"} options={{
            drawerItemStyle:{display:'none'},
          }} component={TradeAccount} />
          <Drawer.Screen name={"Brands"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Brands} />
          <Drawer.Screen name={"ShopBrand"} options={{
            drawerItemStyle:{display:'none'},
          }} component={ShopBrand} />
          <Drawer.Screen name={"Callipo"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Callipo} />
          <Drawer.Screen name={"Castelli"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Castelli} />
          <Drawer.Screen name={"Colussi"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Colussi} />
          <Drawer.Screen name={"Dolce"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Dolce} />
          <Drawer.Screen name={"Rovagnati"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Rovagnati} />
          <Drawer.Screen name={"Brand"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Brand} />
          <Drawer.Screen name={"Banedetto"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Banedetto} />
          <Drawer.Screen name={"Sapori"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Sapori} />
          <Drawer.Screen name={"Communities"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Community} />
          <Drawer.Screen name={"Delivery"} options={{
            drawerItemStyle:{display:'none'},
          }} component={Delivery} />
          <Drawer.Screen name={"OrderSuccess"} options={{
            drawerItemStyle:{display:'none'},
          }} component={OrderSuccess} />
          <Drawer.Screen name={"AddToOrder"} options={{
            drawerItemStyle:{display:'none'},
          }} component={AddToOrder} />
          <Drawer.Screen name={"BlockList"} options={{
            drawerItemStyle:{display:'none'},
          }} component={BlockList}></Drawer.Screen>
          <Drawer.Screen name={"SubProduct"} options={{
            drawerItemStyle:{display:'none'},
          }} component={SubProduct}></Drawer.Screen>
          <Drawer.Screen name={"BlogsTags"} options={{
            drawerItemStyle:{display:'none'},
          }} component={BlogsTags}></Drawer.Screen>
          <Drawer.Screen name={"BlogsCategory"} options={{
            drawerItemStyle:{display:'none'},
          }} component={BlogsCategory}></Drawer.Screen>
          <Drawer.Screen name={"BlogsSearch"} options={{
            drawerItemStyle:{display:'none'},
          }} component={BlogsSearch}></Drawer.Screen>

    {getCategories().categories?.items[0].children.map((item,index)=>{
      categoryArray.push(item.id)
      return(
        <Drawer.Screen name={item.name} initialParams={{category:item.name,cart:cartId,categoryId:categoryArray[index]}}
         component={Category} />
      );
        
    })
  }
    </Drawer.Navigator>
    </>
  );
 }

export default DrawerNavigation;
