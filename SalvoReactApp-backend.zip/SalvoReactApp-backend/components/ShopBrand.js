import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import Header from "./Header";

const ShopBrand = () =>{
    return(
        <>
        <View style={{padding:height*0.022}}>
            <Text style={styles.brandTitle}>Rummo</Text>

            <View style={{marginTop:height*0.022}}>
                <View style={styles.defaultShipping}>
                    <Image source={require('../assets/icons/danger.png')}
                    style={styles.dangerIcon}/>
                    <Text style={{color:'#6f4400',fontSize:height*0.018}}>    We can't find products matching the selection.</Text>
                </View>
                </View>
            <View style={styles.usuallyBought}>
                <Text style={styles.usuallyBoughtText}>Usually bought together </Text>
                <TouchableOpacity style={{flexDirection:'row'}}>
                    <Text style={styles.seeAll}>See all</Text>
                    <Image source={require('../assets/icons/next-arrow.png')}
                    style={styles.nextArrowIcon}/>
                </TouchableOpacity>
            </View>
            <View style={styles.shopBrandBox}>
                <View style={{}}>
                    <Image source={require('../assets/images/shop.jpg')}
                    style={styles.brandBannerImg}/>
                </View>
                <View style={{padding:height*0.026}}>
                    <Text style={styles.percentOffText}>Up to 15% off</Text>
                    <Text style={styles.offDateText}>All multi-bag Rummo Pasta.</Text>
                    <Text style={styles.offDateText}> Ends 1st April</Text>
                </View>
                <View style={{marginLeft:width*0.080}}>
                    <TouchableOpacity style={styles.shopNow}>
                        <Text style={styles.shopNowText}>Shop Now</Text>
                    </TouchableOpacity>
                 </View>
            </View>
        </View>
        
        </>
    )
}

export default ShopBrand;