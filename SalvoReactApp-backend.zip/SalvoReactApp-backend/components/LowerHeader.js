import React from 'react';
import { Text, View, StyleSheet,Image, useWindowDimensions, ScrollView, ActivityIndicator} from 'react-native';
import styles from '../styles/styles';
import stylesClass from '../styles/stylesClass';
import { ApolloClient, ApolloProvider, gql, InMemoryCache, useQuery } from '@apollo/client';
import HTML, { RenderHTMLConfigProvider, RenderHTMLSource, TRenderEngineProvider } from 'react-native-render-html';
const LowerHeader=()=>{
        const GET_PRODUCTS = gql`
        {
          cmsBlocks(identifiers: "lower_header_block") {
            items {
              content
              identifier
              title
            }
          }
        }
      `;
      const { loading, error, data } = useQuery(GET_PRODUCTS);
      const {width}=useWindowDimensions();
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      return (
        data.cmsBlocks?.items.map(item=>{
          return(
          <ScrollView showsVerticalScrollIndicator={false}>
          <TRenderEngineProvider classesStyles={stylesClass}>
            <RenderHTMLConfigProvider>
              <RenderHTMLSource contentWidth={width} source={{html:item.content}}/>
            </RenderHTMLConfigProvider>
          </TRenderEngineProvider>
          </ScrollView>
          );
        })
      );
}
export default LowerHeader;

