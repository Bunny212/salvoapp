import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal, ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch, useSelector } from "react-redux";
import { gql, useMutation, useQuery } from "@apollo/client";
import { CREATE_WISHLIST } from "./mutations/createWishList";
import { setWishLists } from "./redux/actions";

const SavedLists = ({navigation}) => {
    const CUSTOMER=useSelector(state=>state.customer);
    const CUSTOMER_EMAIL=useSelector(state=>state.customer?.customer?.email);
    const [wishlistName,setWishlistName]=useState();
    const WISHLIST=useSelector(state=>state.wishlist);
    const [newListVisible, setNewListVisible] = useState('none');
    const [serverError,setServerErrorMsg] = useState('');
const [displayServerError,setDisplayServerErrorMsg] = useState(false);

    const changeNewListVisible = () =>{
        if(newListVisible=='none'){
         setNewListVisible('flex');
        }else{
         setNewListVisible('none');
        }
    }
    const dispatch=useDispatch();
    const [wishListCreate]=useMutation(CREATE_WISHLIST);
    const createWishList=async(email,wishlistName)=>{
        console.log(email)
        console.log(wishlistName)
        try {
            const{
                data,errors,
              }= await wishListCreate({
                  variables:{
                     email,
                     wishlistName
                  }
              });
              console.log(data);
              dispatch(setWishLists(data?.AmastyMultiWishListCreate?.wishlist_details));
        } catch (error) {
                console.log(error);
                setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message); 

        }
       }
    
if (displayServerError) {
    setTimeout(() => {
      setDisplayServerErrorMsg(false);
   }, 12000);
}
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>My Account</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        
{displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
	<Text style={styles.serverError}>{serverError}</Text>  
</View>:<View></View>}
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={[styles.myAccountMenuText,{fontWeight:'700'}]}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={styles.savedListContainer}>
            <TouchableOpacity><Text style={styles.savedListTitle}>Saved Lists</Text></TouchableOpacity>
            <TouchableOpacity onPress={changeNewListVisible}><Text style={styles.createNewList}>Create New List</Text></TouchableOpacity>
        </View>
        <View style={[styles.newList,{display:newListVisible}]}>
            <TextInput onChangeText={(newListName)=>setWishlistName(newListName)} style={styles.newListInput}/>
            <View  style={styles.addList}>
                <TouchableOpacity onPress={()=>{createWishList(CUSTOMER_EMAIL,wishlistName);setNewListVisible('none');setWishlistName('')}}><Text style={styles.addListText}>Add</Text></TouchableOpacity>
            </View>
        </View>

        <View style={styles.savedListContainer}>
            <Text numberOfLines={2} style={[styles.savedListText,{width:width*0.220,fontWeight:'600'}]}>Name & Description</Text>
            <Text style={[styles.savedListText,{width:width*0.220,fontWeight:'600'}]}>Items</Text>
            <Text style={[styles.savedListText,{fontWeight:'600'}]}>Action</Text>
        </View>
        <View style={styles.savedListSaperatorLine}></View>
        
        {WISHLIST.map((item)=>{
            console.log(item)
        return(
            <>
        <View style={styles.savedListContainer}>
            <Text style={[styles.savedListText,{width:width*0.250}]}>{item.wishList_name}</Text>
            <Text style={styles.savedListText}>{item.wishList_count}</Text>
            <Text style={styles.savedListText}>{item.added_at}</Text>
            <TouchableOpacity onPress={()=>{navigation.navigate('ViewLists',{wishlist_name:item.wishList_name,wishlist_items:item.wishList_count,wishlist_id:item.wishList_id})}}><Text style={styles.savedListText}>View</Text></TouchableOpacity>
        </View>
        <View style={styles.savedListSaperatorLine}></View>
        </>
        )
    })}
        </ScrollView>
        </>
    )
}

export default SavedLists;