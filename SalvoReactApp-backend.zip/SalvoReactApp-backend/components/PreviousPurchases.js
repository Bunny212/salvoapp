import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal, ActivityIndicator, KeyboardAvoidingView} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch, useSelector } from "react-redux";
import { gql, useMutation, useQuery } from "@apollo/client";
import WishList from "./list/WishList";
import { ADD_TO_CART } from "../components/mutations/addToCart";
import { AddtoCart, CartIdSet, NumberofItems,setShippingMethods,setShippingValue,setSubTotal,setTotalPrice,TotalQuantity  } from "../components/redux/actions";
import { FlatGrid } from "react-native-super-grid";
import {imageUrl} from '../Utils/constants';
import { CREATE_CART } from "./mutations/createCart";

const PreviousPurchases = ({navigation}) => {
    const TOKEN=useSelector(state=>state.token);
    const [wishListVisible, setWishListVisible] = useState('none');
    const [displayMessage,setDisplayMessage]=useState(false);
    const productSKU=[];
    const CART_ID=useSelector(state=>state.cartId);
    const dispatch=useDispatch();
    const units=[];
    const [cartId,setCartId]=useState(null);
    const [quantity,setQuantity]=useState(1);
    const [sku,setSku]=useState('');
    const [fetchCartId]=useMutation(CREATE_CART);
    const changeWishListVisible = () =>{
     if(wishListVisible=='none'){
      setWishListVisible('flex');
     }
    }
    const close=()=>{
      setWishListVisible('none');
    }
    const createCart = async()=>{
        try{
          const{
            data,errors,
          }=await fetchCartId();
          setCartId(data.cartId);
          dispatch(CartIdSet(data.cartId));
        }catch(error){
          console.log(error);
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);    
    
        }
      }
    console.log(CART_ID);
    const [addProductsToCart]=useMutation(ADD_TO_CART);
    const addToCart = async (sku,quantity,cartId) =>{
      console.log('my SKU',sku);
        try{   
          const{
            data,errors,
          }= await addProductsToCart({
              variables:{
                  cartId,
                  sku,
                  quantity
              }
          });
          dispatch(TotalQuantity(data?.addProductsToCart?.cart?.total_quantity));
        dispatch(NumberofItems(data?.addProductsToCart?.cart?.items?.length));
        dispatch(AddtoCart(data?.addProductsToCart?.cart?.items));
        dispatch(setTotalPrice(data?.addProductsToCart?.cart?.prices?.grand_total?.value));
        dispatch(setSubTotal(data?.addProductsToCart?.cart?.prices?.subtotal_excluding_tax?.value));
        dispatch(setShippingValue(data?.addProductsToCart?.cart?.shipping_addresses[0]?.selected_shipping_method?.amount?.value));
        setMinOrdervalue(NAVISION_RESPONSE);
        setRemainingMinOrderValue(NAVISION_RESPONSE-data?.addProductsToCart?.cart?.prices?.grand_total?.value.toFixed(2));
         
        }catch(error){
          console.log(error);
        }
      }
      const GetBrand=({data})=>{
        return(
          <View>
          {data?.products?.aggregations?.map((brand_array)=>{
           return(
            <>
            {
            brand_array?.attribute_code=="brand_name"? <Text style={styles.rummoText}>
              {brand_array?.options[0]?.label}
            </Text>:<Text style={{height:0}}></Text>
          }
          </>
           )
          })}
          </View>
        )
      }
      const CustomButton=({data,quantity,item,index})=>{
        if(TOKEN==null){
          if(item.stock_status=="IN_STOCK"){
        return(
        <TouchableOpacity onPress={()=>navigation.navigate('Login')} style={styles.addProduct}>
        <Text style={styles.loginTextButton}>Login/Create an Account</Text>
      </TouchableOpacity>
        )
          }else{
            return(
              <View style={styles.addProduct}>
              <Text style={styles.loginTextButton}>Out of Stock</Text>
            </View>
            )
          }
        }else{
          if(item.stock_status=="IN_STOCK"){
            return(
            <TouchableOpacity onPress={()=>{addToCart(data.products?.items[index].sku,quantity,cartId),setDisplayMessage(!displayMessage),createCart()}} style={styles.addProduct}>
              
              <Text style={styles.addProductText}>Add to Basket</Text>
            </TouchableOpacity>
            )
          }else{
            return(
            <View style={styles.addProduct}>
            <Text style={styles.addProductText}>Out of Stock</Text>
          </View>
            )
          }
    
        }
      }
      const getUnit=()=>{
        const SALES_UNIT_OF_MEASURE=gql`
        {
          customAttributeMetadata(
            attributes: [
              {
                attribute_code: "sales_unit_of_measure"
                entity_type: "catalog_product"
              }
            ]
          ) {
            items {
              attribute_code
              attribute_type
              entity_type
              input_type
              attribute_options {
               value
               label
             }
            }
          }
        }
          `;
          const { loading, error, data } = useQuery(SALES_UNIT_OF_MEASURE);
          if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        // console.log(data.customAttributeMetadata.items[0].attribute_options);
        data?.customAttributeMetadata?.items[0]?.attribute_options.map((unit)=>{
          units.push(unit);
        })
      }
      getUnit();
    const CUSTOMER=useSelector(state=>state.customer);
      const previousOrders=()=>{
        const OORDERED_ITEMS=gql`
        query{
            PreviousOrderItem(
                customerEmail: "${CUSTOMER.customer.email}"
            ){
                product_details{
                    product_sku
                    product_name
                    product_qty
                    product_price
                    product_image
                }
                message
            }
        }
      `;
      const { loading, error, data } = useQuery(OORDERED_ITEMS);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        return data;
       
      }
      previousOrders()?.PreviousOrderItem?.product_details?.map((products)=>{
        console.log(products?.product_sku);
        productSKU.push(products?.product_sku);
      });
      const GET_PRODUCTS = 
      gql`
      {
        products(
          filter:{
            sku:{in:[${productSKU}]}
          }
        
          pageSize: 15
         
        )
         {
          sort_fields{
            options{
              label
            }
          }
          aggregations{
            attribute_code
            options{
              label
              value
            }
          }
          
            page_info{
            total_pages
          }
            items{
              sales_unit_of_measure
              brand_name
              stock_status
              is_frozen
              sku
              name
              stock_status
              small_image{
                url
              }
             
              price_range{
                maximum_price{
                  final_price{
                    value
                  }
                }
              }
            }
        }
        }
    `;
    const { loading, error, data } = useQuery(GET_PRODUCTS);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    console.log(':::::::::::::',data);
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>My Orders</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        {displayMessage? <View style={{width:'100%'}}>
    <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
        <Image source={require('../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
        <View style={{marginHorizontal:width*0.022}}>
          <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  You added {data?.products?.items[0]?.name} to your 
            <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
            <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> shopping cart.</Text></TouchableOpacity>
          </Text>
        </View>
      </View>
    </View> : null}
        <KeyboardAvoidingView behavior='height' keyboardVerticalOffset={110} style={[styles.wishListOuterContainer,{display:wishListVisible}]}>
        <View style={styles.wishListClose}>
            <TouchableOpacity onPress={()=>{close()}}>
                <Image source={require('../assets/icons/close.png')} 
                style={styles.wishListCloseIcon}/>
            </TouchableOpacity>
        </View>
        <WishList/>
      </KeyboardAvoidingView>

        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={[styles.myAccountMenuText,{fontWeight:'700'}]}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <FlatGrid itemDimension={130} spacing={10} indicatorStyle={false} data={data.products.items}
        renderItem={({index,item})=>(
        <>
        <View style={{minHeight:height*0.40}}>
        <View style={[styles.productContainer,{flex:1}]}>
        <TouchableOpacity  onPress={()=>navigation.navigate('ProductPage',{sku:`"${item.sku}"`,title:item.name})}>
        <View style={{flexDirection:'row',justifyContent:'space-between'}}>
        <Text numberOfLines={1} style={styles.skuText}>{item.sku}</Text>
        <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible(item.product_sku):navigation.navigate('Login')}} style={{paddingRight:width*0.022}}>
            <Image style={{height:height*0.045,width:width*0.045,resizeMode:'contain',tintColor:'#999DA3'}} source={require('../assets/icons/tasks.png')}></Image>
        </TouchableOpacity>
        
            
        </View>
        {console.log(imageUrl+item.product_image)}
        <View style={styles.productImage}>
            <Image style={{resizeMode:'contain'}}  source={{uri:data.products?.items[index].small_image.url,height:height*0.150,width:width*0.350}}></Image>
        </View>
        <GetBrand data={data}></GetBrand>
        <Text numberOfLines={3} style={styles.productName}>
            {item.name}
        </Text>
        </TouchableOpacity>

        <View style={styles.priceContainer}>
            <TextInput keyboardType="numeric" onChangeText={newQuantity=>setQuantity(newQuantity)} key={item} style={styles.input}>
                1
            </TextInput>

            <Text style={styles.productPrice}>£{parseFloat(item.price_range.maximum_price.final_price.value).toFixed(2)} {units[item.sales_unit_of_measure-1]!=undefined?'/'+units[item.sales_unit_of_measure-1].label:''}</Text>
        </View>
            <CustomButton data={data} quantity={quantity} item={item} index={index}></CustomButton>
        
        </View>
        </View>
            </>
            )}
            
            >
            </FlatGrid>


        </ScrollView>
        </>
    )
}

export default PreviousPurchases;