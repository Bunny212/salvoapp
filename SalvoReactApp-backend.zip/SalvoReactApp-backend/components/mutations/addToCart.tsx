import { gql } from "@apollo/client";

export const ADD_TO_CART=gql`  
mutation AddProductsToCart(
    $cartId :String!
    $quantity:Float!
    $sku:String!
){
    addProductsToCart(
      cartId: $cartId
      cartItems: [
        {
          quantity: $quantity
          sku: $sku
        }
      ]
    ) {
      cart {
        items {
          uid
          product {

            name
            sku
            small_image{
              url
            }
            price_range{
              maximum_price{
                final_price{
                  value
                }
              }
            }
          }
          quantity
        }
        prices{
          subtotal_excluding_tax{
            value
          }
          grand_total{
            value
          }
        }
        shipping_addresses{
          available_shipping_methods{
            method_code
            carrier_code
            method_title
          }
          selected_shipping_method {
         amount {
           value
           currency
         }
         carrier_code
         carrier_title
         method_code
         method_title
         
       }
       }
        total_quantity
      }
      user_errors {
        code
        message
      }
    }
  }
`;

export type addProductsToCartResponseType = {
    cart: {
        items: {
            id:string,
          product: {
            name:string,
            sku :string,
          }
          quantity:number,
        }
      }
}