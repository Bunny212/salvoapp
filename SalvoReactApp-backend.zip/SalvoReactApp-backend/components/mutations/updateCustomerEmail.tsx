import { gql } from "@apollo/client";

export const UPDATE_EMAIL=gql`
mutation UpdateCustomerEmail($email:String! $password:String!){
    updateCustomerEmail(email: $email, password: $password) {
        customer {
            id
            }
      }
}
`;

export type updateCustomerEmailResponseType = {
    email:string
    password:string
}

