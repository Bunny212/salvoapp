import { gql } from "@apollo/client";

export const ADD_TO_WISHLIST=gql`
mutation amastyMultiWishListAddProduct($email:String! $wishlistId:String! $productSku:String! $productqty:String!){
    AmastyMultiWishListAddProduct(
        input: {
            customerEmail: $email,
            wishlistId: $wishlistId,
            productSku: $productSku,
            productqty: $productqty
        }
    ){
        wishlist_details{
            wishList_id
            wishList_name
            wishList_count
        }
    }
}
`;

export type amastyMultiWishListAddProductResponseType = {
    $email:string,
    $wishlistId:string,
    $productSku:string,
    $productqty:string,
}