import { gql } from "@apollo/client";

export const REWARD_POINTS=gql`
mutation UseRewardPoints($cartId:String! $points:Float!){
  useRewardPoints(input: { cart_id:$cartId points:$points }) {
    cart {
      email
      id
      is_virtual
      total_quantity
    }
    response
  }
}
`;

export type setBraintreeTokenResponseType = {
  cartId:string,
  points:number,
}