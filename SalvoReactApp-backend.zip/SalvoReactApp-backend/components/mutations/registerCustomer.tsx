import { gql } from "@apollo/client";

export const REGISTER_CUSTOMER=gql`  
  
mutation CreateCustomer(
    $firstname:String!
    $lastname:String!
    $email:String!
    $confirmPassword:String!
    $industry:Int!
    $stock_location:Int!
    $minimum_order_amount:Int!
    $how_did_you_hear:Int!
    $delivery_schedule: String!
    $shipment_days: String!
    ){
    createCustomer(
      input: {
        firstname: $firstname
        lastname: $lastname
        email: $email
        password: $confirmPassword
        is_subscribed: true
        industry:$industry
        stock_location:$stock_location
        minimum_order_amount:$minimum_order_amount
        how_did_you_hear:$how_did_you_hear
        delivery_schedule:$delivery_schedule
        shipment_days:$shipment_days
    }) {
      customer {
        
        allow_remote_shopping_assistance
        created_at
        date_of_birth
        default_billing
        default_shipping
        dob
        email
        firstname
        gender
        group_id
        id
        is_subscribed
        lastname
        middlename
        prefix
        suffix
        taxvat
      }
    }
  }
`;

export type RegisterCustomerResponseType = {
    firstname:string,
    lastname:string,
    email:string,
    confirmPassword:string,
    industry:number,
    stock_location:number,
    minimum_order_amount:number,
    how_did_you_hear:number
  }