import { gql } from "@apollo/client";

export const SET_DELIVERY_METHOD=gql`
mutation SetShippingMethod($cartId:String! $carrier_code:String! $method_code:String!){
    setShippingMethodsOnCart(input: {
      cart_id: $cartId
      shipping_methods: [
        {
          carrier_code: $carrier_code
          method_code: $method_code
        }
      ]
    }) {
      cart {
        shipping_addresses {
          selected_shipping_method {
            carrier_code
            method_code
            carrier_title
            method_title
          }
        }
      }
    }
  }
`;

export type setShippingMethodResponseType = {
    cartId:string
    carrier_code:string
    method_code:string
}