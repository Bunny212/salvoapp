import { gql } from "@apollo/client";

export const SET_SAVED_PAYMENT_METHOD=gql`
mutation SetPaymentMethodOnCart($cartId:String! $code:String! $nounce:String!){
  setPaymentMethodOnCart(
    input: {
      cart_id: $cartId
      payment_method: {
        code: $code
        braintree_cc_vault: { public_hash: $nounce }
      }
    }
  ) {
    cart {
      selected_payment_method {
        code
        title
      }
    }
  }
}

`;

export type setPaymentMethodOnCartResponseType = {
    cartId:string
    code:string
    public_hash:string
}