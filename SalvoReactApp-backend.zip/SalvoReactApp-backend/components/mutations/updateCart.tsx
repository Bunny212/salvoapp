import { gql } from "@apollo/client";

export const UPDATE_CART=gql`  
mutation UpdateCartItems(
    $cartId:String!
    $uid:ID!
    $quantity:Float!
    ){
    updateCartItems(
      input: {
        cart_id: $cartId,
        cart_items: [
          {
            cart_item_uid: $uid
            quantity: $quantity
          }
        ]
      }
    )
    {
      cart {
        items {
          uid
          product {
            name
            sku
            small_image{
              url
            }
            price_range{
              maximum_price{
                final_price{
                  value
                }
              }
            }
          }
          quantity
        }
        prices{
          subtotal_excluding_tax{
            value
          }
          grand_total{
            value
          }
        }
        shipping_addresses{
          selected_shipping_method {
         amount {
           value
           currency
         }
         carrier_code
         carrier_title
         method_code
         method_title
         
       }
       }
        total_quantity
      }
  }
  }  
`;

export type UpdateCartResponseType = {
  cart: {
    items: {
        id:string,
      product: {
        name:string,
        sku :string,
      }
      quantity:number,
    }
  }
}