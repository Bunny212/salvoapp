import { gql } from "@apollo/client";

export const CUSTOMER_ADDRESS=gql`mutation CreateCustomerAddress(
    $region:String!
    $region_code:String!
    $region_id:Int!
    $country_code:CountryCodeEnum!
    $street:[String]!
    $city:String!
    $postcode:String!
    $telephone:String!
    $firstname:String!
    $lastname:String!
    $company:String!
    
    ) {
    createCustomerAddress(input: {
      region: {
        region: $region
        region_code: $region_code
        region_id:$region_id
      }
      country_code:$country_code
      street: $street
      telephone: $telephone
      postcode: $postcode
      city: $city
      firstname: $firstname
      lastname: $lastname
      default_shipping: true
      default_billing: true
      company:$company
    }) {
      id
      region {
        region
        region_code
      }
      country_code
      street
      telephone
      postcode
      city
      default_shipping
      default_billing
    }
  }`

  export type CreateCustomerAddressResponseType = {
    region:string
    region_code:string
    region_id:number
    country_code:string
    street:string
    city:string
    postcode:string
    telephone:string
    firstname:string
    lastname:string
    company:string
}