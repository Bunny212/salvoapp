import { gql } from "@apollo/client";
export const SET_SHIPPING_ADDRESS=gql`  
mutation SetShippingAddress(
    $cartId:String!
    $firstName:String!   
    $lastName:String!
    $company:String!
    $street:[String]!
    $city:String!
    $region:String!
    $region_id:Int!
    $postcode:String!
    $country_code:String!
    $telephone:String!
    ){
    setShippingAddressesOnCart(
      input: {
        cart_id: $cartId
        shipping_addresses: [
          {
            address: {
              firstname: $firstName
              lastname: $lastName
              company: $company
              street: $street
              city: $city
              region: $region
              region_id: $region_id
              postcode: $postcode
              country_code: $country_code
              telephone: $telephone
              save_in_address_book: false
            }
          }
        ]
      }
    ) {
      cart {
        available_payment_methods{
          code
          title
        }
        shipping_addresses {
          firstname
          lastname
          company
          street
          city
          region {
            code
            label
            region_id
          }
          postcode
          telephone
          country {
            code
            label
          }
          available_shipping_methods{
            carrier_code
            carrier_title
            method_code
            method_title
          }
        }
      }
    }
  }
`;

export type setShippingAddressResponseType = {
    cartId:string,
    firstName:string,
    lastName:string,
    company:string,
    street:string,
    city:string,
    region:string,
    region_id:number,
    postcode:string,
    country:string,
    telephone:string
};