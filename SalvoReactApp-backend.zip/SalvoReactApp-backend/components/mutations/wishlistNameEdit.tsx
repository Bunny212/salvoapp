import { gql } from "@apollo/client";

export const EDIT_NAME=gql`
mutation amastyMultiWishListNameEdit($email:String! $wishlist_id:String! $wishlist_name:String!){
    AmastyMultiWishListNameEdit(
        input: {
            customerEmail: $email
            wishlistId: $wishlist_id
            wishlistName: $wishlist_name
        }
    ){
        message
        wishlist_details{
            wishList_id
            wishList_name
            wishList_count
        }
    }
}
`;

export type amastyMultiWishListNameEditResponseType = {
  email:string,
  wishlist_id:string,
  wishlist_name:string,
}