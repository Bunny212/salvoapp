import { gql } from "@apollo/client";
export const SET_BILLING_ADDRESS=gql`  
mutation setBillingAddress(
  $cartId:String!
  $firstName:String!   
  $lastName:String!
  $company:String!
  $street:[String]!
  $city:String!
  $region:String!
  $region_id:Int!
  $postcode:String!
  $country_code:String!
  $telephone:String!
  ){
    setBillingAddressOnCart(
    input: {
      cart_id: $cartId
      billing_address: {
          address: {
            firstname: $firstName
            lastname: $lastName
            company: $company
            street: $street
            city: $city
            region: $region
            region_id: $region_id
            postcode: $postcode
            country_code: $country_code
            telephone: $telephone
            save_in_address_book: false
        }
      }
    }
  ) {
    cart {
      available_payment_methods {
        code
        title
      }
      billing_address {
        firstname
        lastname
        company
        street
        city
        region {
          code
          label
          region_id
        }
        postcode
        telephone
        country {
          code
          label
        }
       
      }
      available_payment_methods {
        code
        title
      }
    }
  }
}
  
`;

export type setBillingAddressResponseType = {
    cartId:string,
    firstName:string,
    lastName:string,
    company:string,
    street:string,
    city:string,
    region:string,
    region_id:number,
    postcode:string,
    country:string,
    telephone:string
};