import { gql } from "@apollo/client";

export const REORDER=gql`  

mutation ReorderItems($orderNumber:String!){
    reorderItems(orderNumber: $orderNumber) 
     {
        cart {
          items {
            uid
            product {
  
              name
              sku
              small_image{
                url
              }
              price_range{
                maximum_price{
                  final_price{
                    value
                  }
                }
              }
            }
            quantity
          }
          prices{
            subtotal_excluding_tax{
              value
            }
            grand_total{
              value
            }
          }
          shipping_addresses{
            selected_shipping_method {
           amount {
             value
             currency
           }
           carrier_code
           carrier_title
           method_code
           method_title
           
         }
         }
          total_quantity
        }
      userInputErrors {
        code
        message
        path
      }
    }
  }  
`;

export type reorderItemsResponseType = {
   orderNumber:string
}