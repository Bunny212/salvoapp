import { gql } from "@apollo/client";

export const CHANGE_PASSWORD=gql`
mutation ChangeCustomerPassword($currentPassword: String! $newPassword:String!){
    changeCustomerPassword(currentPassword:$currentPassword, newPassword: $newPassword) {
      addresses {
        city
        company
        country_code
        country_id
        customer_id
        default_billing
        default_shipping
        fax
        firstname
        id
        lastname
        middlename
        postcode
        prefix
        region_id
        street
        suffix
        telephone
        vat_id
      }
      allow_remote_shopping_assistance
      compare_list {
        item_count
        uid
      }
      created_at
      created_in
      date_of_birth
      default_billing
      default_shipping
      dob
      email
      firstname
      gender
      group_id
      id
      is_subscribed
      lastname
      middlename
      minimum_order_amount
      shipment_days
      store_id
      suffix
      taxvat
      website_id
  
    }
  }  
`;

export type setChangeCustomerPasswordResponseType = {
    newPassword:string
    currentPassword:string
}