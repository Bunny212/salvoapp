import { gql } from "@apollo/client";

export const DELETE_ITEM=gql`
mutation RemoveItemFromCart(
    $cartId:String!
    $uid:ID!
    ){
    removeItemFromCart(
      input: {
        cart_id: $cartId,
        cart_item_uid: $uid
      }
    )
    {
      cart {
        items {
          uid
          product {
            name
            sku
            price_range{
              maximum_price{
                final_price{
                  value
                }
              }
            }
          }
          quantity
        }
        prices{
          subtotal_excluding_tax{
            value
          }
          grand_total{
            value
          }
        }
        shipping_addresses{
          selected_shipping_method {
         amount {
           value
           currency
         }
         carrier_code
         carrier_title
         method_code
         method_title
         
       }
       }
        total_quantity
      }
  }
  }  `;

export type UpdateCartResponseType = {
  cart: {
    items: {
        id:string,
      product: {
        name:string,
        sku :string,
      }
      quantity:number,
    }
  }
}