import { gql } from "@apollo/client"

export const ORDER_ADDITIONS=gql`
mutation OrderAdditionData($parent_order_id:String! $new_child_order_id:String!){
    OrderAdditionalData(input: { parent_order_id: $parent_order_id ,new_child_order_id: $new_child_order_id}) {
      message
      success
    }
  }
`;
export type OrderAdditionDataResponseType  = {
    parent_order_id:string,
    new_child_order_id:string,
}