import { gql } from "@apollo/client";

export const CREATE_WISHLIST=gql`
mutation amastyMultiWishListCreate($email:String! $wishlistName:String!){
    AmastyMultiWishListCreate(
        input:{
            customerEmail: $email,
            wishListName: $wishlistName,
            wishListId: ""
        }
    ){
        wishlist_details{
            wishList_id
            wishList_name
            wishList_count
        }
        message        
    }
}
`;

export type amastyMultiWishListCreateResponseType = {
    email:string
    wishlistName:string
}