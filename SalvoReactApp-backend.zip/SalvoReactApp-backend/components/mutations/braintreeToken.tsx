import { gql } from "@apollo/client";

export const BRAINTREE_TOKEN=gql`
mutation {
    createBraintreeClientToken
  }
`;

export type setBraintreeTokenResponseType = {
}