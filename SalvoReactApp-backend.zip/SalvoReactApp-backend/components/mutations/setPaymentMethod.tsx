import { gql } from "@apollo/client";

export const SET_PAYMENT_METHOD=gql`
mutation SetPaymentMethod($cartId:String! $code:String! $nounce:String!){
    setPaymentMethodOnCart(input: {
        cart_id: $cartId
        payment_method: {
            code:$code
           braintree:{
             is_active_payment_token_enabler:true,
             payment_method_nonce:$nounce
           }
          } 
    }) {
      cart {
        selected_payment_method {
          code
        }
      }
    }
  }
`;

export type setPaymentMethodResponseType = {
    cartId:string
    code:string
    token:string
}