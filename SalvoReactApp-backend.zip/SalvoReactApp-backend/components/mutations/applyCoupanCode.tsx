import { gql } from "@apollo/client";

export const APPLY_COUPAN_CODE=gql`
mutation ApplyCoupanToCart($cartId:String! $coupan_code:String!){
    applyCouponToCart(
      input: {
        cart_id: $cartId
        coupon_code: $coupan_code
      }
    ) {
      cart {
        applied_coupons {
          code
        }
      }
    }
  }
`;

export type setShippingMethodResponseType = {
    cartId:string
    coupon_code:string
}