import { gql } from "@apollo/client";

export const DELETE_WISHLIST=gql`
mutation amastyMultiWishListDelete($email:String! $wishlistId:String!){
    AmastyMultiWishListDelete(
        input:{
            wishListId: $wishlistId,
            customerEmail: $email
        }
    ){
        wishlist_details{
            wishList_id
            wishList_name
            wishList_count
        }
        message
    }
}
`;

export type amastyMultiWishListDeleteResponseType = {
    wishlistId:string
    email:string,
}