import { gql } from "@apollo/client";

export const LOGIN_CUSTOMER=gql`  
mutation LoginCustomer(
  $email:String! 
  $password:String!
  ){
    generateCustomerToken(
      email: $email
      password: $password
    ) {
      token
    }
  }
`;

export type LoginCustomerResponseType = {
    email:String,
    password:String,
}