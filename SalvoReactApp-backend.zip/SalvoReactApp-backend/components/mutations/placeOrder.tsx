import { gql } from "@apollo/client";

export const PLACE_ORDER=gql`
mutation PlaceOrder($cartId:String! $delivery_date:String!){
    placeOrder(input: {cart_id: $cartId delivery_date: $delivery_date}) {
        order {
          order_number
        }
      }
  }
`;

export type setPlaceOrderResponseType = {
    cartId:string
}