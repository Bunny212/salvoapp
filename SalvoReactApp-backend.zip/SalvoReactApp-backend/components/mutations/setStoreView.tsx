import { gql } from "@apollo/client";

export const SET_STORE_VIEW=gql`
mutation setWebsite($customerEmail:String!){
    SetWebsite(
        input: {
            customerEmail: $customerEmail,
        }
    ){
        message
    }
}
`;

export type setShippingMethodResponseType = {
    customerEmail:string
}