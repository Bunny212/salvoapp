import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import CheckBox from '@react-native-community/checkbox';
import { useDispatch, useSelector } from "react-redux";
import { useMutation } from "@apollo/client";
import { CHANGE_PASSWORD } from "./mutations/changeCustomerPassword";
import { UPDATE_EMAIL } from "./mutations/updateCustomerEmail";
import { useRef } from "react";
import { SIGN_OUT } from "./mutations/signOut";
import { customerToken, setOrderIdOfProccessingOrders } from "./redux/actions";
const ChangePassword = ({navigation}) => {
    const CUSTOMER=useSelector(state=>state.customer);
    const [email,setEmail] = useState('');
    const [currentPassword,setCurrentPassword] = useState('');
    const [newPassword,setNewPassword] = useState('');
    const [confirmPassword,setConfirmPassword] = useState('');
    const [toggleCheckBox, setToggleCheckBox] = useState(false);
    const [showPassword, setShowPassword] = useState(true);
    const [tooltipVisible, setTooltipVisible] = useState('none');
    const [checkBoxEmail, setCheckBoxEmail] = useState(false);
    const [checkBoxPassword, setCheckBoxPassword] = useState(true);
    const [checkRemoteShipping, setCheckBoxRemoteShipping] = useState(false);
    const [changePasswordVisible, setChangePasswordVisible] = useState('flex');
    const [changeEmailVisible, setChangeEmailVisible] = useState('none');
    const [showCurrentPassword, setShowCurrentPassword] = useState(true);
    const [toggleShowCurrentPassword, setToggleShowCurrentPassword] = useState(false);
    const newErrors = {};
    const [errorsMsg, setErrorsMsg] = useState({});
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const dispatch=useDispatch()
    const [displayMessage,setDisplayMessage]=useState(false);
    const inputRefCurrent=useRef(null);
    const inputRefNew=useRef(null);
    const inputRefConfirm=useRef(null);

    const changeTooltipVisible = () =>{
        if(tooltipVisible=='none'){
         setTooltipVisible('flex');
        }else{
         setTooltipVisible('none');
        }
    } 
     const handleChangePasswordVisible = () =>{
        if(changePasswordVisible=='none'){
         setChangePasswordVisible('flex');
        }else{
         setChangePasswordVisible('none');
        }
    }
    const handleChangeEmailVisible = () =>{
        if(changeEmailVisible=='none'){
         setChangeEmailVisible('flex');
        }else{
         setChangeEmailVisible('none');
        }
    }

    function AccountInfoSuccess () {
        return(
            <>
            <View style={{width:'100%'}}>
                <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
                    <Image source={require('../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
                    <View style={{}}>
                    <Text style={{color:'#006400',fontSize:height*0.018}}> You saved the account information.
                    </Text>
                    </View>
                </View>
            </View>
            </>
        )
}
    const [ChangeCustomerPassword]=useMutation(CHANGE_PASSWORD)
    const changePassword=async (currentPassword,newPassword)=>{
        try{   
            const{
              data,errors,
            }= await ChangeCustomerPassword({
                variables:{
                    currentPassword,
                    newPassword
                }
            });
            if(data!=undefined){
            inputRefCurrent.current.clear();
            inputRefNew.current.clear();
            inputRefConfirm.current.clear();
            }
          }catch(error){
            if(Object.keys(newErrors).length==0){
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error.message);
            }
        }
    }
    const [UpdateCustomerEmail]=useMutation(UPDATE_EMAIL);
    const updateEmail=async (email,password)=>{
        try{   
            const{
              data,errors,
            }= await UpdateCustomerEmail({
                variables:{
                    email,
                    password
                }
            });

          
          }catch(error){
            console.log(error);
          }
    }
    const scrollViewRef = useRef(null);
    const [signOut]=useMutation(SIGN_OUT);
    const SignOut=async()=>{
       try{
           const{
             data,errors,
           }=await signOut();
           if(data.revokeCustomerToken.result==true){
                dispatch(customerToken(null));
           }
         }catch(error){
           console.log(error);
         }
    }
    if (displayServerError) {
        setTimeout(() => {
          setDisplayMessage(false);
          setDisplayServerErrorMsg(false);
        }, 12000);
      }

    const validate=()=>{
        if(!currentPassword){
            newErrors.currentPassword = "This is a required field";
        }
        if(!newPassword){
            newErrors.newPassword = "This is a required field";
        }else if (newPassword.length < 8) {
            newErrors.newPassword = 'Password must be at least 8 characters';
        }
        if(!confirmPassword){
            newErrors.confirmPassword = "This is a required field";
        }else if (confirmPassword.length < 8) {
            newErrors.confirmPassword = 'Password must be at least 8 characters';
        }if (newPassword != confirmPassword) {
            newErrors.confirmPassword = "Please enter the same value again.";
        }
        else{
            if(newPassword==confirmPassword){
                changePassword(currentPassword,newPassword);
                setDisplayMessage(true);
                setTimeout(() => {
                    setDisplayMessage(false);
                    SignOut();
                    navigation.navigate('Login');    
                }, 12000);
            }
        }
        setErrorsMsg(newErrors);
        scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });
        return Object.keys(newErrors).length === 0;    
    }
    return(
        <>
        <ScrollView ref={scrollViewRef} style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>Edit Account Information</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        {displayMessage? <View><AccountInfoSuccess/></View> : <View></View>}
        {/* Server errors */}
        {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={{padding:height*0.022}}>
            <Text style={[styles.headingTitle,{fontSize:height*0.028}]}>Account Information</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>First Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.firstname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Last Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER.customer.lastname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setCheckBoxEmail(!checkBoxEmail);handleChangeEmailVisible()}}>
                    <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={checkBoxEmail} onValueChange={()=>{setCheckBoxEmail(!checkBoxEmail);handleChangeEmailVisible()}}></CheckBox>
                    <Text style={styles.showPassword}>Change Email</Text>
                </TouchableOpacity>
            </View>

            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setCheckBoxPassword(!checkBoxPassword);handleChangePasswordVisible()}}>
                    <CheckBox checked tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={checkBoxPassword} onValueChange={()=>{setCheckBoxPassword(!checkBoxPassword);handleChangePasswordVisible()}}></CheckBox>
                    <Text style={styles.showPassword}>Change Password</Text>
                </TouchableOpacity>
            </View>

            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setCheckBoxRemoteShipping(!checkRemoteShipping)}}>
                    <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={checkRemoteShipping} onValueChange={()=>{setCheckBoxRemoteShipping(!checkRemoteShipping)}}></CheckBox>
                    <Text style={styles.showPassword}>Allow remote shopping assistance </Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>changeTooltipVisible()}>
                    <Image source={require('../assets/icons/qmark.png')}
                        style={styles.questionIcon}/>
                </TouchableOpacity>
            </View>

            <View style={{display:tooltipVisible,position:'absolute'}}>
                    <View style={styles.tooltipText}>
                    <Text>This allows merchants to "see what you see" and take actions on your 
                        behalf in order to provide better assistance.</Text>
                    </View>
            </View>
        </View>
        <View style={{paddingRight:height*0.022,paddingLeft:height*0.022,display:changeEmailVisible}}>
            <View style={{}}>
                <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Change Email</Text>
                <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014,marginBottom:height*0.014}]}></View>
            </View>
            <View style={{paddingBottom:height*0.022}}>
                <View style={{flexDirection:'row'}}>
                    <Text style={styles.textInputLable}>Email</Text>
                    <Text style={{color:'red'}}>  *</Text>
                </View>
                <TextInput onChangeText={newEmail=>setEmail(newEmail)} style={styles.textInput}>{CUSTOMER.customer.email}</TextInput>
            </View>
        </View>

            <View style={[styles.accountInputField,{display:changeEmailVisible=='none' && changePasswordVisible=='none'? 'none':'flex'}]}>
                    <View style={{flexDirection:'row'}}>
                        <Text style={styles.textInputLable}>Current Password</Text>
                        <Text style={{color:'red'}}>  *</Text>
                    </View>
                    <TextInput ref={inputRefCurrent} value={currentPassword} onChangeText={newCurrentPassword=>setCurrentPassword(newCurrentPassword)} style={styles.textInput} 
                    secureTextEntry={showPassword}/>
                    {errorsMsg.currentPassword && <Text style={{color:'#e02b27',marginTop:height*0.010}}>{errorsMsg.currentPassword}</Text>}
                </View>
                 <View style={{display:changePasswordVisible}}>

                <View style={styles.accountInputField}>
                    <View style={{flexDirection:'row'}}>
                        <Text style={styles.textInputLable}>New Password</Text>
                        <Text style={{color:'red'}}>  *</Text>
                    </View>
                    <TextInput ref={inputRefNew} value={newPassword} onChangeText={newNewPassword=>setNewPassword(newNewPassword)} style={styles.textInput}
                    secureTextEntry={showPassword}/>
                    {errorsMsg.newPassword && <Text style={{color:'#e02b27',marginTop:height*0.010}}>{errorsMsg.newPassword}</Text>}
                </View>

                <View style={styles.accountInputField}>
                    <View style={{flexDirection:'row'}}>
                        <Text style={styles.textInputLable}>Confirm New Password</Text>
                        <Text style={{color:'red'}}>  *</Text>
                    </View>
                    <TextInput ref={inputRefConfirm} value={confirmPassword} onChangeText={newConfirmPassword=>setConfirmPassword(newConfirmPassword)} style={styles.textInput}
                    secureTextEntry={showPassword}/>
                    {errorsMsg.confirmPassword && <Text style={{color:'#e02b27',marginTop:height*0.010}}>{errorsMsg.confirmPassword}</Text>}
                </View>
                </View>
                <View style={[styles.accountInputField,{display:changeEmailVisible=='none' && changePasswordVisible=='none'? 'none':'flex'}]}>
                    <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setToggleCheckBox(!toggleCheckBox);setShowPassword(!showPassword)}}>
                        <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} onValueChange={()=>{setToggleCheckBox(!toggleCheckBox);setShowPassword(!showPassword)}} value={toggleCheckBox} ></CheckBox>
                        <Text style={styles.showPassword}>Show Password</Text>
                    </TouchableOpacity>
                </View>
              
                <View style={styles.accountInputField}>
                    <TouchableOpacity onPress={()=>validate()} style={styles.saveBtn}>
                        <Text style={styles.saveBtnText}>
                            Save
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
            
        </>
    )
}

export default ChangePassword;