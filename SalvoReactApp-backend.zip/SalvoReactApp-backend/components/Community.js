import React from "react";
import { View, Text,Dimensions,Image,TouchableOpacity, ScrollView, useWindowDimensions, ActivityIndicator } from "react-native";
import styles from "../styles/styles";
import { RenderHTML, RenderHTMLConfigProvider,TRenderEngineProvider} from 'react-native-render-html';
import { gql, useQuery } from "@apollo/client";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
const { width, height } = Dimensions.get('window');
const Community = ({navigation}) => {
    const GET_COMMUNITY = gql`
    {
        cmsPage(identifier: "community") {
          identifier
          url_key
          title
          content
        }
      }
      `;
      const { loading, error, data } = useQuery(GET_COMMUNITY);
      const {width}=useWindowDimensions();
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      const html={
        html:data.cmsPage.content       
      }
    return(
        <>
        <ScrollView>
        <TRenderEngineProvider>
            <RenderHTMLConfigProvider>
              <ScrollView style={{padding:height*0.020,backgroundColor:'#fff'}}>
                <RenderHTML 
                    classesStyles={stylesClass} 
                    tagsStyles={stylesTags} 
                    contentWidth={width} 
                    source={html}>
                </RenderHTML>
              </ScrollView>
            </RenderHTMLConfigProvider>
        </TRenderEngineProvider> 
                
            </ScrollView>
        </>
    )
}

export default Community;