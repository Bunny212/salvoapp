import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal, Platform} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import CheckBox from '@react-native-community/checkbox';
import { useDispatch, useSelector } from "react-redux";
import { useMutation } from "@apollo/client";
import { CHANGE_PASSWORD } from "./mutations/changeCustomerPassword";
import { UPDATE_EMAIL } from "./mutations/updateCustomerEmail";
import { useRef } from "react";
import { customerDetails } from "./redux/actions";
import { SIGN_OUT } from "./mutations/signOut";

import { customerToken,TotalQuantity,NumberofItems,AddtoCart,setTotalPrice,setSubTotal,setShippingValue} from "./redux/actions";
const EditAccountInfo = ({navigation}) => {
    const dispatch=useDispatch();
    const CUSTOMER=useSelector(state=>state?.customer);
    const [checkBoxEmail, setCheckBoxEmail] = useState(false);
    const [checkBoxPassword, setCheckBoxPassword] = useState(false);
    const [checkRemoteShipping, setCheckBoxRemoteShipping] = useState(false);

    const [email, setEmail]= useState(CUSTOMER?.customer?.email);
    const [currentPassword,setCurrentPassword] = useState('');
    const [newPassword,setNewPassword] = useState('');
    const [confirmPassword,setConfirmPassword] = useState('');

    const [toggleCheckBox, setToggleCheckBox] = useState(false);

    const [showPassword, setShowPassword] = useState(true);
    const [toggleShowPassword, setToggleShowPassword] = useState(false);

    const [showCurrentPassword, setShowCurrentPassword] = useState(true);
    const [toggleShowCurrentPassword, setToggleShowCurrentPassword] = useState(false);

    const [tooltipVisible, setTooltipVisible] = useState('none');
    const [changePasswordVisible, setChangePasswordVisible] = useState('none');
    const [changeEmailVisible, setChangeEmailVisible] = useState('none');
    const newErrors = {};
    const [errorsMsg, setErrorsMsg] = useState({});
    const [serverError,setServerErrorMsg] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const [displayMessage,setDisplayMessage]=useState(false);

    const inputRefCurrent=useRef(null);
    const inputRefNew=useRef(null);
    const inputRefConfirm=useRef(null);
    const inputRefEmail=useRef(null);

    const changeTooltipVisible = () =>{
        if(tooltipVisible=='none'){
         setTooltipVisible('flex');
        }else{
         setTooltipVisible('none');
        }
    }
    
    const handleChangePasswordVisible = () =>{
        if(changePasswordVisible=='none'){
         setChangePasswordVisible('flex');
        }else{
         setChangePasswordVisible('none');
        }
    }

    const handleChangeEmailVisible = () =>{
        if(changeEmailVisible=='none'){
         setChangeEmailVisible('flex');
        }else{
         setChangeEmailVisible('none');
        }
    }
    const scrollViewRef = useRef(null);
    function AccountInfoSuccess () {
        return(
            <>
            <View style={{width:'100%'}}>
                <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
                    <Image source={require('../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
                    <View style={{marginHorizontal:width*0.020}}>
                    <Text style={{color:'#006400',fontSize:height*0.018}}> You saved the account information.
                    </Text>
                    </View>
                </View>
            </View>
            </>
        )
}

    const [ChangeCustomerPassword]=useMutation(CHANGE_PASSWORD)
    const changePassword=async (currentPassword,newPassword)=>{
        try{   
            const{
              data,errors,
            }= await ChangeCustomerPassword({
                variables:{
                    currentPassword,
                    newPassword
                }
            });
            if(data!=undefined){
                inputRefCurrent.current.clear();
                inputRefNew.current.clear();
                inputRefConfirm.current.clear();
                }

          }catch(error){
            if(Object.keys(newErrors).length==0){
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error.message);
            }
        }
    }
    const [UpdateCustomerEmail]=useMutation(UPDATE_EMAIL);
    const updateEmail=async (email,password)=>{
        try{   
            const{
              data,errors,
            }= await UpdateCustomerEmail({
                variables:{
                    email,
                    password
                }
            });
            if(data!=undefined){
                inputRefCurrent.current.clear();
                inputRefEmail.current.clear();
                }
             
          }catch(error){
            if(Object.keys(newErrors).length==0){
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error.message);
            }
          }
    }

    const [signOut]=useMutation(SIGN_OUT);
    const SignOut=async()=>{
       try{
           const{
             data,errors,
           }=await signOut();
           if(data.revokeCustomerToken.result==true){
                dispatch(customerToken(null));
                dispatch(TotalQuantity(0));
                dispatch(NumberofItems(0));
                dispatch(AddtoCart([]));
                dispatch(setTotalPrice(0));
                dispatch(setSubTotal(0))
                dispatch(setShippingValue(0));
                navigation.navigate('Login');    
           }
         }catch(error){
           console.log(error);
           setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message); 
         }
    }

    if (displayServerError) {
        setTimeout(() => {
          setDisplayMessage(false);
          setDisplayServerErrorMsg(false);
        }, 12000);
      }

    const validate=()=>{
        if(!email){
            newErrors.email = "This is a required field";
        }
        if(!currentPassword){
            newErrors.currentPassword = "This is a required field";
        }
        else{
            if(checkBoxEmail){
                updateEmail(email,currentPassword);
                setDisplayMessage(true);
                setTimeout(() => {
                    setDisplayMessage(false);
                    SignOut();
                    navigation.navigate('Login');    
                }, 10000);
            }
            if(checkBoxPassword){
                changePassword(currentPassword,newPassword);
                setDisplayMessage(true);
                setTimeout(() => {
                    setDisplayMessage(false);
                    SignOut();
                }, 10000);

            }
            
        }
        setErrorsMsg(newErrors);
        scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });
        return Object.keys(newErrors).length === 0;    
    }

    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}} ref={scrollViewRef}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>Edit Account Information</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER?.customer?.email}</Text>
        </View>

        {displayMessage? <View><AccountInfoSuccess/></View> : <View></View>}

        {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<View></View>}

        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={{padding:height*0.022}}>
            <Text style={[styles.headingTitle,{fontSize:height*0.028}]}>Account Information</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>First Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER?.customer?.firstname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Last Name</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput style={styles.textInput}>{CUSTOMER?.customer?.lastname}</TextInput>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setCheckBoxEmail(!checkBoxEmail);handleChangeEmailVisible()}}>
                    {Platform.OS==='ios'?                     <CheckBox tintColor={'#9E663C'} boxType="square" style={styles.checkbox} value={checkBoxEmail} ></CheckBox>:
                                        <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={checkBoxEmail}></CheckBox>}

                    <Text style={styles.showPassword}>Change Email</Text>
                </TouchableOpacity>
            </View>

            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setCheckBoxPassword(!checkBoxPassword);handleChangePasswordVisible()}}>
                {Platform.OS==='ios'? 
                    <CheckBox tintColor={'#9E663C'} boxType="square" style={styles.checkbox} value={checkBoxPassword} ></CheckBox>:<CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={checkBoxPassword} ></CheckBox>}
                    <Text style={styles.showPassword}>Change Password</Text>
                </TouchableOpacity>
            </View>

            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setCheckBoxRemoteShipping(!checkRemoteShipping)}}>
                    {Platform.OS==='ios'?                    <CheckBox tintColor={'#9E663C'} boxType="square" style={styles.checkbox} value={checkRemoteShipping}></CheckBox>:                    <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={checkRemoteShipping}></CheckBox>}

                    <Text style={styles.showPassword}>Allow remote shopping assistance </Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>changeTooltipVisible()}>
                    <Image source={require('../assets/icons/qmark.png')}
                        style={styles.questionIcon}/>
                </TouchableOpacity>
            </View>
            <View style={{display:tooltipVisible,position:'absolute'}}>
                    <View style={styles.tooltipText}>
                    <Text>This allows merchants to "see what you see" and take actions on your 
                        behalf in order to provide better assistance.</Text>
                    </View>
            </View>
        </View>

        <View style={{paddingRight:height*0.022,paddingLeft:height*0.022,display:changeEmailVisible}}>
            <View style={{}}>
                {checkBoxEmail && checkBoxPassword?<Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Change Email and Password</Text>:
                <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Change Email</Text>}
                <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014,marginBottom:height*0.014}]}></View>
            </View>
            <View style={{paddingBottom:height*0.022}}>
                <View style={{flexDirection:'row'}}>
                    <Text style={styles.textInputLable}>Email</Text>
                    <Text style={{color:'red'}}>  *</Text>
                </View>
                <TextInput style={styles.textInput} ref={inputRefEmail} onChangeText={newEmail=>{setEmail(newEmail)}}>{CUSTOMER?.customer?.email}</TextInput>
                {errorsMsg.email && <Text style={{color:'#e02b27',marginTop:height*0.010}}>{errorsMsg.email}</Text>}
            </View>
            {checkBoxPassword && checkBoxEmail?<View></View>:
            <View>
                <View style={{flexDirection:'row'}}>
                    <Text style={styles.textInputLable}>Current Password</Text>
                    <Text style={{color:'red'}}>  *</Text>
                </View>
                <TextInput ref={inputRefCurrent} value={currentPassword} onChangeText={newCurrentPassword=>setCurrentPassword(newCurrentPassword)} style={styles.textInput} 
                    secureTextEntry={showPassword}/>
                {errorsMsg.currentPassword && <Text style={{color:'#e02b27',marginTop:height*0.010}}>{errorsMsg.currentPassword}</Text>}
            </View>}
         
        </View>

        <View style={{display:changePasswordVisible,paddingRight:height*0.022,paddingLeft:height*0.022}}>
            {checkBoxPassword && checkBoxEmail?<View></View>:
            <View style={{}}>
                <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Change Password</Text>
                <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014,marginBottom:height*0.014}]}></View>
            </View>}
            <View style={{paddingBottom:height*0.022}}>
                <View style={{flexDirection:'row'}}>
                    <Text style={styles.textInputLable}>Current Password</Text>
                    <Text style={{color:'red'}}>  *</Text>
                </View>
                <TextInput ref={inputRefCurrent} value={currentPassword} onChangeText={newCurrentPassword=>setCurrentPassword(newCurrentPassword)} style={styles.textInput} 
                secureTextEntry={showPassword}/>
            </View>

            <View style={{paddingBottom:height*0.022}}>
                <View style={{flexDirection:'row'}}>
                    <Text style={styles.textInputLable}>New Password</Text>
                    <Text style={{color:'red'}}>  *</Text>
                </View>
                <TextInput ref={inputRefNew} value={newPassword} onChangeText={newNewPassword=>setNewPassword(newNewPassword)} style={styles.textInput}
                    secureTextEntry={showPassword}/>
            </View>

            <View style={{}}>
                <View style={{flexDirection:'row'}}>
                    <Text style={styles.textInputLable}>Confirm New Password</Text>
                    <Text style={{color:'red'}}>  *</Text>
                </View>
                <TextInput ref={inputRefConfirm} value={confirmPassword} onChangeText={newConfirmPassword=>setConfirmPassword(newConfirmPassword)} style={styles.textInput}
                    secureTextEntry={showPassword}/>
            </View>
           
         
            {/* <View style={{paddingRight:height*0.022,paddingTop:height*0.022}}>
                <TouchableOpacity onPress={() => {setToggleShowPassword(!toggleShowPassword);setShowPassword(!showPassword)}}>
                    <View style={{flexDirection:'row'}} >
                        {Platform.OS==='ios'?<CheckBox tintColor={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleShowPassword} onValueChange={()=>{setToggleShowPassword(!toggleShowPassword);setShowPassword(!showPassword)}}></CheckBox>
:                   <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleShowPassword} onValueChange={()=>{setToggleShowPassword(!toggleShowPassword);setShowPassword(!showPassword)}}></CheckBox>
}
                     <Text style={styles.showPassword}>Show Password</Text>
                    </View>
                </TouchableOpacity>
            </View> */}
        </View>
        {!checkBoxPassword && !checkBoxEmail?<View></View>:
            <View style={styles.accountInputField}>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={() => {setToggleCheckBox(!toggleCheckBox);setShowPassword(!showPassword)}}>
                    {Platform.OS==='ios'?   <CheckBox tintColor={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleCheckBox} ></CheckBox>:  <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} onValueChange={()=>{setToggleCheckBox(!toggleCheckBox);setShowPassword(!showPassword)}} value={toggleCheckBox} ></CheckBox>}
                  
                    <Text style={styles.showPassword}>Show Password</Text>
                </TouchableOpacity>
            </View>}
        <View style={styles.saveBtnBox}>
            <TouchableOpacity onPress={()=>validate()} style={styles.saveBtn}>
                <Text style={styles.saveBtnText}>
                    Save
                </Text>
            </TouchableOpacity>
        </View>
        </ScrollView>
        </>
    )
}

export default EditAccountInfo;