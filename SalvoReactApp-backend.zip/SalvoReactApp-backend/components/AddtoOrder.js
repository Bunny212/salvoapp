import React ,{ useState } from "react";    
import { View,Text,TextInput,TouchableOpacity,Dimensions } from "react-native";
import styles from "../styles/styles";
const {width,height} = Dimensions.get('screen');
import DropDownPicker from 'react-native-dropdown-picker';
import CartPage from "./CartPage";
import { ScrollView } from "react-native-gesture-handler";

const AddToOrder = () =>{
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(null);
    const [items, setItems] = useState([
        {label: 'A', value: 'a'},
        {label: 'B', value: 'b'},
        {label: 'C', value: 'c'},
        {label: 'D', value: 'd'},
    ]);

    return(
        <>
        <ScrollView>
        <View style={{padding:height*0.020}}>
          <Text style={styles.cartTitle}>Shopping Cart</Text>
        </View>
        <View style={{paddingLeft:height*0.020}}>
            <Text style={{color:'#000',fontSize:height*0.026,lineHeight:height*0.034}}>You are adding items to order #000000</Text>
        </View>
        <View style={{paddingLeft:height*0.020,paddingTop:height*0.018}}>
            <Text style={{color:'#000',fontSize:height*0.020}}>This order will be delievered on yyyy-mm-dd</Text>
        </View>
        <View style={{paddingLeft:height*0.020,paddingTop:height*0.018,paddingRight:height*0.018}}>
            <Text style={{color:'#000',fontSize:height*0.020}}>
                Select a different order below, or select "Create new order" to create a new order instead
            </Text>
        </View>
        <View style={{paddingLeft:height*0.020,paddingTop:height*0.018,paddingRight:height*0.018}}>
            <View style={{zIndex:1}}>
                <DropDownPicker
                    placeholder="Order #000000000 for £price.00 being delievered on YYYY/MM/DD"
                    dropDownContainerStyle={styles.dropdownContainerStyle}
                    style={styles.dropdownStyle}              
                    containerStyle={[styles.filterButton,{marginTop:height*0.020,width:'100%'}]}
                    open={open}
                    value={value}
                    items={items}
                    setOpen={setOpen}
                    setValue={setValue}
                    setItems={setItems}
                />
            </View>
            <View style={{marginTop:height*0.020}}>
                <TouchableOpacity style={[styles.summaryButton,{width:width*0.26}]}>
                    <Text style={styles.summaryButtonText}>Confirm</Text>
                </TouchableOpacity>
            </View>
        </View>
        <View>
            <CartPage/>
        </View>
        </ScrollView>
        </>
    )
}

export default AddToOrder;