import React,{useState} from 'react';
import {View, StyleSheet, ScrollView,Button,Text,Dimensions,TouchableOpacity,Modal,Pressable,ActivityIndicator, Platform, useWindowDimensions } from 'react-native';
import styles from '../styles/styles';
import DropDownPicker from 'react-native-dropdown-picker';
import stylesIpad from '../styles/stylesIpad';


const { width, height } = Dimensions.get('window')


  const Sort = ({open,value,items,setOpen,setValue,setItems}) => {
    console.log('Sort Value::::::::::::::::::::',value);
    console.log(setValue);
    if(Platform.isPad){
      return (
        <DropDownPicker
              textStyle={[stylesIpad.filterButtonText,{textAlign:'center',fontSize:useWindowDimensions().height*0.018}]}
              style={[stylesIpad.dropdownStyle,{backgroundColor:'#fff',  minHeight:useWindowDimensions().height*0.060,
              borderWidth:useWindowDimensions().height*0.001,
              paddingRight:useWindowDimensions().width*0.020,}]}
              containerStyle={[stylesIpad.filterButtonContainerStyle,{zIndex:1}]}
              dropDownContainerStyle={[stylesIpad.dropdownContainerStyle,{backgroundColor:'#fff'}]}
              zIndex={1}
              open={open}
              value={value}
              items={items}
              setOpen={setOpen}
              setValue={setValue}
              setItems={setItems}
              selectedItemContainerStyle={{
               display:'none',
              }}
            />
    );
    }else{
    return (
        <DropDownPicker
              textStyle={[styles.filterButtonText,{textAlign:'center'}]}
              style={[styles.dropdownStyle,{backgroundColor:'#fff'}]}
              containerStyle={[styles.filterButtonContainerStyle,{zIndex:1}]}
              dropDownContainerStyle={[styles.dropdownContainerStyle,{backgroundColor:'#fff'}]}
              zIndex={1}
              open={open}
              value={value}
              items={items}
              setOpen={setOpen}
              setValue={setValue}
              setItems={setItems}
              selectedItemContainerStyle={{
               display:'none',
              }}
            />
    );
            }
  };
    
  
export default Sort;
