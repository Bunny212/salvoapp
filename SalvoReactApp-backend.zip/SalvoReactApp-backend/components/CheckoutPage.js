import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator, BackHandler, Platform, useWindowDimensions} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useEffect, useState } from "react";
import RadioButtonRN from 'radio-buttons-react-native';
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch, useSelector } from "react-redux";
import { gql, useMutation, useQuery } from "@apollo/client";
import { SET_DELIVERY_METHOD } from "./mutations/setShippingMethod";
import { APPLY_COUPAN_CODE } from "./mutations/applyCoupanCode";
import { decrement, increment, setAddress, setPaymentMethod, setShippingMethods, SHIPPING_METHODS } from "./redux/actions";
import { SET_PAYMENT_METHOD } from "./mutations/setPaymentMethod";
import { PLACE_ORDER } from "./mutations/placeOrder";
import { BRAINTREE_TOKEN } from "./mutations/braintreeToken";
import { SET_SHIPPING_ADDRESS } from "./mutations/setShippingAddress";
import { SET_BILLING_ADDRESS } from "./mutations/setBillingAddress";
import { REWARD_POINTS } from "./mutations/useRewardPoints";
import { ORDER_ADDITIONS } from "./mutations/orderAdditionPlaceOrder";
import { Calendar } from "react-native-calendars";
import moment from "moment";
import Modal from "react-native-modal";
import { CreditCardInput } from "react-native-credit-card-input";
import RNBraintree from '@ekreative/react-native-braintree';
import { useRef } from "react";
import RadioButton from "radio-button-react-native";
import { SET_SAVED_PAYMENT_METHOD } from "./mutations/setSavedPaymentMethod";
import { useFocusEffect, useIsFocused } from "@react-navigation/native";
import stylesIpad from "../styles/stylesIpad";

const Checkout = ({navigation,route}) =>{
    const isFocused=useIsFocused();
    const dispatch=useDispatch();
    const heightPad = useWindowDimensions().height;
    const widthPad = useWindowDimensions().width;
    const [showCalendar, setShowCalendar]=useState(false);
    const [isCalendarVisible, setIsCalendarVisible]=useState('none');
    const ITEMS=useSelector(state=>state);
    const CUSTOMER=useSelector(state=>state.customer);
    const SHIPPING=useSelector(state=>state.address);
    const CART_ID=useSelector(state=>state.cartId);
    const PARENT_ORDER_ID=useSelector(state=>state.parentOrderId);
    const PARENT_ORDER_DATE=useSelector(state=>state.parentOrderDate);
    const GET_SHIPPING_METHOD=useSelector(state=>state.shippingMethods);
    const [discountCode,setDiscountCode]=useState(null);
    const methods=[];
    const paymentMethods=[];
    const [country,setCountry]=useState(null);
    const [tooltipVisible, setTooltipVisible] = useState('none');
    const [creditCardInfo, setCreditCardInfo] = useState({display:'none',card:null});
    const [creditCardTooltip, setCreditCardTooltip] = useState('none');
    const [date,setDate]=useState(null);
    const [display,setDisplay]=useState('flex');
    const [selectedCard,setSelectedCard]=useState();
    const [clicked,setClicked]=useState(0);
    const [setShippingAddress]=useMutation(SET_SHIPPING_ADDRESS);
    const [setBillingAddress]=useMutation(SET_BILLING_ADDRESS);
    const [placedOrderMessage,setPlacedOrderMessage]=useState('');
    const [rewardPoints,setRewardPoints]=useState(0);
    const [creditCardNumber, setCreditCardNumber] = useState(null);
    const [expiryDate, setExpiryDate] = useState(null);
    const [verificationNumber, setVerificationNumber] = useState(null);
    const [errorMessage,setErrorMessage] = useState('');
    const [childOrderId,setChildOrderId]=useState(null);
    const [show,setShow]=useState('none');
    const [load,setLoad]=useState();
    const [loadShipping,setLoadShipping]=useState();
    const [selected,setSelected]=useState(null);
    const [nounce,setNounce]=useState(null);
    const [tokenBraintree,setTokenBraintree]=useState(null);
    const [selectedCardValue,setSelectedCardValue]=useState(0);
    const [selectedShippingValue,setSelectedShippingValue]=useState(0);
    const [carrier_code,setCarrierCode]=useState('');
    const [method_code,setMethodCode]=useState('');
    const [carrier_codeTitle,setCarrierCodeTitle]=useState('');
    const [method_codeTitle,setMethodCodeTitle]=useState('');
    const [serverError,setServerErrorMsg] = useState('');
    const [calendarMessage, setCalendarMessage]=useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const scrollViewRef = useRef(null);
    const storedCards=[];
    const shipping=[];
    const ShippingMethod = [
        {label:'Shipping Methods'}
    ];
    const validate=()=>{
        if(creditCardNumber!=0){
            setErrorMessage('');
        }else{
            setErrorMessage('Please enter valid credit card number.');
        }
    }

    const changeCreditCardInfo = () =>{
        if(creditCardInfo.display=='none'){

            setCreditCardInfo({display:'flex',card:selected?.code});
            setLoad(false)
        }
        else{
            setCreditCardInfo({display:'none',card:selected?.code});
            setLoad(false)
        }
        }
    
    const [addresses,setAddress]=useState([]);
    

    const changeCreditCardTooltip = () =>{
        if(creditCardTooltip=='none'){
            setCreditCardTooltip('flex');
        }else{
            setCreditCardTooltip('none');
        }
    }

    const changeTooltipVisible = () =>{
        if(tooltipVisible=='none'){
         setTooltipVisible('flex');
        }else{
         setTooltipVisible('none');
        }
    }
    
   const [setShippingMethod]=useMutation(SET_DELIVERY_METHOD);
const selectShippingMethod=async(cartId,carrier_code,method_code)=>{
    
    try{
        const{
            data,errors,
          }= await setShippingMethod({
              variables:{
                  cartId,
                  carrier_code,
                method_code,
              }
          });
          if(data!=undefined){
            console.log(data);
            setSelectedShippingValue(1);
        }
        // dispatch(setShippingMethods(methods));
    }
    catch (error){
        console.log(error);
        setSelectedCardValue(0);
        setSelectedShippingValue(0);
        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            }
        }
}
const [applyDiscount]=useMutation(APPLY_COUPAN_CODE);
const applyDiscountCode=async(cartId,coupan_code)=>{
    try{
        const{
            data,errors,
          }= await applyDiscount({
              variables:{
                  cartId,
                  coupan_code
              }
          });
    }
    catch (error){
        console.log(error);
        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            }
        }
}

const [getBrainTreeToken]=useMutation(BRAINTREE_TOKEN);
const getToken= async(selected)=>{

    setLoad(true)
    changeCreditCardInfo()
    setSelected(selected);
    try{
        const{
            data,errors,
          }= await getBrainTreeToken();
            setBrainTree(data?.createBraintreeClientToken);
    }
    catch (error){
        console.log('Error This1::::::::::::1',error);
        setSelectedCardValue(0);
        setSelectedShippingValue(0);
        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            }
        }
}
const setBrainTree= (token)=>{
    setTokenBraintree(token); 
 }
const setCardDetails=(creditCardNumber,expiryDate,verificationNumber)=>{
    setCreditCardNumber(creditCardNumber);
    setExpiryDate(expiryDate);
    setVerificationNumber(verificationNumber);
}


const getBraintreeTokenNounce=(cartId,code,creditCardNumber,expiryDate,verificationNumber)=>{
    
   console.log(':::::::::::::::::',code);
   if(code=='braintree'){
   if(tokenBraintree!=null){
    RNBraintree.tokenizeCard({
        clientToken: tokenBraintree,
        number: creditCardNumber,
        expirationMonth: expiryDate.split('/')[0],
        expirationYear: expiryDate.split('/')[1],
        cvv: verificationNumber,
        })
        .then(result => setPayment(cartId,code,result.nonce))
        .catch((error) => {        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            };setSelectedCardValue(0);
            setSelectedShippingValue(0);});
    
   }
}
}
const [setPaymentMethod]=useMutation(SET_PAYMENT_METHOD);
const [setPaymentMethodOnCart]=useMutation(SET_SAVED_PAYMENT_METHOD);
const setPayment= async (cartId,code,nounce)=>{
    if(code=='braintree'){
   setLoad(true)
    try{
        const{
            data,errors,
          }= await setPaymentMethod({
              variables:{
                  cartId,
                  code,
                  nounce
              }
          });
          if(data!=undefined){
            console.log('Payment Set::::::::::::::::::::::::',data);
            setSelectedCardValue(1);
      setLoad(false)      
      }
    }
    catch (error){
        setSelectedCardValue(0);
        setSelectedShippingValue(0);
        console.log('Error This2::::::::::::',error);
        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            }
        }
    }else if(code=='braintree_cc_vault'){
        console.log(':::::::::::::::: public_hash',nounce);
        setLoad(true)
        try{
            
           
            const{
                data,errors,
              }= await setPaymentMethodOnCart({
                  variables:{
                      cartId,
                      code,
                      nounce
                  }
              });
              if(data!=undefined){
              console.log('Payment Set::::::::::::::::::::::::',data);
            //   setSelectedCardValue(1);
        setLoad(false)      
        }
        }
        catch (error){
            setSelectedCardValue(0);
            setSelectedShippingValue(0);
            console.log('Error This2::::::::::::',error);
            if(error.message!=undefined){
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error.message);
                }else{
                    setDisplayServerErrorMsg(true);
                    setServerErrorMsg(error);    
                }
            }
    }

}


const [useRewardPoints]=useMutation(REWARD_POINTS);
const applyRewardPoints=async(cartId,points)=>{
    try{
        const{
            data,errors,
          }= await useRewardPoints({
              variables:{
                  cartId,
                  points
              }
          });
        
    }catch(error){

        console.log('::::::::',error);
        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            }
        }
}
// function OrderFailed () {
//     return(
//       <>
//       {load==true?<ActivityIndicator animating={load}></ActivityIndicator>:
//       <View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
//         <Text style={[styles.serverError,{fontSize:height*0.016}]}>
//             {serverError}
//         </Text>
//       </View>}
    
//       </>
//     )
//   }
  if (displayServerError) {
    setTimeout(() => {
      setDisplayServerErrorMsg(false);
      setServerErrorMsg('');
    }, 15000);
  }

const [placeOrder]=useMutation(PLACE_ORDER);
const placeTheOrder=async(cartId,delivery_date)=>{
    
  
    setLoad(true)
    getBraintreeTokenNounce(cartId,selected.code,creditCardNumber,expiryDate,verificationNumber);
        
        setTimeout(async function() {
            try{
        //         console.log(cartId);
        // console.log(selected.code);
        // console.log(creditCardNumber);
        // console.log(expiryDate);
        // console.log(verificationNumber)
        // console.log(delivery_date);
                const{
                    data,errors,
                  }= await placeOrder({
                      variables:{
                          cartId,
                          delivery_date
                      }
                  });
              
                
                  if(PARENT_ORDER_ID!=null){
                    
                    setLoad(false);
                    orderAdditions(PARENT_ORDER_ID,data?.placeOrder?.order?.order_number[0]);
                    navigation.navigate('OrderSuccess',{orderNumber1:data?.placeOrder?.order?.order_number[0]})
                  }else{
                   
                    if(data?.placeOrder?.order?.order_number.length==1){
                        setDate(null);
                        setSelectedCardValue(0);
                        setSelectedShippingValue(0);
                        setCreditCardInfo('none');
                        setCalendarMessage('');
                        setLoad(false);
                        setDisplayServerErrorMsg(true);
                        navigation.navigate('OrderSuccess',{orderNumber1:data?.placeOrder?.order?.order_number[0],orderNumber2:''});
                    }else{
                        setDate(null);
                        setSelectedCardValue(0);
                        setSelectedShippingValue(0);
                        setCreditCardInfo('none');
                        setCalendarMessage('');
                        setLoad(false);
                        setDisplayServerErrorMsg(true);
                        navigation.navigate('OrderSuccess',{orderNumber1:data?.placeOrder?.order?.order_number[0],orderNumber2:data?.placeOrder?.order?.order_number[1]});
                    }
                  }
               
        
            }catch(error){
                if(error.message!=undefined){
                    setDisplayServerErrorMsg(true);
                    setServerErrorMsg(error.message);
                    }else{
                        setDisplayServerErrorMsg(true);
                        setServerErrorMsg(error);    
                    }
                            setSelectedCardValue(0);
                        setSelectedShippingValue(0);
                    console.log('Error This1::::::::::::2',error);
                    setShow('flex');
                    setCreditCardInfo('flex');
                setLoad(false);  
            }
        }, 8000);
   


}

const saveShippingAddress= async(cartId,firstName,lastName,company,street,city,region,region_id,postcode,country_code,telephone)=>{

    try{
        const{
            data,errors,
          }= await setShippingAddress({
              variables:{
                  cartId,
                  firstName,
                  lastName,
                  company,
                  street,
                  city,
                  region,
                  region_id,
                  postcode,
                  country_code,
                  telephone
              }
          });
            console.log('Payment Methods:::::::::',data?.setShippingAddressesOnCart?.cart?.shipping_addresses[0]?.available_shipping_methods[0]?.carrier_title)
            setCarrierCodeTitle(data?.setShippingAddressesOnCart?.cart?.shipping_addresses[0]?.available_shipping_methods[0]?.carrier_title);
            setMethodCodeTitle(data?.setShippingAddressesOnCart?.cart?.shipping_addresses[0]?.available_shipping_methods[0]?.method_title)
            setCarrierCode(data?.setShippingAddressesOnCart?.cart?.shipping_addresses[0]?.available_shipping_methods[0]?.carrier_code);
            setMethodCode(data?.setShippingAddressesOnCart?.cart?.shipping_addresses[0]?.available_shipping_methods[0]?.method_code)
     
         
    }catch(error){
        console.log(error);
        if(error.message!=undefined){
        setDisplayServerErrorMsg(true);
        setServerErrorMsg(error.message);
        }else{
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error);    
        }
    }
}

function handleBackButtonClick() {
    navigation.navigate('DrawerNavigation',{screen:"CartPage"});
    return true;
  }

// useEffect(()=>{
//     // console.log(CUSTOMER?.customer?.addresses[0]?.company);
//     saveShippingAddress(CART_ID,CUSTOMER?.customer?.addresses[0]?.firstname,CUSTOMER?.customer?.addresses[0]?.lastname,CUSTOMER?.customer?.addresses[0]?.company!=null?CUSTOMER?.customer?.addresses[0]?.company:'',CUSTOMER?.customer?.addresses[0]?.street,CUSTOMER?.customer?.addresses[0]?.city,"AS",0,CUSTOMER?.customer?.addresses[0]?.postcode,CUSTOMER?.customer?.addresses[0]?.country_code,CUSTOMER?.customer?.addresses[0]?.telephone)
//     saveBillingAddress(CART_ID,CUSTOMER?.customer?.addresses[0]?.firstname,CUSTOMER?.customer?.addresses[0]?.lastname,CUSTOMER?.customer?.addresses[0]?.company!=null?CUSTOMER?.customer?.addresses[0]?.company:'',CUSTOMER?.customer?.addresses[0]?.street,CUSTOMER?.customer?.addresses[0]?.city,"AS",0,CUSTOMER?.customer?.addresses[0]?.postcode,CUSTOMER?.customer?.addresses[0]?.country_code,CUSTOMER?.customer?.addresses[0]?.telephone)
// },[CART_ID]);


useFocusEffect(
    React.useCallback(() => {

        saveShippingAddress(CART_ID,CUSTOMER?.customer?.addresses[0]?.firstname,CUSTOMER?.customer?.addresses[0]?.lastname,CUSTOMER?.customer?.addresses[0]?.company!=null?CUSTOMER?.customer?.addresses[0]?.company:'',CUSTOMER?.customer?.addresses[0]?.street,CUSTOMER?.customer?.addresses[0]?.city,"AS",0,CUSTOMER?.customer?.addresses[0]?.postcode,CUSTOMER?.customer?.addresses[0]?.country_code,CUSTOMER?.customer?.addresses[0]?.telephone)
        saveBillingAddress(CART_ID,CUSTOMER?.customer?.addresses[0]?.firstname,CUSTOMER?.customer?.addresses[0]?.lastname,CUSTOMER?.customer?.addresses[0]?.company!=null?CUSTOMER?.customer?.addresses[0]?.company:'',CUSTOMER?.customer?.addresses[0]?.street,CUSTOMER?.customer?.addresses[0]?.city,"AS",0,CUSTOMER?.customer?.addresses[0]?.postcode,CUSTOMER?.customer?.addresses[0]?.country_code,CUSTOMER?.customer?.addresses[0]?.telephone)
    }, [CART_ID])
);

function getBack(){
BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
return () => {
  BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
};   
}
getBack();
function getShippingMethod(){
    const SHIPPING_METHOD=gql`
    {
      getAvailableShippingMethods(cartId: "${CART_ID}") {
        available_shipping_methods
      }
    }
    `;
    const { loading, error, data } = useQuery(SHIPPING_METHOD);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if(data!=undefined){
        console.log(data);
        methods.push(JSON.parse(data?.getAvailableShippingMethods?.available_shipping_methods)[0]);
        ShippingMethod.push(JSON.parse(data?.getAvailableShippingMethods?.available_shipping_methods)[0]);
        ShippingMethod.push({
            carrier_code: JSON.parse(data?.getAvailableShippingMethods?.available_shipping_methods)[0]?.carrier_code,
            method_code:JSON.parse(data?.getAvailableShippingMethods?.available_shipping_methods)[0]?.method_code
            });
    }
   
    
}
// console.log(CUSTOMER.customer.addresses)
// console.log(CART_ID);
function getPaymentMethod(){
    
    const PAYMENT_METHOD=gql` 
{
    cart(cart_id: "${CART_ID}") {
     available_payment_methods{
       code
       title
     }
    }
  }
  
    `;
    const { loading, error, data } = useQuery(PAYMENT_METHOD);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    // console.log(data);
    paymentMethods.push(data?.cart?.available_payment_methods);
    
}
function getStoredCards(){
    
    const PAYMENT_METHOD=gql` 
{
        customerPaymentTokens {
          items {
            details
            public_hash
            payment_method_code
            type
          }
        }
  }
  
    `;
    const { loading, error, data } = useQuery(PAYMENT_METHOD);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    // console.log('::::::::::::',data.customerPaymentTokens.items);
    storedCards.push(data?.customerPaymentTokens?.items);
}
getPaymentMethod();
getStoredCards();
// getShippingMethod();

const [OrderAdditionData]=useMutation(ORDER_ADDITIONS);
const orderAdditions= async(parent_order_id,new_child_order_id)=>{
    try{
        const{
            data,errors,
          }= await OrderAdditionData({
              variables:{
                parent_order_id,
                new_child_order_id
              }
          });

          console.log('Order Additions::::::::::::::::;',data);
       
    }catch(error){
        console.log(error);
        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            }
        }
}
   

   
    const paymentMethod = [
        
        ];
        const storeCards = [
        
        ];


const GetClick=(item,display)=>{
    if(item){
        setDisplay('none');
        setClicked(item);
   
    }else{
        setDisplay('flex');
        setClicked(item);
    }
    

}


const GetSavedAddress=()=>{
   
    setAddress(CUSTOMER?.customer?.addresses)
    const completeAddress=[...addresses,SHIPPING];
              const COUNTRY= gql`
             {
                 country(id: "${CUSTOMER?.customer?.addresses[0]?.country_code}") {
                 full_name_english
                 full_name_locale
                 id
                 three_letter_abbreviation
                 two_letter_abbreviation
               }
             }
               `;
               const { loading, error, data } = useQuery(COUNTRY);
               if (loading) return <ActivityIndicator></ActivityIndicator>;
               if(Platform.isPad){
                return(
                    <View style={{marginTop:'5%'}}>
                        <Text style={[stylesIpad.shippingAddress,{fontSize:heightPad*0.018}]}>{CUSTOMER?.customer?.addresses[0]?.firstname} {CUSTOMER?.customer?.addresses[0]?.lastname}</Text>
                        <Text style={[stylesIpad.shippingAddress,{fontSize:heightPad*0.018}]}>{CUSTOMER?.customer?.addresses[0]?.street}</Text>
                        <Text style={[stylesIpad.shippingAddress,{fontSize:heightPad*0.018}]}>{CUSTOMER?.customer?.addresses[0]?.city},{CUSTOMER?.customer?.addresses[0]?.region?.region} {CUSTOMER?.customer?.addresses[0]?.postcode}</Text>
                        <Text style={[stylesIpad.shippingAddress,{fontSize:heightPad*0.018}]}>{data?.country?.full_name_english}</Text>
                        <Text style={[stylesIpad.shippingAddress,{fontSize:heightPad*0.018}]}>{CUSTOMER?.customer?.addresses[0]?.telephone}</Text>
                    </View>      
                )
               }else{
    return(
    //     <>
    // {SHIPPING.length!=0? <>
    //     {completeAddress.map((address,item)=>{
            
                
             
    //          const COUNTRY= gql`
    //          {
    //              country(id: "${address.country_code==undefined? address.country.code:address.country_code}") {
    //              full_name_english
    //              full_name_locale
    //              id
    //              three_letter_abbreviation
    //              two_letter_abbreviation
    //            }
    //          }
    //            `;
    //            const { loading, error, data } = useQuery(COUNTRY);
    //            if (loading) return <ActivityIndicator></ActivityIndicator>;
              

    //         return(
                // <View>
                //     <Text style={styles.shippingAddress}>{address.firstname} {address.lastname}</Text>
                //     <Text style={styles.shippingAddress}>{address.street}</Text>
                //     <Text style={styles.shippingAddress}>{address.city},{address.region.region} {address.postcode}</Text>
                //     <Text style={styles.shippingAddress}>{data.country.full_name_english}</Text>
                //     <Text style={styles.shippingAddress}>{address.telephone}</Text>
             
                //     {SHIPPING.length!=0?<TouchableOpacity onPress={()=>{GetClick(item,display); if(address.region.region_code==undefined){saveShippingAddress(CART_ID,address.firstname,address.lastname,address.company,address.street,address.city,address.region.code,address.region.region_id,address.postcode,data.country.id,address.telephone)}else{saveShippingAddress(CART_ID,address.firstname,address.lastname,address.company,address.street,address.city,address.region.region_code,address.region.region_id,address.postcode,data.country.id,address.telephone)}}} style={[styles.newAddress,{display:item==clicked && SHIPPING.length!=0?'none':'flex'}]}>
                //                 <Text style={styles.summaryButtonText}>Ship here</Text>
                //             </TouchableOpacity>:<TouchableOpacity onPress={()=>{GetClick(item,display); if(address.region.region_code==undefined){saveShippingAddress(CART_ID,address.firstname,address.lastname,address.company,address.street,address.city,address.region.code,address.region.region_id,address.postcode,data.country.id,address.telephone)}else{saveShippingAddress(CART_ID,address.firstname,address.lastname,address.company,address.street,address.city,address.region.region_code,address.region.region_id,address.postcode,data.country.id,address.telephone)}}} style={[styles.newAddress,{display:item==clicked && SHIPPING.length!=0?'none':'flex'}]}>
                //                 <Text style={styles.summaryButtonText}>Ship here</Text>
                //             </TouchableOpacity>} 
                //     </View>
    //                 )})}
    //                 <TouchableOpacity onPress={()=>{navigation.navigate('NewAddress')}} style={styles.newAddress}>
    //                     <Text style={styles.summaryButtonText}>{SHIPPING.length==0? 'New Address':'Edit'}</Text>
    //                 </TouchableOpacity>
    //                 </>:<>
    // {addresses.map((address,item)=>{
    //       const COUNTRY= gql`
    //       {
    //           country(id: "${address.country_code==undefined? address.country.code:address.country_code}") {
    //           full_name_english
    //           full_name_locale
    //           id
    //           three_letter_abbreviation
    //           two_letter_abbreviation
    //         }
    //       }
    //         `;
    //         const { loading, error, data } = useQuery(COUNTRY);
    //         if (loading) return <ActivityIndicator></ActivityIndicator>;
    //     return(
    //         <View style={{marginBottom:height*0.012}}>
                // <Text style={styles.shippingAddress}>{address.firstname} {address.lastname}</Text>
                // <Text style={styles.shippingAddress}>{address.street}</Text>
                // <Text style={styles.shippingAddress}>{address.city},{address.region.region} {address.postcode}</Text>
                // <Text style={styles.shippingAddress}>{data.country.full_name_english}</Text>
                // <Text style={styles.shippingAddress}>{address.telephone}</Text>
            

    //             <TouchableOpacity onPress={()=>{GetClick(item,display),saveShippingAddress(CART_ID,address.firstname,address.lastname,address.company,address.street,address.city,address.region.region_code,address.region.region_id,address.postcode,address.country_code,address.telephone)}} style={[styles.newAddress,{display:item==clicked?'none':'flex'}]}>
    //                 <Text style={styles.summaryButtonText}>Ship here</Text>
    //             </TouchableOpacity>
                   
    //             </View>
    //                 )})}
    //                 <TouchableOpacity onPress={()=>{navigation.navigate('NewAddress')}} style={styles.newAddress}>
    //                     <Text style={styles.summaryButtonText}>{SHIPPING.length==0? 'New Address':'Edit'}</Text>
    //                 </TouchableOpacity>
    //             </>
    //             }
   
    // </>
    <View>
    <Text style={styles.shippingAddress}>{CUSTOMER?.customer?.addresses[0]?.firstname} {CUSTOMER?.customer?.addresses[0]?.lastname}</Text>
    <Text style={styles.shippingAddress}>{CUSTOMER?.customer?.addresses[0]?.street}</Text>
    <Text style={styles.shippingAddress}>{CUSTOMER?.customer?.addresses[0]?.city},{CUSTOMER?.customer?.addresses[0]?.region?.region} {CUSTOMER?.customer?.addresses[0]?.postcode}</Text>
    <Text style={styles.shippingAddress}>{data?.country?.full_name_english}</Text>
    <Text style={styles.shippingAddress}>{CUSTOMER?.customer?.addresses[0]?.telephone}</Text>

    </View>      
    )
    }          
               
                   
}

const saveBillingAddress=async(cartId,firstName,lastName,company,street,city,region,region_id,postcode,country_code,telephone)=>{
    try{
        const{
            data,errors,
          }= await setBillingAddress({
              variables:{
                cartId,
                firstName,
                lastName,
                company,
                street,
                city,
                region,
                region_id,
                postcode,
                country_code,
                telephone
              }
          });        
        //   console.log('Billing Addresss:::::::::::::',data.setBillingAddressOnCart);    
    }catch(error){
        console.log(error);
        if(error.message!=undefined){
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);
            }else{
                setDisplayServerErrorMsg(true);
                setServerErrorMsg(error);    
            }
        }
}

var mondays=[];
const [months,setMonths]=useState(0);
var hello = {
};

function getMondays(mondays,months) {
   

    setMonths(365);
    var mondays = [];
    var weekDays=JSON.parse(CUSTOMER?.customer?.shipment_days);
    
    weekDays?.map((days)=>{
        
        if(days=="Monday"){
            var d = new Date();
            // console.log(days);
            d.setDate(1);
           
            // Get the first Monday in the month
            while (d.getDay() !== 1) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+1);
                
            }
            for(let i=0;i<=months;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }else if(days=="Tuesday"){
            var d = new Date();
            // console.log(days);
            d.setDate(2);
         
            // Get the first Monday in the month
            while (d.getDay() !== 2) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+2);
                
            }
            for(let i=0;i<=months;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Wednesday"){
            var d = new Date();
            d.setDate(3);
          
            // Get the first Monday in the month
            while (d.getDay() !== 3) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+3);
                
            }
            for(let i=0;i<=months;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Thursday"){
            var d = new Date();
            d.setDate(4);
           
            // Get the first Monday in the month
            while (d.getDay() !== 4) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+4);
                
            }
            for(let i=0;i<=months;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Friday"){
            var d = new Date();
            d.setDate(5);
         
            // Get the first Monday in the month
            while (d.getDay() !== 5) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+5);
                
            }
            for(let i=0;i<=months;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Saturday"){
            var d = new Date();
            d.setDate(6);
           
            // Get the first Monday in the month
            while (d.getDay() !== 6) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+6);
                
            }
            for(let i=0;i<=months;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Sunday"){
            var d = new Date();
            d.setDate(0);
           
            // Get the first Monday in the month
            while (d.getDay() !== 0) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+1);
                
            }
            for(let i=0;i<=months;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
    });

        mondays.map((date)=>{
        hello[date?.date]={disabled: false};
        hello[currentDate]={disabled:true};
        if(date?.date<currentDate){
            hello[date?.date]={disabled: true};
        }
    })
    // return mondays;
  
    return hello
   
}

// useEffect(()=>{
//     getMondays(mondays,months);
// },[]);


const enableTuesday=()=>{
    var weekDays=JSON.parse(CUSTOMER?.customer?.shipment_days);
    
    weekDays?.map((days)=>{
        
        if(days=="Monday"){
            var d = new Date();
            // console.log(days);
            d.setDate(1);
           
            // Get the first Monday in the month
            while (d.getDay() !== 1) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+1);
                
            }
            for(let i=0;i<=10;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }else if(days=="Tuesday"){
            var d = new Date();
            // console.log(days);
            d.setDate(2);
         
            // Get the first Monday in the month
            while (d.getDay() !== 2) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+2);
                
            }
            for(let i=0;i<=10;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Wednesday"){
            var d = new Date();
            d.setDate(3);
          
            // Get the first Monday in the month
            while (d.getDay() !== 3) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+3);
                
            }
            for(let i=0;i<=10;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Thursday"){
            var d = new Date();
            d.setDate(4);
           
            // Get the first Monday in the month
            while (d.getDay() !== 4) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+4);
                
            }
            for(let i=0;i<=10;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Friday"){
            var d = new Date();
            d.setDate(5);
         
            // Get the first Monday in the month
            while (d.getDay() !== 5) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+5);
                
            }
            for(let i=0;i<=10;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Saturday"){
            var d = new Date();
            d.setDate(6);
           
            // Get the first Monday in the month
            while (d.getDay() !== 6) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+6);
                
            }
            for(let i=0;i<=10;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
        else if(days=="Sunday"){
            var d = new Date();
            d.setDate(0);
           
            // Get the first Monday in the month
            while (d.getDay() !== 0) {
                
                    // console.log("My Date",d.getDay());
                    d.setDate(d.getDate()+1);
                
            }
            for(let i=0;i<=10;i++){
                mondays.push({date:moment(new Date(d.getTime())).format('YYYY-MM-DD')});
                d.setDate(d.getDate() + 7);
            }
        }
    });
    
    mondays.map((date)=>{
        hello[date?.date]={disabled: false};
        hello[currentDate]={disabled:true};
        if(date?.date<currentDate){
            hello[date?.date]={disabled: true};
        }
    })
  
    return hello;
}

let calendarDate = moment();

const [currentDate,setCurrentDate]=useState(calendarDate.format('YYYY-MM-DD'));

  const getMonth = (counter) => {
        setMonths(365);
        // setCurrentDate(calendarDate.format('YYYY-MM-DD'));     
        enableTuesday(hello,getMondays(mondays,months)); 
       
  };
  const changeCalendarVisible = () =>{
    if(isCalendarVisible=='none'){
     setIsCalendarVisible('flex');
   
    }else{
     setIsCalendarVisible('none');
    }
}
// console.log(':::::::::::::::',methods);

const GET_REWARD_POINTS=gql`
{
  rewards {
    balance
  }
}
`;
const { loading, error, data } = useQuery(GET_REWARD_POINTS);
if (loading) return <ActivityIndicator></ActivityIndicator>;
if (error) return <Text style={{color:'#000'}}>Error :(</Text>;


if(Platform.isPad){
return (
    <View style={{flexDirection:'row',height:'100%'}}>
            <View style={{width:'25%',paddingHorizontal:'0.5%',paddingTop:'1%'}}>
            <View style={[stylesIpad.titleBox,{height:'5%',padding:'2%',justifyContent:'center'}]}>
                    <Text style={[stylesIpad.titleBoxText,{fontSize:heightPad*0.015}]}>
                        Shipping Address
                    </Text>
            </View>
            <GetSavedAddress></GetSavedAddress>
            </View>
            <View style={{width:'40%',paddingHorizontal:'0.5%',paddingTop:'1%'}}>
            <View style={[stylesIpad.titleBox,{height:'5%',padding:'2%',flexDirection:'row',alignItems:'center'}]}>
                    <Text style={[stylesIpad.titleBoxText,{fontSize:heightPad*0.015}]}>
                        Choose Dates Below
                    </Text>
                    <Text style={[stylesIpad.titleBoxText,{fontSize:heightPad*0.015,color:'red',marginLeft:'3%'}]}>
                        *
                    </Text>
            </View>
            <View style={{width:'100%',justifyContent:'center',zIndex:1}}>
                <TouchableOpacity style={{marginTop:'5%'}} onPress={()=>{changeCalendarVisible();getMonth()}}>
                    <View style={[stylesIpad.chooseDateClickable,{width:'100%',flexDirection:'row',marginTop:0}]}>
                            <View style={[stylesIpad.availableChoices,{width:'85%',height:'20%'}]}>
                                <Text style={stylesIpad.availableChoicesText}>{moment(date).format('DD/MM/YYYY')!='Invalid date'? moment(date).format('DD/MM/YYYY'):''}</Text>
                            </View>
                            <View style={[stylesIpad.calenderIconContainer,{marginLeft:'5%',marginTop:0}]}>
                        <Image source={require('../assets/icons/calendar.png')} style={[stylesIpad.calenderIcon,{width:width*0.035,
        height:height*0.035,}]}/>
                    </View>
                    </View>

                </TouchableOpacity>
                
            <View style={[stylesIpad.calenderView,{display:isCalendarVisible,width:'100%',}]}>    
                <Calendar firstDay={1} theme={{
                    selectedDayBackgroundColor: '#00adf5',
                }} onDayPress={(day) => {
                setDate(moment(day.dateString).format("MM/DD/YYYY"));setIsCalendarVisible('none');
                // console.log(day);
                }} disableAllTouchEventsForDisabledDays={true}  onMonthChange={()=>{getMonth()}} disabledByDefault={true} hideExtraDays={true} markedDates={enableTuesday()}   style={{borderRadius:height*0.010}}
                />  
                {/* onMonthChange={(month)=>{getMonth(month)}} */}

                {/* <CalendarPicker disable={['2']} style={{borderRadius:height*0.010}}></CalendarPicker> */}

                </View>
                </View>
               
                    <View style={[stylesIpad.titleBox,{height:'5%',padding:'2%',flexDirection:'row',alignItems:'center',marginTop:'10%'}]}>
                            <Text style={[stylesIpad.titleBoxText,{fontSize:heightPad*0.015}]}>
                                Shipping Method
                            </Text>
                    </View>
          <View style={[stylesIpad.shippingMethod,{padding:'4%'}]}>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                    <View style={stylesIpad.radioContainer}>
                        <View style={[stylesIpad.radioOuter,{paddingBottom:'2%'}]}>
                            <RadioButtonRN
                            initial={selectedShippingValue}
                                data={ShippingMethod}
                                // selectedBtn={()=>{carrier_code!=null && method_code!=null? selectShippingMethod(CART_ID,carrier_code,method_code):console.log('Select Shipping Method')}}
                                selectedBtn={()=>{setLoadShipping(true);selectShippingMethod(CART_ID,carrier_code,method_code)}}
                                circleSize={9}
                                boxStyle={{backgroundColor:'#f9f9f9',borderWidth:0}}
                                activeColor={'#000'}
                                deactiveColor={'#000'}   
                            />
                        </View>
                        <Text style={[stylesIpad.shippingMethodPrice,{fontWeight:'500',marginLeft:'1%',fontSize:heightPad*0.015}]}>£{route?.params?.cart_shipping}</Text>
                        <Text style={[stylesIpad.shippingMethodPrice,{fontWeight:'500',marginLeft:'7%',fontSize:heightPad*0.015}]}>{carrier_codeTitle}</Text>
                        <Text style={[stylesIpad.shippingMethodPrice,{fontWeight:'500',marginLeft:'7%',fontSize:heightPad*0.015}]}>-</Text>
                        <Text style={[stylesIpad.shippingMethodPrice,{fontWeight:'500',marginLeft:'7%',fontSize:heightPad*0.015}]}>{method_codeTitle}</Text>
                   
                       
                </View>
            </View>
         
            
        </View>
        {paymentMethods?.map((methods)=>{
                methods?.map((method)=>{
                    paymentMethod.push( {
                        label: method.title,
                        code:  method.code
                    });
                })            
            }
            )
            
            }
        {storedCards?.map((methods)=>{
                methods?.map((method,index)=>{
                    // console.log(method);
                    storeCards.push({
                        label: 'ending '+JSON.parse(method.details).maskedCC+' ( expires:'+ JSON.parse(method.details).expirationDate+')',
                        code: method?.payment_method_code,
                        index:index,
                        public_hash:method.public_hash
                    });
                })            
            }
            )
            
            }
        <Text style={[stylesIpad.serverError,{fontSize:height*0.016,marginLeft:width*0.050}]}>{calendarMessage}</Text>
               
                <View  style={[stylesIpad.titleBox,{height:'5%',padding:'2%',flexDirection:'row',alignItems:'center',marginTop:'10%'}]}>
                    <Text style={[stylesIpad.titleBoxText,{fontSize:heightPad*0.015}]}>
                        Payment Method
                    </Text>
                    </View>
            
                {load?<ActivityIndicator animating={load}></ActivityIndicator>:<View style={{paddingHorizontal:'2%'}}>
         <RadioButtonRN
         initial={selectedCardValue}
         data={paymentMethod}
        //  selectedBtn={(selected)=>{getToken(CART_ID,selected?.code);}}
         selectedBtn={(selected)=>{getToken(selected);}}
         circleSize={10}
         boxStyle={{backgroundColor:'#f9f9f9',borderWidth:0,borderRadius:0}}
         activeColor={'#000'}
         deactiveColor={'#000'}
         textStyle={{fontSize:heightPad*0.015}}             
         > 
            
         </RadioButtonRN>
         <View style={{padding:'2%',backgroundColor:'#f9f9f9',marginTop:'10%',display:selected?.code=='braintree'? 'flex':'none'}}>
                <View style={{}}>
                <CreditCardInput onChange={(form)=>{setCardDetails(form.values.number,form.values.expiry,form.values.cvc);}} allowScroll={true} labelStyle={{color:'#000',marginBottom:'5%'}} inputStyle={{backgroundColor:'#ffffff',padding:'1%'}}>
                </CreditCardInput>
                {/* <TouchableOpacity onPress={()=>{setCreditCardInfo(false)}} style={[styles.summaryButton,{width:'80%',padding:height*0.020,marginTop:height*0.020,marginLeft:width*0.10}]}>
                    <Text  style={styles.summaryButtonText}>Save</Text>
                </TouchableOpacity> */}
                </View>
                <Text style={[stylesIpad.serverError,{fontSize:height*0.016}]}>{errorMessage}</Text>
            </View>
        
            <ScrollView>
            <View style={{marginVertical:'5%',paddingHorizontal:'2%',display:selected?.code=='braintree_cc_vault'? 'flex':'none'}}>
                
                {storeCards?.map((item,index)=>{
                    // console.log('::::::::::::::::::',item.index)
                    return(
                        <View style={{backgroundColor:'#f9f9f9',borderWidth:0,padding:'3%',marginTop:'2%'}}>
                        <RadioButton currentValue={item.index} value={selectedCard} onPress={()=>{setSelectedCard(item.index); setPayment(CART_ID,selected.code,item.public_hash)}} innerCircleColor='#000' outerCircleColor='#000' outerCircleSize={18} outerCircleWidth={1} innerCircleSize={10}>
                            <View style={{paddingHorizontal:'2%',flexDirection:'row'}}>
                                <Image source={require('../assets/images/vi.png')} style={{resizeMode:'contain',height:'100%'}}/> 
                                <Text style={{color:'#000',fontSize:heightPad*0.013,paddingHorizontal:'2%'}}>
                                    {item.label}
                                </Text>   
                            </View>
                        </RadioButton>
                        </View>
                    )
                })}
               
            </View>
           
            <View style={[stylesIpad.orderSummary,{paddingLeft:0,
        paddingRight:0,
        paddingBottom:0}]}>
            <TouchableOpacity onPress={()=>{
                if(PARENT_ORDER_DATE!=null && PARENT_ORDER_ID !=null){
                    placeTheOrder(CART_ID,String(PARENT_ORDER_DATE));
                }else{
                    if(date!=null){
                        placeTheOrder(CART_ID,String(date));
                        setCalendarMessage('');
                    }else{
                        setCalendarMessage('This is a required field.')
                    }
                    
                }
        }} style={[stylesIpad.summaryButton,{width:'100%',padding:'5%',marginTop:'10%'}]}>
            {load? <ActivityIndicator animating={load}></ActivityIndicator>: <Text style={[stylesIpad.summaryButtonText,{fontSize:heightPad*0.018}]}>Place Order</Text>}
                
            </TouchableOpacity>
        </View>

            </ScrollView>
          
                </View>}
                
            </View>
            <View style={{width:'35%',paddingHorizontal:'0.5%',paddingTop:'1%'}}>
            <View style={[stylesIpad.titleBox,{height:'5%',padding:'2%',flexDirection:'row',alignItems:'center'}]}>
                            <Text style={[stylesIpad.titleBoxText,{fontSize:heightPad*0.015}]}>
                                Order Summary
                            </Text>
                    </View>
                    <View style={[stylesIpad.rewardPointsDesc,{marginTop:'2%',padding:'2%'}]}>
                <Text style={[stylesIpad.rewardPointsDescText,{fontSize:heightPad*0.012}]}>You can earn 200 Reward Points for completing your purchase!</Text>
                <Collapse>
                    <CollapseHeader>
                    <View style={[stylesIpad.estimateContainer,{paddingHorizontal:0,paddingTop:'5%',alignItems:'center'}]}>
                        <Text style={[stylesIpad.itemsInCartText,{fontSize:heightPad*0.012}]}>{ITEMS?.total_qty} Items in Cart</Text>
                        <Image source={require('../assets/icons/down-filled-arrow.png')} style={[stylesIpad.estimateDownIcon,{  width:width*0.015,
          height:height*0.004}]}/>
                    </View>
                    </CollapseHeader>
                    <CollapseBody>
                    <View style={[stylesIpad.cartItems,{paddingHorizontal:0}]}>
                    {ITEMS.items.map((item)=>{
                        var price_total=item?.product?.price_range?.maximum_price?.final_price?.value*item.quantity;
                         return( 
                            
                        <View style={{flexDirection:'row',marginTop:'6%',width:'30%'}}>
                                {/* <View>
                                    <Image style={{resizeMode:'contain'}} source={{uri:item?.product?.small_image?.url,height:heightPad*0.06,width:widthPad*0.06}}
                                    // style={{width:width*0.10,height:height*0.10,resizeMode:"contain"}}
                                    />
                                </View>
                                <View style={[stylesIpad.itemDetails,{paddingHorizontal:0,marginLeft:'1%',marginRight:'2%',marginTop:'1%'}]}>
                                    <Text style={[stylesIpad.itemDetailsText,{marginLeft:'3%',fontSize:heightPad*0.012}]}>{item?.product?.sku}</Text>
                                    <Text style={[stylesIpad.itemDetailsText,{marginLeft:'3%',fontSize:heightPad*0.012,width:widthPad*0.17}]}>{item?.product?.name}</Text>
                                    <Text style={[stylesIpad.itemDetailsText,{marginLeft:'3%',fontSize:heightPad*0.012}]}>Qty {item?.quantity}</Text>
                                </View>
                                <View>
                                    <Text style={[stylesIpad.itemPrice,{marginTop:'2%',fontSize:heightPad*0.015}]}>£ {parseFloat(price_total).toFixed(2)}</Text>
                                </View> */}
                            <Image style={{resizeMode:'contain'}} source={{uri:item?.product?.small_image?.url,height:heightPad*0.06,width:widthPad*0.06}}
                                                                />
                             <View style={[stylesIpad.itemDetails,{paddingHorizontal:0,marginLeft:'1%',marginRight:'2%',marginTop:'1%'}]}>
                                    <Text style={[stylesIpad.itemDetailsText,{marginLeft:'3%',fontSize:heightPad*0.012}]}>{item?.product?.sku}</Text>
                                    <View style={{flexDirection:'row'}}>
                                    <Text style={[stylesIpad.itemDetailsText,{marginLeft:'3%',fontSize:heightPad*0.012,width:widthPad*0.17}]}>{item?.product?.name}</Text>
                                    <Text style={[stylesIpad.itemPrice,{marginTop:'2%',fontSize:heightPad*0.012,marginLeft:'7%'}]}>£ {parseFloat(price_total).toFixed(2)}</Text>
                                    </View>
                                    <Text style={[stylesIpad.itemDetailsText,{marginLeft:'3%',fontSize:heightPad*0.012}]}>Qty {item?.quantity}</Text>
                                </View>

                            </View>
                            )
                        })}
                    </View>
                    </CollapseBody>
                </Collapse>
                <View style={[stylesIpad.priceDetails,{padding:0,marginTop:'2%'}]}>
                    <View style={[stylesIpad.subTotalPrice]}>
                        <Text style={[stylesIpad.shippingPrice,{fontSize:heightPad*0.012}]}>Cart Subtotal</Text>
                        <Text style={[stylesIpad.shippingPrice,{fontSize:heightPad*0.012}]}>£{route?.params?.cart_subtotal}</Text>
                    </View>

                    <View style={stylesIpad.shippingTotal}>
                        <Text style={[stylesIpad.shippingPrice,{fontSize:heightPad*0.012}]}>Shipping</Text>
                        <Text style={[styles.shippingPrice,{fontSize:heightPad*0.012}]}>£{route?.params?.cart_shipping}</Text>
                    </View>
                    <Text style={[styles.shippingPrice,{fontSize:heightPad*0.012}]}>Flat Rate - Fixed</Text>
                    <View style={styles.orderSubtotal}>
                        <Text style={[stylesIpad.shippingPrice,{fontWeight:'bold',marginTop:height*0.014,fontSize:heightPad*0.012}]}>Order Subtotal</Text>
                        <Text style={[styles.shippingPrice,{marginTop:height*0.014,fontSize:heightPad*0.012}]}>£{parseFloat(ITEMS?.total_price).toFixed(2)}</Text>
                    </View>
                </View>
            </View>

            <View style={[stylesIpad.applyDiscountBox,{padding:'2%'}]}>
                <Text style={[stylesIpad.applyDiscountText,{fontSize:heightPad*0.012}]}>Apply Discount Code</Text>
                <View style={[stylesIpad.applyDiscount,{padding:0}]}> 
                    <TextInput onChangeText={code=>setDiscountCode(code)} placeholder="Enter discount code" placeholderTextColor={'#000'} keyboardType={'numeric'} style={{color:'#000',fontSize:height*0.012}}/>
                    <TouchableOpacity onPress={()=>{applyDiscountCode(CART_ID,discountCode)}} style={[stylesIpad.summaryButton,{width:'50%'}]}>
                        <Text style={[styles.summaryButtonText,{fontSize:heightPad*0.012}]}>Apply Discount</Text>
                    </TouchableOpacity>
                </View>
            </View>

            <View style={[stylesIpad.applyDiscountBox,{padding:'2%'}]}>
                <Text style={[stylesIpad.applyDiscountText,{fontSize:heightPad*0.012}]}>Apply Rewards</Text>
                <View style={{marginTop:'5%'}}>
                    <Text style={{color:'#000',fontSize:heightPad*0.012}}>You Have {data.rewards.balance} points left</Text>
                    <Text style={{color:'#000',fontSize:heightPad*0.012}}>10 for every 1GBP</Text>
                </View>

                <View style={styles.applyDiscount}> 
                    <TextInput placeholder="0.00" placeholderTextColor={'#000'} onChangeText={(newPoint)=>setRewardPoints(newPoint)} keyboardType={'numeric'} style={{color:'#000',width:'50%',fontSize:height*0.012}}/>
                    <TouchableOpacity onPress={()=>{applyRewardPoints(CART_ID,rewardPoints),console.log(rewardPoints)}} style={[stylesIpad.summaryButton,{width:'50%'}]}>
                        <Text style={[stylesIpad.summaryButtonText,{fontSize:heightPad*0.012}]}>Apply Reward</Text>
                    </TouchableOpacity>
                </View>
                </View>  
            </View>
    </View>
)
}else{
    //Mobile View
    return(
        <>
        <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:'#fff'}}>
        <View style={{padding:height*0.030, display:PARENT_ORDER_ID!=null && route.params.order_date!=null?"flex":"none"}}>
            <Text style={[styles.otherOptions,{fontWeight:'500'}]}>You are adding items to order #{PARENT_ORDER_ID}</Text>
            <Text style={styles.otherOptions}>This order is being delivered on {route.params.order_date}</Text>
        </View>
        <View style={{padding:height*0.030}}>
            <Text style={styles.checkoutTitle}>Checkout</Text>
        </View>
        {displayServerError?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                <Text style={styles.serverError}>{serverError}</Text>  
            </View>:<></>}
        {/* <View style={{display:show}}>
            <OrderFailed></OrderFailed>
        </View> */}
        <View style={styles.estimatedTotal}>
            <Text style={styles.estimatedTotalText}>Estimated Total</Text>
            <Text style={styles.estimatedTotalText}>£ {parseFloat(ITEMS?.total_price).toFixed(2)}</Text>
        </View>
        <View style={{padding:height*0.020}}>
            <View style={styles.titleBox}>
                    <Text style={styles.titleBoxText}>
                        Shipping Address
                    </Text>
                    
            </View>
            <View style={{padding:height*0.018}}>
                
            {paymentMethods?.map((methods)=>{
                methods?.map((method)=>{
                    paymentMethod.push( {
                        label: method.title,
                        code:  method.code
                    });
                })            
            }
            )
            
            }
        {storedCards?.map((methods)=>{
                methods?.map((method,index)=>{
                    // console.log(method);
                    storeCards.push({
                        label: 'ending '+JSON.parse(method.details).maskedCC+' ( expires:'+ JSON.parse(method.details).expirationDate+')',
                        code: method?.payment_method_code,
                        index:index,
                        public_hash:method.public_hash
                    });
                })            
            }
            )
            
            }
            {/* {ShippingMethod?.map((methods)=>{
                shipping.push({
                    carrier_code:methods?.carrier_code,
                    method_code:methods?.method_code
                })     
            })} */}

        <GetSavedAddress></GetSavedAddress>
            </View>
        </View>
        <View style={{padding:height*0.020}}>
            <View style={styles.titleBox}>
                    <Text style={styles.titleBoxText}>
                        Shipping Method
                    </Text>
            </View>
          <View style={styles.shippingMethod}>
                <View style={{flexDirection:'row'}}>
                    <View style={styles.radioContainer}>
                        <View style={styles.radioOuter}>
                            <RadioButtonRN
                            initial={selectedShippingValue}
                                data={ShippingMethod}
                                // selectedBtn={()=>{carrier_code!=null && method_code!=null? selectShippingMethod(CART_ID,carrier_code,method_code):console.log('Select Shipping Method')}}
                                selectedBtn={()=>{setLoadShipping(true);selectShippingMethod(CART_ID,carrier_code,method_code)}}
                                circleSize={9}
                                boxStyle={{backgroundColor:'#f9f9f9',borderWidth:0}}
                                activeColor={'#000'}
                                deactiveColor={'#000'}   
                            />
                        </View>
                        <Text style={[styles.shippingMethodPrice,{fontWeight:'500'}]}>£{route?.params?.cart_shipping}</Text>
                        <Text style={styles.shippingMethodPrice}>{carrier_codeTitle}</Text>
                        <Text style={styles.shippingMethodPrice}>-</Text>
                        <Text style={styles.shippingMethodPrice}>{method_codeTitle}</Text>
                    </View>
                       
                </View>
            </View>
            
            
        </View>

        <View style={{padding:height*0.020,display:PARENT_ORDER_ID?'none':'flex',zIndex:1}}>
            <Text style={styles.chooseDate}>Choose Dates Below<Text style={{color:'red'}}> *</Text></Text>
                <TouchableOpacity style={{flexDirection:'row'}} onPress={()=>{changeCalendarVisible();getMonth()}}>
                    <View style={styles.chooseDateClickable}>
                            <View style={styles.availableChoices}>
                                <Text style={styles.availableChoicesText}>{moment(date).format('DD/MM/YYYY')!='Invalid date'? moment(date).format('DD/MM/YYYY'):''}</Text>
                            </View>
                    </View>
                    <View style={styles.calenderIconContainer}>
                        <Image source={require('../assets/icons/calendar.png')} style={styles.calenderIcon}/>
                    </View>
                </TouchableOpacity>
              
    
                <View style={[styles.calenderView,{display:isCalendarVisible}]}>


                   
                        <Calendar firstDay={1} theme={{
                             selectedDayBackgroundColor: '#00adf5',
                        }} onDayPress={(day) => {
    setDate(moment(day.dateString).format("MM/DD/YYYY"));setIsCalendarVisible('none');
    // console.log(day);
  }} disableAllTouchEventsForDisabledDays={true}  onMonthChange={()=>{getMonth()}} disabledByDefault={true} hideExtraDays={true} markedDates={enableTuesday()}   style={{borderRadius:height*0.010}}
                  />  
                  {/* onMonthChange={(month)=>{getMonth(month)}} */}

                    {/* <CalendarPicker disable={['2']} style={{borderRadius:height*0.010}}></CalendarPicker> */}
                   
                </View>

                </View>
                <Text style={[styles.serverError,{fontSize:height*0.016,marginLeft:width*0.050}]}>{calendarMessage}</Text>
                <View style={{paddingHorizontal:height*0.020}}>
                <View style={styles.titleBox}>
                    <Text style={styles.titleBoxText}>
                        Payment Method
                    </Text>
                    </View>
            </View>
                {load?<ActivityIndicator animating={load}></ActivityIndicator>:<View style={{paddingHorizontal:height*0.020}}>
         <RadioButtonRN
         initial={selectedCardValue}
         data={paymentMethod}
        //  selectedBtn={(selected)=>{getToken(CART_ID,selected?.code);}}
         selectedBtn={(selected)=>{getToken(selected);}}
         circleSize={10}
         boxStyle={{backgroundColor:'#f9f9f9',borderWidth:0,borderRadius:0}}
         activeColor={'#000'}
         deactiveColor={'#000'}
         textStyle={{fontSize:height*0.02}}             
         > 
            
         </RadioButtonRN>
         <View style={{padding:height*0.020,backgroundColor:'#f9f9f9',marginTop:height*0.010,display:selected?.code=='braintree'? 'flex':'none'}}>
                <View style={{}}>
                <CreditCardInput onChange={(form)=>{setCardDetails(form.values.number,form.values.expiry,form.values.cvc);}} allowScroll={true} labelStyle={{color:'#000',marginBottom:height*0.005}} inputStyle={{backgroundColor:'#ffffff',padding:height*0.01}}>
                </CreditCardInput>
                {/* <TouchableOpacity onPress={()=>{setCreditCardInfo(false)}} style={[styles.summaryButton,{width:'80%',padding:height*0.020,marginTop:height*0.020,marginLeft:width*0.10}]}>
                    <Text  style={styles.summaryButtonText}>Save</Text>
                </TouchableOpacity> */}
                </View>
                <Text style={[styles.serverError,{fontSize:height*0.016,marginLeft:width*0.050}]}>{errorMessage}</Text>
            </View>
        
          
            <View style={{marginVertical:height*0.010,paddingHorizontal:height*0.010,display:selected?.code=='braintree_cc_vault'? 'flex':'none'}}>
                {storeCards?.map((item,index)=>{
                    // console.log('::::::::::::::::::',item.index)
                    return(
                        <View style={{backgroundColor:'#f9f9f9',borderWidth:0,padding:height*0.020,marginTop:height*0.010}}>
                        <RadioButton currentValue={item.index} value={selectedCard} onPress={()=>{setSelectedCard(item.index); setPayment(CART_ID,selected.code,item.public_hash)}} innerCircleColor='#000' outerCircleColor='#000' outerCircleSize={18} outerCircleWidth={1} innerCircleSize={10}>
                            <View style={{paddingHorizontal:height*0.016,flexDirection:'row'}}>
                                <Image source={require('../assets/images/vi.png')} style={{resizeMode:'contain',height:'100%'}}/> 
                                <Text style={{color:'#000',fontSize:height*0.02,paddingHorizontal:height*0.010}}>
                                    {item.label}
                                </Text>   
                            </View>
                        </RadioButton>
                        </View>
                    )
                })}
            </View>
           
          
                </View>}
            
         
        <View style={styles.orderSummary}>
            <TouchableOpacity onPress={()=>{
                if(PARENT_ORDER_DATE!=null && PARENT_ORDER_ID !=null){
                    placeTheOrder(CART_ID,String(PARENT_ORDER_DATE));
                }else{
                    if(date!=null){
                        placeTheOrder(CART_ID,String(date));
                        setCalendarMessage('');
                    }else{
                        setCalendarMessage('This is a required field.')
                    }
                    
                }
            // scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });
        }} style={[styles.summaryButton,{width:'100%',padding:height*0.020,marginTop:height*0.010}]}>
            {load? <ActivityIndicator animating={load}></ActivityIndicator>: <Text style={styles.summaryButtonText}>Place Order</Text>}
                
            </TouchableOpacity>
        </View>
        
        <View style={styles.orderSummary}>
            <View style={styles.titleBox}>
                    <Text style={styles.titleBoxText}>
                        Order Summary
                    </Text>
            </View>
            <View style={styles.rewardPointsDesc}>
                <Text style={styles.rewardPointsDescText}>You can earn 200 Reward Points for completing your purchase!</Text>
                <Collapse>
                    <CollapseHeader>
                    <View style={styles.estimateContainer}>
                        <Text style={styles.itemsInCartText}>{ITEMS?.total_qty} Items in Cart</Text>
                        <Image source={require('../assets/icons/down-filled-arrow.png')} style={styles.estimateDownIcon}/>
                    </View>
                    </CollapseHeader>
                    <CollapseBody>
                    <View style={styles.cartItems}>
                    {ITEMS.items.map((item)=>{
                        var price_total=item?.product?.price_range?.maximum_price?.final_price?.value*item.quantity;
                         return( 
                            
                        <View style={{flexDirection:'row',marginTop:height*0.016}}>
                                <View>
                                    <Image source={{uri:item?.product?.small_image?.url,height:height*0.09,width:width*0.07}}
                                    // style={{width:width*0.10,height:height*0.10,resizeMode:"contain"}}
                                    />
                                </View>
                                <View style={styles.itemDetails}>
                                    <Text numberOfLines={2} style={styles.itemDetailsText}>{item?.product?.sku}</Text>
                                    <Text style={styles.itemDetailsText}>{item?.product?.name}</Text>
                                    <Text style={styles.itemDetailsText}>Qty {item?.quantity}</Text>
                                </View>
                                <View>
                                    <Text style={styles.itemPrice}>£ {parseFloat(price_total).toFixed(2)}</Text>
                                </View>
                            </View>
                            )
                        })}
                    </View>
                    </CollapseBody>
                </Collapse>
                <View style={styles.priceDetails}>
                    <View style={styles.subTotalPrice}>
                        <Text style={styles.shippingPrice}>Cart Subtotal</Text>
                        <Text style={styles.shippingPrice}>£{route?.params?.cart_subtotal}</Text>
                    </View>

                    <View style={styles.shippingTotal}>
                        <Text style={styles.shippingPrice}>Shipping</Text>
                        <Text style={styles.shippingPrice}>£{route?.params?.cart_shipping}</Text>
                    </View>
                    <Text style={styles.shippingPrice}>Flat Rate - Fixed</Text>
                    <View style={styles.orderSubtotal}>
                        <Text style={[styles.shippingPrice,{fontWeight:'bold',marginTop:height*0.014}]}>Order Subtotal</Text>
                        <Text style={[styles.shippingPrice,{marginTop:height*0.014}]}>£{parseFloat(ITEMS?.total_price).toFixed(2)}</Text>
                    </View>
                </View>
            </View>

            <View style={styles.applyDiscountBox}>
                <Text style={styles.applyDiscountText}>Apply Discount Code</Text>
                <View style={styles.applyDiscount}> 
                    <TextInput onChangeText={code=>setDiscountCode(code)} placeholder="Enter discount code" placeholderTextColor={'#000'} keyboardType={'numeric'} style={{color:'#000',fontSize:height*0.020}}/>
                    <TouchableOpacity onPress={()=>{applyDiscountCode(CART_ID,discountCode)}} style={[styles.summaryButton]}>
                        <Text style={styles.summaryButtonText}>Apply Discount</Text>
                    </TouchableOpacity>
                </View>
            </View>

            <View style={styles.applyDiscountBox}>
                <Text style={styles.applyDiscountText}>Apply Rewards</Text>
                <View style={{marginTop:height*0.014}}>
                    <Text style={{color:'#000',fontSize:height*0.020}}>You Have {data.rewards.balance} points left</Text>
                    <Text style={{color:'#000',fontSize:height*0.020}}>10 for every 1GBP</Text>
                </View>

                <View style={styles.applyDiscount}> 
                    <TextInput placeholder="0.00" placeholderTextColor={'#000'} onChangeText={(newPoint)=>setRewardPoints(newPoint)} keyboardType={'numeric'} style={{color:'#000',width:'50%',fontSize:height*0.020}}/>
                    <TouchableOpacity onPress={()=>{applyRewardPoints(CART_ID,rewardPoints),console.log(rewardPoints)}} style={[styles.summaryButton]}>
                        <Text style={styles.summaryButtonText}>Apply Reward</Text>
                    </TouchableOpacity>
                </View>
            </View>

        </View>

        </ScrollView>
        </>
    )
}
}

export default Checkout;
