import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useEffect, useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import Header from "./Header";
import { useDispatch, useSelector } from "react-redux";
import { gql, useMutation, useQuery } from "@apollo/client";
import { REORDER } from "./mutations/reorderItems";

import { AddtoCart, NumberofItems, setSubTotal, setTotalPrice, TotalQuantity } from "./redux/actions";
const PreviousOrders = ({navigation}) => {
    const CUSTOMER=useSelector(state=>state.customer);
    const dispatch=useDispatch();
    const [ReorderItems]=useMutation(REORDER);
    const [serverError,setServerErrorMsg] = useState('');
const [displayServerError,setDisplayServerErrorMsg] = useState(false);

    const orders=[];
    const reorderPreviousOrder=async(orderNumber)=>{
        try{   
            const{
              data,errors,
            }= await ReorderItems({
                variables:{
                   orderNumber
                }
            });
           
            dispatch(TotalQuantity(data.reorderItems.cart.total_quantity));
            dispatch(NumberofItems(data.reorderItems.cart.items.length));
            dispatch(AddtoCart(data.reorderItems.cart.items));
            dispatch(setTotalPrice(data.reorderItems.cart.prices.grand_total.value));
            dispatch(setSubTotal(data.reorderItems.cart.prices.subtotal_excluding_tax.value))
            navigation.navigate('CartPage');            
          }catch(error){
                console.log(error);
                setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message);    
          }
    }
    const AddToThisOrder=()=>{
        const ORDERR_DETAILS=gql`
        {
            customer {
                    orders(filter: {}
                      )  
                      {      
                        items{
                            number
                          status
                            total{
                                subtotal{
                                  value
                                }
                                grand_total{
                                  value
                                  currency
                                }
                              }      
                            items{
                              
                                product_name
                                product_sku
                                product_sale_price {
                                value
                              }
                                quantity_ordered
                                quantity_canceled
                              }
                            shipping_method
                            shipping_address{
                            firstname
                            lastname
                            street
                            city
                            country_code
                            telephone
                            company
                            postcode
                            region
                          }
                          billing_address{
                            firstname
                            lastname
                            street
                            city
                            country_code
                            telephone
                            company
                            postcode
                            region
                            }
                            payment_methods{
                                name
                              }
                        }
                        
                      }
                    
                     }
                    country(id:"GB"){
                        full_name_english
                    }
                    currency{
                        default_display_currency_symbol
                    }
                  }
        `;
        const { loading, error, data } = useQuery(ORDERR_DETAILS);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      orders.push(data);
    }
   AddToThisOrder();
   if (displayServerError) {
    setTimeout(() => {
      setDisplayServerErrorMsg(false);
   }, 12000);
}

   const addToThisOrder=(orderNumber)=>{
      data.customer.orders.items.map((order,index)=>{
        if(order.number==orderNumber){
          // dispatch(TotalQuantity(data.reorderItems.cart.total_quantity));
          // dispatch(NumberofItems(data.reorderItems.cart.items.length));
          // dispatch(AddtoCart(data.reorderItems.cart.items));
          // dispatch(setTotalPrice(data.reorderItems.cart.prices.grand_total.value));
          // dispatch(setSubTotal(data.reorderItems.cart.prices.subtotal_excluding_tax.value))
          // data.customer.orders.items[index].items.map((products)=>{
          //   console.log(products);
          // })
          console.log(data.customer.orders.items[index].items);
        }
      })
   }
    const GET_ORDER=gql`
    {
      customer {
        firstname
        lastname
              orders(filter: {}
                )  
                {      
                  items{
                    order_date
                      number
                    status
                      total{
                          subtotal{
                            value
                          }
                          grand_total{
                            value
                            currency
                          }
                        }      
                      items{
                        
                          product_name
                          product_sku
                          product_sale_price {
                          value
                        }
                          quantity_ordered
                          quantity_canceled
                        }
                      shipping_method
                      shipping_address{
                      firstname
                      lastname
                      street
                      city
                      country_code
                      telephone
                      company
                      postcode
                      region
                    }
                    billing_address{
                      firstname
                      lastname
                      street
                      city
                      country_code
                      telephone
                      company
                      postcode
                      region
                      }
                      payment_methods{
                          name
                        }
                  }
                  
                }
              
               }
              country(id:"GB"){
                  full_name_english
              }
              currency{
                  default_display_currency_symbol
              }
            }
    `;
    const { loading, error, data } = useQuery(GET_ORDER);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>My Orders</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
	<Text style={styles.serverError}>{serverError}</Text>  
</View>:<View></View>}
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={[styles.myAccountMenuText,{fontWeight:'700'}]}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        {data.customer.orders?.items.map((order)=>{
            return(
 <View style={{padding:height*0.022}}>
 <View style={styles.orderNumber}>
     <Text style={[styles.orderDetail,{fontWeight:'700'}]}>Order #:</Text>
     <Text style={styles.orderDetail}>   {order.number}</Text>
 </View>
 <View style={styles.orderNumber}>
     <Text style={[styles.orderDetail,{fontWeight:'700'}]}>Date:</Text>
     <Text style={styles.orderDetail}>   {order.order_date}</Text>
 </View>
 <View style={styles.orderNumber}>
     <Text style={[styles.orderDetail,{fontWeight:'700'}]}>Ship to</Text>
     <Text style={styles.orderDetail}>   {data.customer.firstname} {data.customer.lastname}</Text>
 </View>
 <View style={styles.orderNumber}>
     <Text style={[styles.orderDetail,{fontWeight:'700'}]}>Order Total:</Text>
     <Text style={styles.orderDetail}>   {data.currency.default_display_currency_symbol}{order.total.grand_total.value}</Text>
 </View>
 <View style={styles.orderNumber}>
     <Text style={[styles.orderDetail,{fontWeight:'700'}]}>Status:</Text>
     <Text style={styles.orderDetail}>   {order.status}</Text>
 </View>
 <View style={styles.orderNumber}>
     <TouchableOpacity onPress={()=>navigation.navigate('ViewOrder',{order_number:order.number,order_status:order.status,order_date:order.order_date,order_price:order.total.grand_total.value})}><Text style={styles.orderDetail}>View Order</Text></TouchableOpacity>
     <Text style={{fontSize:height*0.020,color:'#000'}}>   |   </Text>
     <TouchableOpacity onPress={()=>{reorderPreviousOrder(order.number)}}><Text style={styles.orderDetail}>Reorder</Text></TouchableOpacity>
     <Text style={{fontSize:height*0.020,color:'#000'}}>   |   </Text>
     <TouchableOpacity onPress={()=>{addToThisOrder(order.number)}}><Text style={styles.orderDetail}>Add to this Order</Text></TouchableOpacity>
 </View>
 <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
</View>
            )
        })}    
        </ScrollView>
        </>
    )
}

export default PreviousOrders;