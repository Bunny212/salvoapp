import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import React, { useEffect, useState } from "react";
import { View, Text, Dimensions, Image, TouchableOpacity, TextInput, ScrollView,ActivityIndicator,Platform, BackHandler } from "react-native";
import Swiper from "react-native-swiper";
import styles from "../styles/styles";
import CheckBox from '@react-native-community/checkbox';
import { gql ,useMutation,useQuery} from "@apollo/client";
import Basket from './Basket';
import { useDispatch, useSelector } from "react-redux";
import {ADD_TO_CART} from "./mutations/addToCart";
import { CREATE_CART } from "./mutations/createCart";
import { AddtoCart, CartIdSet, NumberofItems, setnavisionResponse, setShippingValue, setSubTotal, setTotalPrice, TotalQuantity } from "./redux/actions";
import { UPDATE_CART } from "./mutations/updateCart";
import WishList from "./list/WishList";
import { RenderHTML, RenderHTMLConfigProvider,TRenderEngineProvider} from 'react-native-render-html';
import useWindowDimensions from "react-native/Libraries/Utilities/useWindowDimensions";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
import { Col, Row, Rows, Table } from "react-native-table-component";
import stylesIpad from "../styles/stylesIpad";

const { width, height } = Dimensions.get('window')
const Product = ({navigation,route}) =>{
    const heightPad = useWindowDimensions().height;
  const widthPad = useWindowDimensions().width;
    const [toggleCheckBox, setToggleCheckBox] = useState('')
    const ITEMS=useSelector(state=>state);
    const [cartId,setCartId]=useState(null);
    const [quantity,setQuantity]=useState(1);
    const dispatch=useDispatch();
    const TOKEN=useSelector(state=>state.token);
    const [addProductsToCart]=useMutation(ADD_TO_CART);
    const [updateCartItems]=useMutation(UPDATE_CART);
    const regex = /(<([^>]+)>)/ig;
    const units=[];
    const table=[];
    const [wishListVisible, setWishListVisible] = useState('none');
    const [serverError,setServerErrorMsg] = useState('');
    const [displayMessage,setDisplayMessage]=useState(false);
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const PRODUCT_SKU=useSelector(state=>state.previousOrders);



const [fetchCartId]=useMutation(CREATE_CART);
const createCart = async(sku,quantity)=>{
  try{
    const{
      data,errors,
    }=await fetchCartId();
    setCartId(data?.cartId);
    setTimeout(() => {
      addToCart(sku,quantity,data?.cartId);
  }, 5000);
  }catch(error){
    console.log('1 SUB',error);
      setDisplayServerErrorMsg(true);
      setServerErrorMsg(error.message);    

  }
}
    const [descOpen, setDescOpen] = useState('flex');
    const changeDescOpen = () =>{
        if(descOpen=='none'){
            setDescOpen('flex')
        }else{
            setDescOpen('none');
        }
    }
    const [nutritionOpen, setNutritionOpen] = useState('none');
    const changeNutritionOpen = () =>{
        if(nutritionOpen=='none'){
            setNutritionOpen('flex')
        }else{
            setNutritionOpen('none');
        }
    }
    const [usageOpen, setUsageOpen] = useState('none');
    const changeUsageOpen = () =>{
        if(usageOpen=='none'){
            setUsageOpen('flex')
        }else{
            setUsageOpen('none');
        }
    }
    const [brandDetailsOpen, setBrandDetailsOpen] = useState('none');
    const changeBrandDetailsOpen = () =>{
        if(brandDetailsOpen=='none'){
            setBrandDetailsOpen('flex')
        }else{
            setBrandDetailsOpen('none');
        }
    }

    const [ingredientOpen, setIngredientOpen] = useState('none');
    const changeIngredientOpen = () =>{
        if(ingredientOpen=='none'){
            setIngredientOpen('flex')
        }else{
            setIngredientOpen('none');
        }
    }

    const changeWishListVisible = () =>{
        if(wishListVisible=='none'){
        setWishListVisible('flex');
        }
    }
    const close=()=>{
        setWishListVisible('none');
    }

    const getUnit=()=>{
    const SALES_UNIT_OF_MEASURE=gql`
    {
      customAttributeMetadata(
        attributes: [
          {
            attribute_code: "sales_unit_of_measure"
            entity_type: "catalog_product"
          }
        ]
      ) {
        items {
          attribute_code
          attribute_type
          entity_type
          input_type
          attribute_options {
           value
           label
         }
        }
      }
    }
      `;
      const { loading, error, data } = useQuery(SALES_UNIT_OF_MEASURE);
      if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    // console.log(data.customAttributeMetadata.items[0].attribute_options);
    data?.customAttributeMetadata?.items[0]?.attribute_options.map((unit)=>{
      units.push(unit);
    })
  }
  getUnit();
  if (displayMessage) {
    setTimeout(() => {
      setDisplayMessage(!displayMessage)
    }, 12000);
  }
  const addToCart = async (sku,quantity,cartId) =>{
      try{   
        const{
          data,errors,
        }= await addProductsToCart({
            variables:{
                cartId,
                sku,
                quantity
            }
        });
        dispatch(TotalQuantity(data?.addProductsToCart?.cart?.total_quantity));
        dispatch(NumberofItems(data?.addProductsToCart?.cart?.items?.length));
        dispatch(AddtoCart(data?.addProductsToCart?.cart?.items));
        dispatch(setTotalPrice(data?.addProductsToCart?.cart?.prices?.grand_total?.value));
        dispatch(setSubTotal(data?.addProductsToCart?.cart?.prices?.subtotal_excluding_tax?.value));
        dispatch(setShippingValue(data?.addProductsToCart?.cart?.shipping_addresses[0]?.selected_shipping_method?.amount?.value));
        dispatch(CartIdSet(cartId))
      }catch(error){
        console.log(error);
        setDisplayServerErrorMsg(true);
        setServerErrorMsg(error.message);    
      }
    }
  
    function handleBackButtonClick() {
        if(route?.params?.block_title!=null){
            navigation.navigate('BlockList',{title:route?.params?.block_title,skus:PRODUCT_SKU});
            return true;
        }else if(route?.params?.block_title!=null){
            console.log('ID:::::::::::::::::::::::::',route.params);
            navigation.navigate('SubProduct',{category_sub_id:route.params.category_sub_id,title:route.params.title,categoryId:route.params.categoryId});
            return true;    
        }else if(route.params.category_sub_id==null){
            console.log('SKUS:::::::::::::::::::::;',PRODUCT_SKU);
            navigation.navigate('PreviousPurchases');
        }
      }
      useEffect(() => {
        BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
        return () => {
          BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
        };
      }, []);
  

    useEffect(()=>{

            setCartId(ITEMS.cartId);
            
      },[])
      const updateCart =async (cartId,uid,quantity)=>{
        try{
            const {error,data}=await updateCartItems({
                variables:{
                    cartId,
                    uid,
                    quantity
                }
            });
            dispatch(AddtoCart(data?.updateCartItems?.cart?.items));
            dispatch(NumberofItems(data?.updateCartItems?.cart?.items?.length));
            dispatch(TotalQuantity(data?.updateCartItems?.cart?.total_quantity));
            dispatch(setTotalPrice(data?.updateCartItems?.cart?.prices?.grand_total?.value));
            dispatch(setSubTotal(data?.updateCartItems?.cart?.prices?.subtotal_excluding_tax?.value));
            dispatch(setShippingValue(data?.updateCartItems?.cart?.shipping_addresses[0]?.selected_shipping_method?.amount?.value));
        }catch(error){
            console.log(error);
            setDisplayServerErrorMsg(true);
            setServerErrorMsg(error.message);    
        }
    }
    if (displayServerError) {
        setTimeout(() => {
          setDisplayServerErrorMsg(false);
        }, 12000);
      }
    const getHeading=(heading)=>{
        let parts = heading.split(': ');
let obj = {
  [parts[0]]: parts[1]
};
console.log(Object.values(obj)[0]);
return Object.values(obj)[0];
    }
    const PRODUCT_DETIALS=gql`
    {
        products(filter: {sku: {eq: ${route.params.sku}}}){   
          items {
            name
            sales_unit_of_measure
            sku
            stock_status
            ingredients
            nutrition
            brand_details
            description{
                html
              }
              media_gallery{
                url
              }
              price_range{
                  maximum_price{
                    final_price{
                      value
                    }
                }
            }
          }
        }
      }`;
      
        const { loading, error, data } = useQuery(PRODUCT_DETIALS);
        const {width}=useWindowDimensions();
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
       if(Platform.isPad){
        return(
            <View style={[stylesIpad.container,{flexDirection:'row',padding:'3%'}]}>
                {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                    <Text style={styles.serverError}>{serverError}</Text>  
                </View>:<View></View>}
                 <View style={[stylesIpad.wishListOuterContainer,{display:wishListVisible}]}>
                <View style={stylesIpad.wishListClose}>
                    <TouchableOpacity onPress={()=>{close()}}>
                        <Image source={require('../assets/icons/close.png')} 
                        style={stylesIpad.wishListCloseIcon}/>
                    </TouchableOpacity>
                </View>
                <WishList style={{display:wishListVisible}}/>
            </View>
                 <View style={{width:'50%',height:'100%',}}>
                 <View style={{position:'absolute',left:'7%'}}>
                        <TouchableOpacity onPress={()=>handleBackButtonClick()}>
                            <Image source={require('../assets/icons/back-arrow.png')} style={[stylesIpad.tasksIcon,{
                                height:heightPad*0.030,
                                width:widthPad*0.030,
                            }]}/>
                        </TouchableOpacity>
                        </View>
                 {data.products?.items.map((item)=>{
         
            return(
                <View style={{height:'40%'}}>     
                <Swiper scrollEnabled={true} alwaysBounceHorizontal={true} index={0} 
            activeDotStyle={{backgroundColor:'#317250'}} showsPagination={true} 
            // nextButton={<Text style={{color:'#555555',fontSize:height*0.10,backgroundColor:'#E6E8EA'}}>›</Text>}
            // prevButton={<Text style={{color:'#555555',fontSize:height*0.10,backgroundColor:'#E6E8EA'}}>‹</Text>}
            showsButtons={false} style={{maxHeight:heightPad*0.400}} loop={true} dotColor={'#ADADAD'}>

                {/* <View style={styles.swiperImage}>
                    <Image style={{resizeMode:'contain'}} source={{url:item.media_gallery[0].url,height:height*0.25,width:width*0.55}}
                    />
                </View> */}
                {item.media_gallery.map((image)=>{
                    return(
                        <>
                        <View style={{}}>
                                              
                       
                        </View>
                        <View key={image} style={stylesIpad.swiperImage}>
                            {Platform.OS==='ios'? <TouchableOpacity><Image style={{resizeMode:'contain'}} source={{url:image.url,height:heightPad*0.25,width:widthPad*0.55}}/></TouchableOpacity> : <TouchableOpacity><Image style={{resizeMode:'contain'}} source={{uri:image.url,height:heightPad*0.38,width:widthPad*1.0}}/></TouchableOpacity>}
                        </View>
                        </>
                )
                })}
       
            </Swiper>
           
               
                </View>
            )
           

            })}
             </View>
             <View style={{width:'50%',height:'100%',paddingTop:'3%'}}>
                <View style={{position:'absolute',right:'7%'}}>
                            <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible():navigation.navigate('Login')}}>
                                <Image source={require('../assets/icons/tasks.png')} style={[stylesIpad.tasksIcon,{
                                height:heightPad*0.030,
                                width:widthPad*0.030,
                            }]}/></TouchableOpacity>

                        </View>
                        {data?.products?.items.map((item)=>{
                               const html={
                                html:item.description.html
                            }
                            
    return(
        <ScrollView>
        <View style={{paddingLeft:widthPad*0.030}}>
        <Text style={[stylesIpad.prodSku,{fontWeight:'400'}]}>{item.sku}</Text>
        <Text style={[stylesIpad.prodPrice,{fontSize:heightPad*0.020}]}>£{parseFloat(item?.price_range?.maximum_price?.final_price?.value).toFixed(2)} {units[item?.sales_unit_of_measure-1]!=undefined?'/'+units[item?.sales_unit_of_measure-1].label:''}</Text>
        <Text style={[stylesIpad.prodTitle,{fontSize:heightPad*0.025}]}>{item.name}</Text>
    <View style={stylesIpad.prodQty}>
        <Text style={[stylesIpad.prodQtyText,{fontSize:heightPad*0.018}]}>Qty</Text>
        <TextInput editable={item.stock_status=='IN_STOCK'?true:false} keyboardType='numeric' onChangeText={newQuantity=>setQuantity(newQuantity)} style={stylesIpad.prodQtyInput}>1</TextInput>
    </View>
    {/* //ButtonHere */}
    <View style={[stylesIpad.addToBasketCont,{ paddingTop:'10%',paddingHorizontal:0}]}>
                    {TOKEN==null ? <TouchableOpacity onPress={item.stock_status=='IN_STOCK'? ()=>{navigation.navigate('Login')}:()=>{}} 
                    style={[stylesIpad.addToBasket,{width:'100%',padding:'4%'}]}>
                        <Text style={[stylesIpad.addToBasketText,{fontSize:heightPad*0.015}]}>{item.stock_status=='IN_STOCK'? "Login/Create an Account":"Out of Stock"}</Text></TouchableOpacity> : item.stock_status=='IN_STOCK'? 
                        <TouchableOpacity onPress={route.params.uid!=null? ()=>updateCart(ITEMS.cartId,route.params.uid,quantity) :()=>{createCart(item.sku,quantity);setDisplayMessage(!displayMessage)}} 
                        style={[stylesIpad.addToBasket,{width:'100%',padding:'4%'}]}>
                    <Text style={[stylesIpad.addToBasketText,{fontSize:heightPad*0.015}]}>{route.params.uid!=null? "Update Cart":"Add to Basket"}</Text>
                  </TouchableOpacity>:<View style={[stylesIpad.addToBasket,{width:'100%',padding:'4%'}]}>
                    <Text style={[stylesIpad.addToBasketText,{fontSize:heightPad*0.015}]}>Out of Stock</Text>
                  </View>}         
                </View>
    <View style={stylesIpad.accordinSaperator}></View>
                <View style={{}}>

                    {item.description.html==null?<View></View>: <View>
                <TouchableOpacity onPress={()=>changeDescOpen()} style={[stylesIpad.accordinTitle,{padding:'3%'}]}>
                    <Text style={[stylesIpad.accordinTitleText,{fontSize:height*0.015,fontWeight:'700'}]}>Description</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={[stylesIpad.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}],  width:width*0.020,
  height:height*0.020,}]}/>
                </TouchableOpacity>
                <View style={[stylesIpad.accordinInner,{display:descOpen}]}>
                   
                    {item.description.html.replace(regex,'')==null?<Text style={[stylesIpad.accordinTitleText,{fontSize:height*0.015,fontWeight:'700'}]}>No Description Added.</Text>:                
                    
                    <RenderHTML
                        contentWidth={width}
                        source={html}
                            classesStyles={stylesClass} 
                            tagsStyles={stylesTags} 
                    />           
                    }
                </View>
            </View>}
           
            {item?.brand_usage==null? <View></View>:
            <View>
                <TouchableOpacity onPress={()=>changeUsageOpen()}>
                <View style={[stylesIpad.accordinTitle,{padding:'3%'}]}>
                    <Text style={[stylesIpad.accordinTitleText,{fontSize:height*0.015,fontWeight:'700'}]}>Usage</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={stylesIpad.downArrow}/>
                </View>
                </TouchableOpacity>
                <View style={{display:usageOpen}}>
                <View style={stylesIpad.accordinInner}>
                    <Text style={stylesIpad.accordinInnerText}>- Usage</Text>
                </View>
                </View>
            </View>}
        {item?.brand_details==null? <View></View>:  <View>
                <TouchableOpacity onPress={()=>changeBrandDetailsOpen()}>
                <View style={[stylesIpad.accordinTitle,{padding:'3%'}]}>
                    <Text style={[stylesIpad.accordinTitleText,{fontSize:height*0.015,fontWeight:'700'}]}>Brand Details</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={stylesIpad.downArrow}/>
                </View>
                </TouchableOpacity>
                <View style={{display:brandDetailsOpen}}>
                <View style={stylesIpad.accordinInner}>
                    <Text style={[stylesIpad.accordinTitleText,{fontSize:height*0.015,fontWeight:'700'}]}>{item?.brand_details?.replace(regex,'')==null?'No Brand Details added':item?.brand_details?.replace(regex,'')}</Text>
                </View>
                </View>
            </View>}
          
                {item.nutrition==null? <View></View>:<View>
                <TouchableOpacity onPress={()=>changeNutritionOpen()}>
                <View style={[stylesIpad.accordinTitle,{padding:'3%'}]}>
                    <Text style={[stylesIpad.accordinTitleText,{fontSize:height*0.015,fontWeight:'700'}]}>Nutrition</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={[stylesIpad.downArrow,{transform:nutritionOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}],  width:width*0.020,
  height:height*0.020,}]}/>
                </View>
                </TouchableOpacity>
                <View>
                <View style={[stylesIpad.accordinInner,{display:nutritionOpen}]}>
                    
                <Text numberOfLines={2} style={{fontSize:height*0.012,textAlign:'center',backgroundColor:'#F7F7F7',padding:height*0.020,borderWidth:height*0.001,opacity:0.5}}>{getHeading(item.nutrition.split("|")[0])}</Text>
                    {item.nutrition.split("|").map((nutrition)=>{
                            table.push(nutrition.split(':'));
                        }
                    )}
 <Table style={{opacity:0.5}}>
      {table.splice(1).map((rowData, index) => (
        <Row
          key={index}
          data={rowData}
          style={[stylesIpad.tablerow,{backgroundColor:index%2!==1?'#F7F7F7':'#ffffff',}]}
          textStyle={[stylesIpad.tabletext,{fontSize:height*0.012}]}
        />
        
      ))}
    </Table>
                </View>
                </View>
            </View>}
            
    {item.ingredients==null? <View></View>: <View>
                <TouchableOpacity onPress={()=>changeIngredientOpen()}>
                <View style={[stylesIpad.accordinTitle,{padding:'3%'}]}>
                    <Text style={[stylesIpad.accordinTitleText,{fontSize:height*0.015,fontWeight:'700'}]}>Ingredients</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={[stylesIpad.downArrow,{transform:ingredientOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}],  width:width*0.020,
  height:height*0.020,}]}/>
                </View>
                </TouchableOpacity>
                <View style={{display:ingredientOpen}}>
                <View style={stylesIpad.accordinInner}>
                    <Text style={[stylesIpad.accordinInnerText,{fontSize:height*0.012}]}>{item.ingredients.replace(regex,'')}</Text>
                </View>
                </View>
            </View>}
           
        </View>
    </View>
    </ScrollView>
    )
  })}
                </View>
                
             </View>
             
        )
       }else{
        //Mobile View
    return(
    <View style={{flex:1,backgroundColor:'#fff'}}>
         {data.products?.items.map((item)=>{
            const html={
                html:item.description.html
            }
            return(
        <ScrollView>
            {displayMessage? <View style={{width:'100%'}}>
                <View style={{flexDirection:'row',padding:height*0.020,backgroundColor:'#e5efe5',marginTop:height*0.010,alignItems:'center'}}>
                    <Image source={require('../assets/icons/checked.png')} style={{width:width*0.07,height:height*0.04,resizeMode:'contain'}}></Image>
                    <View style={{marginHorizontal:width*0.022}}>
                    <Text style={{color:'#006400',fontSize:height*0.018,paddingRight:width*0.020}}>  You added {data?.products?.items[0]?.name} to your 
                        <TouchableOpacity onPress={()=>navigation.navigate('Default')}>
                        <Text style={{color:'#000',fontSize:height*0.018,top:height*0.004}}> shopping cart.</Text></TouchableOpacity>
                    </Text>
                    </View>
                </View>
            </View> : null}
            <Swiper scrollEnabled={true} alwaysBounceHorizontal={true} index={0} 
            activeDotStyle={{backgroundColor:'#317250'}} showsPagination={true} 
            // nextButton={<Text style={{color:'#555555',fontSize:height*0.10,backgroundColor:'#E6E8EA'}}>›</Text>}
            // prevButton={<Text style={{color:'#555555',fontSize:height*0.10,backgroundColor:'#E6E8EA'}}>‹</Text>}
            showsButtons={false} style={{maxHeight:height*0.400}} loop={true} dotColor='#ADADAD'>

                {/* <View style={styles.swiperImage}>
                    <Image style={{resizeMode:'contain'}} source={{url:item.media_gallery[0].url,height:height*0.25,width:width*0.55}}
                    />
                </View> */}
                {item.media_gallery.map((image)=>{
                    return(
                        <>
                        <View style={{}}>
                                                <View style={{left:width*0.010}}>
                        <TouchableOpacity onPress={()=>handleBackButtonClick()} style={{left:width*0.040,width:'10%'}}>
                <Image source={require('../assets/icons/back-arrow.png')} style={styles.tasksIcon}/>
            </TouchableOpacity>
            </View>
                        <View style={{position:'absolute',right:width*0.070}}>
                            <TouchableOpacity onPress={()=>{TOKEN!=null? changeWishListVisible():navigation.navigate('Login')}}><Image source={require('../assets/icons/tasks.png')} style={styles.tasksIcon}/></TouchableOpacity>
                        </View>
                        </View>
                        <View key={image} style={styles.swiperImage}>
                            {Platform.OS==='ios'? <TouchableOpacity><Image style={{resizeMode:'contain'}} source={{url:image.url,height:height*0.25,width:width*0.55}}/></TouchableOpacity> : <TouchableOpacity><Image style={{resizeMode:'contain'}} source={{uri:image.url,height:height*0.38,width:width*1.0}}/></TouchableOpacity>}
                        </View>
                        </>
                )
                })}
       
            </Swiper>
            <View style={[styles.wishListOuterContainer,{display:wishListVisible}]}>
                <View style={styles.wishListClose}>
                    <TouchableOpacity onPress={()=>{close()}}>
                        <Image source={require('../assets/icons/close.png')} 
                        style={styles.wishListCloseIcon}/>
                    </TouchableOpacity>
                </View>
                <WishList style={{display:wishListVisible}}/>
            </View>

            <View style={[styles.prodSaperator,{marginTop:height*0.040}]}></View>
                <View style={{paddingLeft:width*0.030}}>
                    <Text style={styles.prodSku}>SKU#: {item.sku}</Text>
                    <Text style={styles.prodPrice}>£{parseFloat(item?.price_range?.maximum_price?.final_price?.value).toFixed(2)} {units[item?.sales_unit_of_measure-1]!=undefined?'/'+units[item?.sales_unit_of_measure-1].label:''}</Text>
                    <Text style={styles.prodTitle}>{item.name}</Text>
                <View style={styles.prodQty}>
                    <Text style={styles.prodQtyText}>Qty</Text>
                    <TextInput editable={item.stock_status=='IN_STOCK'?true:false} keyboardType='numeric' onChangeText={newQuantity=>setQuantity(newQuantity)} style={styles.prodQtyInput}>1</TextInput>
                </View>
                </View>
                {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
                    <Text style={styles.serverError}>{serverError}</Text>  
                </View>:<View></View>}
                <View style={styles.addToBasketCont}>
                    {TOKEN==null ? <TouchableOpacity onPress={item.stock_status=='IN_STOCK'? ()=>{navigation.navigate('Login')}:()=>{}} style={styles.addToBasket}><Text style={styles.addToBasketText}>{item.stock_status=='IN_STOCK'? "Login/Create an Account":"Out of Stock"}</Text></TouchableOpacity> : item.stock_status=='IN_STOCK'? <TouchableOpacity onPress={route.params.uid!=null? ()=>updateCart(ITEMS.cartId,route.params.uid,quantity) :()=>{createCart(item.sku,quantity);setDisplayMessage(!displayMessage)}} style={styles.addToBasket}>
                    <Text style={styles.addToBasketText}>{route.params.uid!=null? "Update Cart":"Add to Basket"}</Text>
                  </TouchableOpacity>:<View style={styles.addToBasket}>
                    <Text style={styles.addToBasketText}>Out of Stock</Text>
                  </View>}         
                </View>
            <View style={styles.accordinSaperator}></View>
                <View style={{}}>
                    {item.description.html==null?<View></View>: <View>
                <TouchableOpacity onPress={()=>changeDescOpen()} style={styles.accordinTitle}>
                    <Text style={styles.accordinTitleText}>Description</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:descOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                </TouchableOpacity>
                <View style={[styles.accordinInner,{display:descOpen}]}>
                   
                    {item.description.html.replace(regex,'')==null?<Text style={styles.accordinInnerText}>No Description Added.</Text>:                <RenderHTML
                        contentWidth={width}
                        source={html}
                            classesStyles={stylesClass} 
                            tagsStyles={stylesTags}
                    />}
                </View>
            </View>}
           
            {item?.brand_usage==null? <View></View>:
            <View>
                <TouchableOpacity onPress={()=>changeUsageOpen()}>
                <View style={styles.accordinTitle}>
                    <Text style={styles.accordinTitleText}>Usage</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </TouchableOpacity>
                <View style={{display:usageOpen}}>
                <View style={styles.accordinInner}>
                    <Text style={styles.accordinInnerText}>- Usage</Text>
                </View>
                </View>
            </View>}
        {item?.brand_details==null? <View></View>:  <View>
                <TouchableOpacity onPress={()=>changeBrandDetailsOpen()}>
                <View style={styles.accordinTitle}>
                    <Text style={styles.accordinTitleText}>Brand Details</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </TouchableOpacity>
                <View style={{display:brandDetailsOpen}}>
                <View style={styles.accordinInner}>
                    <Text style={styles.accordinInnerText}>{item?.brand_details?.replace(regex,'')==null?'No Brand Details added':item?.brand_details?.replace(regex,'')}</Text>
                </View>
                </View>
            </View>}
          
                {item.nutrition==null? <View></View>:<View>
                <TouchableOpacity onPress={()=>changeNutritionOpen()}>
                <View style={styles.accordinTitle}>
                    <Text style={styles.accordinTitleText}>Nutrition</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:nutritionOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                </View>
                </TouchableOpacity>
                <View>
                <View style={[styles.accordinInner,{display:nutritionOpen}]}>
                    
                <Text numberOfLines={2} style={{textAlign:'center',backgroundColor:'#F7F7F7',padding:height*0.020,borderWidth:height*0.001,opacity:0.5}}>{getHeading(item.nutrition.split("|")[0])}</Text>
                    {item.nutrition.split("|").map((nutrition)=>{
                            table.push(nutrition.split(':'));
                        }
                    )}
 <Table style={{opacity:0.5}}>
      {table.splice(1).map((rowData, index) => (
        <Row
          key={index}
          data={rowData}
          style={[styles.tablerow,{backgroundColor:index%2!==1?'#F7F7F7':'#ffffff',}]}
          textStyle={styles.tabletext}
        />
      ))}
    </Table>
                </View>
                </View>
            </View>}
            
    {item.ingredients==null? <View></View>: <View>
                <TouchableOpacity onPress={()=>changeIngredientOpen()}>
                <View style={styles.accordinTitle}>
                    <Text style={styles.accordinTitleText}>Ingredients</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={[styles.downArrow,{transform:ingredientOpen=='flex'? [{rotateX: '180deg'}]:[{rotateY:'180deg'}]}]}/>
                </View>
                </TouchableOpacity>
                <View style={{display:ingredientOpen}}>
                <View style={styles.accordinInner}>
                    <Text style={styles.accordinInnerText}>{item.ingredients.replace(regex,'')}</Text>
                </View>
                </View>
            </View>}
           
        </View>
        <View style={styles.discountContainer}>
            {/* <Text style={styles.frequentlyBought}>Frequently bought together</Text>
            <Text style={styles.saveAmount}>Save upto 10% when you schedule repeat deliveries</Text> */}
        </View>
        {/* <View>
            <View style={styles.imagesContainer}>
                <Image source={require('../assets/images/block/rummo_test.png')} style={styles.image}/>
                <Text style={{fontSize:height*0.026}}>+</Text>
                <Image source={require('../assets/images/block/rummo_test.png')} style={styles.image}/>
                <Text style={{fontSize:height*0.026}}>+</Text>
                <Image source={require('../assets/images/block/rummo_test.png')} style={styles.image}/>
            </View>
        </View>
            <View style={{padding:height*0.010}}>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                    <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox}></CheckBox>
                    <Text style={styles.checkboxDetail}>Product Name + price / case</Text>
                </View>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox}></CheckBox>
                    <Text style={styles.checkboxDetail}>Product Name + price / case</Text>
                </View>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox}></CheckBox>
                    <Text style={styles.checkboxDetail}>Product Name + price / case</Text>
                </View>
            </View>
         
            <View style={styles.totalPriceContainer}>
                <Text style={styles.totalPrice}>Total Price: £ {item.price_range.maximum_price.final_price.value}</Text>
            </View> */}
        </ScrollView>
            )})}
            {TOKEN!=null?<View style={{height:'20%',display:ITEMS.total_qty==0?'none':'flex'}}>
                <Basket navigation={navigation}></Basket>
            </View>:<View></View>}
        </View>

    )
        }  
} 

export default Product;