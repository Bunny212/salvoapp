import React from "react";
import { View, Text,Dimensions,Image,TouchableOpacity, ScrollView } from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');

const Dolce = () => {
    return(
        <>
        <ScrollView>
        <View style={styles.brandImgBox}>
            <Image source={require('../assets/brands/dolce.png')}
            style={styles.brandImg}/>
        </View>

        <View style={styles.brandDescBox}>
            <Text style={styles.brandDescBold}>
                San Benedetto have always led with one fundamental value; to create wellbeing for the entire community. As the 
                biggest Italian company in the drinks sector, the San Benedetto Group have seen their original, ancient source of 
                water be sold in over 100 countries to become second-biggest producer of soft drinks.</Text>
            
            <Text style={[styles.brandDesc,{marginTop:height*0.040}]}>
                San Benedetto have always led with one fundamental value; to create wellbeing for the entire community. As the biggest 
                Italian company in the drinks sector, the San Benedetto Group have seen their original, ancient source of water be sold 
                in over 100 countries to become second-biggest producer of soft drinks.</Text>
            
            <Text style={[styles.brandDesc,{marginRight:width*0.054}]}>
            Leading the way in the production of mineral waters and iced teas, the company embraces innovation and carefully selects 
            its sources so only the highest the standards are adhered to. </Text>

            <Text style={styles.brandDesc}>
                Care for environmental issues and the need to save energy is a fundamental feature of the mission at San Benedetto, as 
                well as its ability to find new solutions and stimulate new patterns of consumption. In line with their environmental 
                concerns, they have been using PET (polyethylene terephthalate) since the 1980s, making them one of the first Italian 
                companies to do this. They have the lightest bottle on the market (just 8.7 g of plastic). The bottles they use in their 
                progetto Ecogreen range are made with 50% regenerated plastic, achieving 100% carbon neutrality.
            </Text>

            <Text style={styles.brandDesc}>
                Beverages produced and sold by San Benedetto are: Water, iced tea, chamomile infusions, flavoured water, fruit-based 
                drinks, sports drinks, aperitifs, tonic waters.
            </Text>
        </View>
        </ScrollView>
        </>
    )
}

export default Dolce;