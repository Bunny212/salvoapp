import 'react-native-gesture-handler';
import React,{useCallback, useState} from 'react';
import {View, StyleSheet, ScrollView,Button,Text,Dimensions,Modal,Pressable,ActivityIndicator,Alert } from 'react-native';
import RangeSlider from 'rn-range-slider';
import Thumb from './Thumb';
import Rail from './Rail'
import RailSelected from './RailSelected'


const PriceRange = () =>{

    const [low, setLow] = useState(0);
    const [high, setHigh] = useState(100);  
    const renderThumb = useCallback(() => <Thumb/>, []);
    const renderRail = useCallback(() => <Rail/>, []);
    const   renderRailSelected = useCallback(() => <RailSelected/>, []);
    const handleValueChange = useCallback((low, high) => {
    setLow(low);
    setHigh(high);
    }, []);

    return(
        <View style={{marginVertical:10}}>
        <RangeSlider
            min={200}
            max={1000}
            step={20}
            renderThumb={renderThumb}
            renderRail={renderRail}
            renderRailSelected={renderRailSelected}
            onValueChanged={handleValueChange}
            style={{width:'100%'}}
        ></RangeSlider>  
        <View style={{flexDirection:'row',justifyContent:'space-between'}}>
            <Text style={{color:'red'}}>{low}</Text>
            <Text style={{color:'red'}}>{high}</Text>
        </View> 
      </View>
    )

}

export default PriceRange;