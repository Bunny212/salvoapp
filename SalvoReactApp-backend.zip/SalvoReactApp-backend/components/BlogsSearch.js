import { gql, useQuery } from "@apollo/client";
import moment from "moment";
import React from "react";
import { useRef } from "react";
import { useState } from "react";
import { View,Text,TouchableOpacity,Image,Dimensions,ScrollView,ActivityIndicator, Touchable, TouchableOpacityBase } from "react-native";
import { DrawerLayout } from "react-native-gesture-handler";
import RenderHTML, { RenderHTMLConfigProvider, TRenderEngineProvider } from "react-native-render-html";
import styles from "../styles/styles";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
import BlogMenu from "./BlogMenu";


const { width, height } = Dimensions.get('window')

const BlogsSearch = ({navigation,route}) => {
    const [sideBar,setSideBar] = useState('none');
    const [color, setColor] = useState({});
    const categories=[];
    const tags=[];
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const drawerRef = useRef(null);
    const handleSideBarVisible = () =>{
        if(sideBar=='none'){
         setSideBar('flex');
        }    
    }
    const openDrawer = () => {
        setIsDrawerOpen(true);
    };
    
    const closeDrawer = () => {
        setIsDrawerOpen(false);
    };
    
    const close=()=>{
        setSideBar('none');
    }
    const getReadTime=(postDate)=>{
        let timePassed = moment(postDate).fromNow();
        return timePassed;
    }
    
    const getAllCategories=()=>{  
        const BLOG_CATEGORIES=gql`
            {
                amBlogCategories {
                items {
                    category_id
                    created_at
                    level
                    meta_description
                    meta_robots
                    meta_tags
                    meta_title
                    name
                    parent_id
                    path
                    post_count
                    sort_order
                    status
                    store_id
                    updated_at
                    url_key
                }
                }
            }
        `;
        const { loading, error, data } = useQuery(BLOG_CATEGORIES);
        if (loading) return <ActivityIndicator></ActivityIndicator>;
        if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
        data.amBlogCategories.items.map((category)=>{
            categories.push({cat_id:category.category_id,label:category.name});
        })
    }
    getAllCategories();
  
       
const getTags=()=>{
    const GET_TAGS=gql`
    {
        amBlogTagsWidget{
          items {
            meta_description
            meta_robots
            meta_tags
            meta_title
            name
            tag_id
            url_key
          }
          title
        }
      }
          `;
      const { loading, error, data } = useQuery(GET_TAGS);
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      console.log(data.amBlogTagsWidget);
      data.amBlogTagsWidget.items.map((tag)=>{
        tags.push({tag_id:tag.tag_id,tag_name:tag.name});
      })
}
getTags();
const getTagCount=(search)=>{
    const GET_TAGS=gql`
    {
        amBlogPostsSearch(query: "${search}") {
          all_post_size
          items {
            author_id
            canonical_url
            categories
            comment_count
            comments_enabled
            created_at
            display_short_content
            full_content
            grid_class
            is_featured
            list_thumbnail
            list_thumbnail_alt
            meta_description
            meta_robots
            meta_tags
            meta_title
            notify_on_enable
            post_id
            post_thumbnail
            post_thumbnail_alt
            published_at
            related_post_ids
            short_content
            status
            tag_ids
            title
            updated_at
            url_key
            user_define_publish
            views
          }
        }
      }
    `;
    const { loading, error, data } = useQuery(GET_TAGS);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return data.amBlogPostsSearch.all_post_size;
}    
const getPosts=(search)=>{
       
    const SEARCH=gql`
    {
        amBlogPostsSearch(query: "${search}") {
          all_post_size
          items {
            author_id
            canonical_url
            categories
            comment_count
            comments_enabled
            created_at
            display_short_content
            full_content
            grid_class
            is_featured
            list_thumbnail
            list_thumbnail_alt
            meta_description
            meta_robots
            meta_tags
            meta_title
            notify_on_enable
            post_id
            post_thumbnail
            post_thumbnail_alt
            published_at
            related_post_ids
            short_content
            status
            tag_ids
            title
            updated_at
            url_key
            user_define_publish
            views
          }
        }
      }
    `;
    const { loading, error, data } = useQuery(SEARCH);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return data;
}

    return(
        <>
                <DrawerLayout
        drawerBackgroundColor="#ffffff"
        ref={drawerRef}
        onDrawerSlide={isDrawerOpen}
        drawerType="front"
        onDrawerOpen={openDrawer}
        onDrawerClose={closeDrawer}
        drawerWidth={300}
        drawerPosition={DrawerLayout.positions.Right}
        renderNavigationView={() =>  <BlogMenu navigation={navigation} onPress={()=>{drawerRef.current.closeDrawer()}}/>}
>
        <ScrollView style={{backgroundColor:'#fff'}}>
           
        <View style={styles.blogHeading}>
            <Text style={[styles.blogHeadingText,{fontSize:height*0.040,width:'90%'}]}>Search results for '{route.params.search}'</Text>
            <TouchableOpacity onPress={()=>{drawerRef.current.openDrawer()}}><Image source={require('../assets/icons/blog-menu.png')}/></TouchableOpacity>
        </View>

        <View style={{padding:height*0.022,flexDirection:'row'}}>
            <TouchableOpacity onPress={()=>{navigation.navigate('BlogsSearch',{search:route.params.search})}} style={{padding:height*0.020,backgroundColor:'#F5F5F5',borderRadius:height*0.050,marginRight:width*0.04}}>
                <Text style={{textAlign:'center',fontSize:height*0.020,color:'#000'}}>Posts ({getPosts(route.params.search)?.amBlogPostsSearch?.all_post_size})</Text>
            </TouchableOpacity>
            {/* <TouchableOpacity style={{padding:height*0.020,backgroundColor:'#F5F5F5',borderRadius:height*0.050,marginRight:width*0.04}}>
                <Text style={{textAlign:'center',fontSize:height*0.020,color:'#000'}}>Authors (4)</Text>
            </TouchableOpacity>
            <TouchableOpacity style={{padding:height*0.020,backgroundColor:'#F5F5F5',borderRadius:height*0.050,marginRight:width*0.04}}>
                <Text style={{textAlign:'center',fontSize:height*0.020,color:'#000'}}>Tags ({getTagCount()})</Text>
            </TouchableOpacity> */}
        </View>

        {/* <View style={{paddingHorizontal:height*0.022,flexDirection:'row'}}>
            <TouchableOpacity style={{padding:height*0.020,backgroundColor:'#F5F5F5',borderRadius:height*0.050,marginRight:width*0.04}}>
                <Text style={{textAlign:'center',fontSize:height*0.020,color:'#000'}}>Categories (4)</Text>
            </TouchableOpacity>
        </View> */}
        {getPosts(route.params.search)?.amBlogPostsSearch?.items.map((post_data)=>{ 
                return(
                    <>
        <View style={styles.blogArticle}>
            <TouchableOpacity onPress={()=>{navigation.navigate('BlogPage',{post_id:post_data.post_id,url_key:post_data.url_key,timePassed:getReadTime(post_data.created_at),
                         views:post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view'})}}>
                <Image style={styles.blogArticleImg} source={{uri:post_data.post_thumbnail,height:height*0.4}}
               />
             </TouchableOpacity>
            <View style={styles.blogDetailsContainer}>
                <View style={{padding:height*0.020}}>
                    <View style={styles.blogPublishDate}>
                        <Text style={styles.blogPublishDateText}>{getReadTime(post_data.created_at)}</Text>
                        <Text style={{color:'#999'}}>{post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view'}</Text>
                    </View>
                    <TouchableOpacity onPress={()=>{navigation.navigate('BlogPage',{post_id:post_data.post_id,url_key:post_data.url_key,timePassed:getReadTime(post_data.created_at),
                         views:post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view'})}}>
                        <Text style={styles.blogArticleTitle}>
                            {post_data.title}
                        </Text>
                    </TouchableOpacity>
                    <View style={{ flexDirection:'row'}}>
                {tags.map((tag)=>{
                    return(
                    post_data.tag_ids.split(',').map((id)=>{
                        if(parseInt(id.replace(' ',''))==parseInt(tag.tag_id)){
                            return(
                            <TouchableOpacity
                        style={{
                            margin:height*0.006,
                            alignSelf: 'flex-start',
                          padding: height*0.012,
                          borderRadius: height*0.02,
                          alignItems: "center",
                          justifyContent: "center",
                        //   backgroundColor: "#F5F5F5",
                          backgroundColor:color.id==tag.tag_id?color.backgroundColor:'#F5F5F5',
                        }}
                        onPressIn={() => {setColor({id:tag.tag_id,text_color:'#fff',backgroundColor:'#000'});}}
                        onPressOut={() => {setColor({id:tag.tag_id,text_color:'#000',backgroundColor:'#F5F5F5'});}}
                        onPress={()=>{  navigation.navigate('BlogsTags',{tag_id:tag.tag_id,tag_name:tag.tag_name});}}
                      >
                        <Text
                           style={{ color:color.id==tag.tag_id?color.text_color:'#000'}}
                        >
                            {tag.tag_name}
                        </Text>
                      </TouchableOpacity>
                            )
                    }
                    })
                    )
                })}
              
              </View>
                    <Text style={styles.blogArticlePara}>
                      {post_data.short_content}
                    </Text>
                    <View style={styles.blogArticlePosted}>
                     
                       
                        {
                         categories.map((category)=>{
            
                            if(category.cat_id==post_data.categories){
                                return (
                                    <>
                                    <Text style={styles.blogArticlePostedIn}>Posted in: </Text>
                                    <TouchableOpacity><Text style={styles.blogArticleCategoty}>{category.label}</Text></TouchableOpacity>
                                    </>
                                )
                            }
                        })
                        }
                    </View>
                    <View style={{marginTop:height*0.020}}>
                        <TouchableOpacity onPress={()=>{navigation.navigate('BlogPage',{post_id:post_data.post_id,url_key:post_data.url_key,
                        timePassed:getReadTime(post_data.created_at),
                        views:post_data.views>1?  post_data.views+' view(s)':post_data.views==0? '':post_data.views+'view',
                        })}} style={styles.readMoreBtn}>
                            <Text style={styles.readMoreBtnText}>Read More</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </View>
        </>
                )
            })}

        
        </ScrollView>
        </DrawerLayout>
        </>
    )
}

export default BlogsSearch;