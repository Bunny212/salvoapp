import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch, useSelector } from "react-redux";
import { gql, useMutation, useQuery } from "@apollo/client";
import { REORDER } from "./mutations/reorderItems";
import { AddtoCart, NumberofItems, setSubTotal, setTotalPrice, TotalQuantity } from "./redux/actions";

const ViewOrder = ({navigation,route}) => {

    const CUSTOMER=useSelector(state=>state.customer);
    const [ReorderItems]=useMutation(REORDER);
    const dispatch=useDispatch();
    const [serverError,setServerErrorMsg] = useState('');
const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const reorderPreviousOrder=async(orderNumber)=>{
        try{   
            const{
              data,errors,
            }= await ReorderItems({
                variables:{
                   orderNumber
                }
            });
           
            dispatch(TotalQuantity(data.reorderItems.cart.total_quantity));
            dispatch(NumberofItems(data.reorderItems.cart.items.length));
            dispatch(AddtoCart(data.reorderItems.cart.items));
            dispatch(setTotalPrice(data.reorderItems.cart.prices.grand_total.value));
            dispatch(setSubTotal(data.reorderItems.cart.prices.subtotal_excluding_tax.value))
            navigation.navigate('CartPage');            
          }catch(error){
                console.log(error);
                setDisplayServerErrorMsg(true);
setServerErrorMsg(error.message);    
          }
    }
    if (displayServerError) {
        setTimeout(() => {
          setDisplayServerErrorMsg(false);
       }, 12000);
    }
    const SHIPPING_ADRESS=gql`{
        customer {
                orders(filter: {number:{eq:"${route.params.order_number}"},
                             
                               })  {      
                    items{
                        number
                        status
                        total{
                            subtotal{
                              value
                            }
                            grand_total{
                              value
                              currency
                            }
                          }      
                        items{
                          
                            product_name
                            product_sku
                            product_sale_price {
                            value
                          }
                            quantity_ordered
                            quantity_canceled
                          }
                        shipping_method
                        shipping_address{
                        firstname
                        lastname
                        street
                        city
                        country_code
                        telephone
                        company
                        postcode
                        region
                      }
                      billing_address{
                        firstname
                        lastname
                        street
                        city
                        country_code
                        telephone
                        company
                        postcode
                        region
                        }
                        payment_methods{
                            name
                          }
                    }
                    
                  }
                
                 }
                country(id:"GB"){
                    full_name_english
                }
                currency{
                    default_display_currency_symbol
                }
              }`;

      const { loading, error, data } = useQuery(SHIPPING_ADRESS);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
   
    // const [itemsOrderedVisible, setItemsOrderedVisible] = useState('none');
    // const [invoicesVisible, setInvoicesVisible] = useState('none');
    // const [shipmentsVisible, setShipmentsVisible] = useState('none');
    // const changeItemsOrderedVisible = () =>{
    //     if(itemsOrderedVisible=='none'){
    //      setItemsOrderedVisible('flex');
    //     }else{
    //      setItemsOrderedVisible('none');
    //     }
    // }
    // const changeInvoicesVisible = () =>{
    //     if(invoicesVisible=='none'){
    //      setInvoicesVisible('flex');
    //     }else{
    //      setInvoicesVisible('none');
    //     }
    // }
    // const changeShipmentsVisible = () =>{
    //     if(shipmentsVisible=='none'){
    //      setShipmentsVisible('flex');
    //     }else{
    //      setShipmentsVisible('none');
    //     }
    // }

    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={[styles.myAccountTitle,{marginBottom:height*0.012}]}>Order # {route.params.order_number}</Text>
            {data?.customer?.orders?.items?.map((item)=>{
                return(
                    <View style={styles.orderStatus}><Text style={styles.orderStatusText}>{item.status}</Text></View>
                )
            })}
           
            <Text style={styles.orderDate}>{route.params.order_date}</Text>

            <View style={styles.orderOptions}>
                <TouchableOpacity onPress={()=>reorderPreviousOrder(route.params.order_number)}><Text style={styles.orderDetail}>Reorder</Text></TouchableOpacity>
                <Text style={styles.otherOptions}>   |   </Text>
                <TouchableOpacity onPress={()=>navigation.navigate('CartPage')}><Text style={styles.orderDetail}>Add to this Order</Text></TouchableOpacity>
            </View>
            {displayServerError==true?<View style={{paddingHorizontal:height*0.022,backgroundColor:'#fae5e5',justifyContent:'center'}}>
	<Text style={styles.serverError}>{serverError}</Text>  
</View>:<View></View>}
            <Text style={[styles.myAccountGreeting,{marginTop:height*0.022}]}>Hello {CUSTOMER.customer.email}</Text>
        </View>

        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={[styles.myAccountMenuText,{fontWeight:'700'}]}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>

        <View style={{padding:height*0.022}}>
            {/* <View style={styles.orderDetailsOptions}><TouchableOpacity onPress={changeItemsOrderedVisible}><Text>Items Ordered</Text></TouchableOpacity></View> */}
            {/* <View style={styles.orderDetailsOptions}><TouchableOpacity onPress={changeInvoicesVisible}><Text>Invoices</Text></TouchableOpacity></View>
            <View style={styles.orderDetailsOptions}><TouchableOpacity onPress={changeShipmentsVisible}><Text>Order Shipments</Text></TouchableOpacity></View> */}
            {/* <View style={[styles.orderDetailsContainer,{display:itemsOrderedVisible}]}> */}
            <View style={styles.orderDetailsContainer}>
                <Text style={styles.otherOptions}>Items Ordered</Text>
                <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                <Text style={styles.ordersText}>Choose Dates Below</Text>
                <Text style={styles.ordersText}>Choose Dates Below: {route.params.order_date}</Text>
                {data.customer.orders?.items.map((item)=>{
                return(
                    <>
                    {item?.items.map((product)=>{
                    console.log('---------------------',product.product_name)
                        return(
                            <>
                            <View>
                                <View style={{flexDirection:'column'}}>
                                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Product Name:</Text>
                                    <Text style={styles.ordersText}>{product.product_name}</Text>
                                </View>
                                <View style={{flexDirection:'row'}}>
                                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>SKU:</Text>
                                    <Text style={styles.ordersText}>  {product.product_sku}</Text>
                                </View>
                                <View style={{flexDirection:'row'}}>
                                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Price:</Text>
                                    <Text style={styles.ordersText}>  {data.currency.default_display_currency_symbol}{product.product_sale_price.value}/each</Text>
                                </View>
                                <View style={{flexDirection:'row'}}>
                                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Qty:</Text>
                                    <View>
                                        <Text style={styles.ordersText}>  Ordered: {product.quantity_ordered}</Text>
                                        {/* <Text style={[styles.ordersText,{marginTop:height*0}]}>  Canceled: {product.quantity_canceled}</Text> */}
                                    </View>
                                </View>
                                <View style={{flexDirection:'row'}}>
                                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Subtotal:</Text>
                                    <Text style={styles.ordersText}>  {data.currency.default_display_currency_symbol}Price</Text>
                                </View>
                                <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                            </View>
                            </>
            
                        )
                })}
                    </>
                )
            })}

                <View style={styles.orderPriceDetail}>
                    <View style={styles.orderPriceTotal}>
                       <Text style={styles.ordersText}>Subtotal</Text>
                       <Text style={styles.ordersText}>{data.currency.default_display_currency_symbol}Price</Text>
                    </View>
                    <View style={styles.orderPriceTotal}>
                       <Text style={styles.ordersText}>Shipping & Handling</Text>
                       <Text style={styles.ordersText}>{data.currency.default_display_currency_symbol}Price</Text>
                    </View>
                    <View style={styles.orderPriceTotal}>
                       <Text style={[styles.ordersText,{fontWeight:'500'}]}>Grand Total</Text>
                       <Text style={[styles.ordersText,{fontWeight:'500'}]}>{data.currency.default_display_currency_symbol}{route.params.order_price}</Text>
                    </View>
                </View>
            </View>

            {/* <View style={[styles.orderDetailsContainer,{display:invoicesVisible}]}>
            <Text style={styles.ordersText}>Choose Dates Below</Text>
                <Text style={styles.ordersText}>Choose Dates Below: dd Mon YYYY</Text>
                <TouchableOpacity><Text style={styles.ordersText}>Print All Invoices</Text></TouchableOpacity>
                <Text style={styles.ordersText}>Invoice #000000000</Text>
                <TouchableOpacity><Text style={[styles.ordersText,{marginTop:height*0.020}]}>Print Invoice</Text></TouchableOpacity>
                <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                <View>
                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Product Name:</Text>
                    <Text style={styles.ordersText}>Name</Text>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>SKU:</Text>
                        <Text style={styles.ordersText}>  sku</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Price:</Text>
                        <Text style={styles.ordersText}>  price/case</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Qty Invoiced:</Text>
                        <Text style={styles.ordersText}>  5</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Subtotal:</Text>
                        <Text style={styles.ordersText}>  £Price</Text>
                    </View>
                    <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                </View>

                <View>
                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Product Name:</Text>
                    <Text style={styles.ordersText}>Name</Text>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>SKU:</Text>
                        <Text style={styles.ordersText}>  sku</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Price:</Text>
                        <Text style={styles.ordersText}>  price/case</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Qty Invoiced:</Text>
                        <Text style={styles.ordersText}>  5</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Subtotal:</Text>
                        <Text style={styles.ordersText}>  £Price</Text>
                    </View>
                </View>
                <View style={styles.orderPriceDetail}>
                    <View style={styles.orderPriceTotal}>
                       <Text style={styles.ordersText}>Subtotal</Text>
                       <Text style={styles.ordersText}>£Price</Text>
                    </View>
                    <View style={styles.orderPriceTotal}>
                       <Text style={styles.ordersText}>Shipping & Handling</Text>
                       <Text style={styles.ordersText}>£Price</Text>
                    </View>
                    <View style={styles.orderPriceTotal}>
                       <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Grand Total</Text>
                       <Text style={[styles.ordersText,{fontWeight:'bold'}]}>£Price</Text>
                    </View>
                </View>
            </View>
            <View style={[styles.orderDetailsContainer,{display:shipmentsVisible}]}>
            <Text style={styles.ordersText}>Choose Dates Below</Text>
                <Text style={styles.ordersText}>Choose Dates Below: dd Mon YYYY</Text>
                <TouchableOpacity><Text style={styles.ordersText}>Print All Shipments</Text></TouchableOpacity>
                <Text style={styles.ordersText}>Shipment #000000000</Text>
                <View style={{flexDirection:'row',justifyContent:'space-between'}}>
                    <TouchableOpacity><Text style={[styles.ordersText,{marginTop:height*0.020}]}>Print Shipment</Text></TouchableOpacity>
                    <TouchableOpacity><Text style={[styles.ordersText,{marginTop:height*0.020}]}>Track this Shipment</Text></TouchableOpacity>
                </View>
                <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                <View>
                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Product Name:</Text>
                    <Text style={styles.ordersText}>Name</Text>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>SKU:</Text>
                        <Text style={styles.ordersText}>  sku</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Qty Shipped:</Text>
                        <Text style={styles.ordersText}>  5</Text>
                    </View>
                    <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
                </View>

                <View>
                    <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Product Name:</Text>
                    <Text style={styles.ordersText}>Name</Text>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>SKU:</Text>
                        <Text style={styles.ordersText}>  sku</Text>
                    </View>
                    <View style={{flexDirection:'row'}}>
                        <Text style={[styles.ordersText,{fontWeight:'bold'}]}>Qty Shipped:</Text>
                        <Text style={styles.ordersText}>  5</Text>
                    </View>
                </View>
            </View> */}
        </View>

        <View style={[styles.orderSummary,{paddingTop:height*0.022,paddingBottom:height*0}]}>
            <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Order Information</Text>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Shipping Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.firstname} {data.customer.orders.items[0].shipping_address.lastname}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.company}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.street}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_address.city}, {data.customer.orders.items[0].shipping_address.region}, {data.customer.orders.items[0].shipping_address.postcode}</Text>
                <Text style={styles.otherOptions}>{data.country.full_name_english}</Text>
                <Text style={styles.otherOptions}>T: {data.customer.orders.items[0].shipping_address.telephone}</Text>
            </View>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Shipping Method</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].shipping_method}</Text>
            </View>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Billing Address</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.firstname} {data.customer.orders.items[0].billing_address.lastname}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.company}</Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.street} </Text>
                <Text style={styles.otherOptions}>{data.customer.orders.items[0].billing_address.city}, {data.customer.orders.items[0].billing_address.region}, {data.customer.orders.items[0].billing_address.postcode}</Text>
                <Text style={styles.otherOptions}>{data.country.full_name_english}</Text>
                <Text style={styles.otherOptions}>T: {data.customer.orders.items[0].billing_address.telephone}</Text>
            </View>
        </View>

        <View style={{padding:height*0.022}}>
            <Text style={styles.headingTitle}>Payment Method</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
            <View style={{marginTop:height*0.014}}>
                <Text style={styles.otherOptions}>Credit Card</Text>
            </View>
            <View style={styles.creditCardContainer}>
                <View style={styles.creditCard}>
                    <Text style={[styles.detailsText,{fontWeight:'700'}]}>cc_type</Text>
                    <Text style={[styles.detailsText,{marginLeft:width*0.20}]}>{data.customer.orders.items[0].payment_methods[0].name}</Text>
                </View>
                <View style={styles.creditCard}>
                    <Text style={[styles.detailsText,{fontWeight:'700'}]}>cc_number</Text>
                    <Text style={[styles.detailsText,{marginLeft:width*0.16}]}>xxxx-1111</Text>
                </View>
            </View>
        </View>

        </ScrollView>
        </>
    )
}

export default ViewOrder;