import { gql, useMutation, useQuery } from "@apollo/client";
import React, { useState } from "react";
import { View,Text, TouchableOpacity, ActivityIndicator } from "react-native";
import { useDispatch } from "react-redux";
import { SIGN_OUT } from "./mutations/signOut";
import { AddtoCart, CartIdSet, customerToken, NumberofItems, setShippingValue, setSubTotal, setTotalPrice, TotalQuantity } from "./redux/actions";

const DropDown=({display,navigation,action})=>{
    const dropdown=['My Account','My Shopping Lists','Reward Points','Sign Out'];
    const dispatch=useDispatch();
    const clickAction=(selected)=>{
       if(selected==0){
        action();
        navigation.navigate("MyAccount");
       }else if(selected==1){
        action();
        navigation.navigate("SavedLists");
       }else if(selected==2){
        action();
        navigation.navigate('MyRewards');
       }else if(selected==3){
        SignOut();
       }
    }
    const [signOut]=useMutation(SIGN_OUT);
        const SignOut=async()=>{
           try{
               const{
                 data,errors,
               }=await signOut();
               if(data.revokeCustomerToken.result==true){
                    dispatch(customerToken(null));
                    action();
                    dispatch(TotalQuantity(0));
                    dispatch(NumberofItems(0));
                    dispatch(AddtoCart());
                    dispatch(setTotalPrice());
                    dispatch(setSubTotal());
                    dispatch(setShippingValue());
                    dispatch(CartIdSet())
                    navigation.navigate('SignOut');
               }
             }catch(error){
               console.log(error);
             }
        }
    const GET_REWARD_POINTS=gql`
    {
      rewards {
        balance
      }
    }
    `;
    const { loading, error, data } = useQuery(GET_REWARD_POINTS);
    return(
        <View style={{left:'47%',top:'100%',position:'absolute',width:'43%',display:display}}>
            <View style={{borderWidth:1,backgroundColor:'#ffffff',borderColor:'#999DA3'}}>
           {dropdown.map((item,index)=>{
            return(
                <TouchableOpacity onPress={()=>{clickAction(index)}} style={{padding:'7%'}}>
                    <View style={{flexDirection:'row'}}>
                    <Text>
                        {item}
                    </Text>
                    {index==2? <Text style={{backgroundColor:'yellow',width:'12%',marginLeft:'2%',textAlign:'center'}}>{data?.rewards?.balance}</Text>:<></>}
                    </View>
                </TouchableOpacity>
            )
           })}
           </View>
        </View>
    )
}

export default DropDown;