import { gql, useMutation, useQuery } from "@apollo/client";
import React, { useState, useRef } from "react";
import { View, Text, TouchableOpacity, Dimensions,TextInput, BackHandler, ActivityIndicator, Keyboard, Platform, useWindowDimensions} from "react-native";
import styles from "../styles/styles";
import stylesIpad from "../styles/stylesIpad";
import CheckBox from '@react-native-community/checkbox';
import { LOGIN_CUSTOMER } from "./mutations/loginCustomer";
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch } from "react-redux";
import { customerToken } from "./redux/actions";
import { useEffect } from "react";
import KeyboardAvoidingView from "react-native/Libraries/Components/Keyboard/KeyboardAvoidingView";
const { width, height } = Dimensions.get('window');
const Login = ({navigation,route}) => {
    const heightPad = useWindowDimensions().height;
    const widthPad = useWindowDimensions().width;
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [emailMessage,setEmailMessage]=useState("");
    const [passwordMessage,setPasswordMessage]=useState("");
    const [showPassword,setShowPassword]=useState(true);
    const [toggleCheckBox,setToggleCheckBox]=useState(false);
    const [error, setError] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const [loading,setLoading]=useState(false);
    const dispatch=useDispatch();
    const [isKeyboardVisibleHeight, setKeyboardVisibleHeight] = useState('100%');
    const scrollViewRef = useRef(null);

    const validate=()=>{
        if(email.length!=0 && password.length==0){
            setEmailMessage("");
            setPasswordMessage("This is a required field.");
        }else if(password.length!=0 && email.length==0){
            setPasswordMessage("");
            setEmailMessage("This is a required field.");
        }else if(email.length!=0 && password.length!=0){
            setEmailMessage("");
            setPasswordMessage("");
            loginCustomer(email,password);         //email validation yet to be added
            // loginCustomer("Arslan.yousaf@sotechnology.co.uk","admin@123");
            // loginCustomer('ahmed.riaz2@sotechnology.co.uk','pudfN$ZUvgH57LSj')
                 
        }else{
            setEmailMessage("This is a required field.");
            setPasswordMessage("This is a required field.");
            setError(true);
        }
    }
    const [generateCustomerToken]=useMutation(LOGIN_CUSTOMER);
    const loginCustomer = async(email,password)=>{
        setLoading(true);
        try{   
            const{
              data,errors,
            }= await generateCustomerToken({
                variables:{
                    email,
                    password
                }
            });
           
            if(data!=undefined){
            setLoading(false);
            dispatch(customerToken(data?.generateCustomerToken?.token));
            navigation.navigate("Default");
            }
            
           
            
          }catch(error){
            setDisplayServerErrorMsg(true);
            setErrorMessage(error.message);    
            setTimeout(() => {
                setDisplayServerErrorMsg(false);
                setErrorMessage(null);
            }, 12000);
            setLoading(false);
          }
    }

    function handleBackButtonClick() {
        navigation.navigate('Default');
        return true;
      }
      useEffect(() => {
        BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
        return () => {
          BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
        };
      }, []);
      const keyboardDidShowListener=Keyboard.addListener(
        'keyboardDidShow',
        () => {
          setKeyboardVisibleHeight('60%'); // or some other action
        }
      );
      const keyboardDidHideListener =Keyboard.addListener(
        'keyboardDidHide',
        () => {
          setKeyboardVisibleHeight('100%'); // or some other action
        }
      );
    keyboardDidHideListener;
    keyboardDidShowListener; 
    
    if(Platform.isPad){
        return(

            <View style={{height:'100%',width:'100%',flexDirection:'row'}}>
                 
                <View style={{width:'55%',alignItems:'center',justifyContent:'center'}}>
                {displayServerError?<View style={{paddingHorizontal:heightPad*0.020,backgroundColor:'#fae5e5',justifyContent:'center',height:'12%'}}>
                        <Text style={[stylesIpad.serverError,{fontSize:heightPad*0.016}]}>{errorMessage}</Text>
        </View>:null}
                    <View style={{padding:'2%',borderBottomWidth:0.5,width:'92.5%'}}>
                        <Text style={[stylesIpad.titleText,{fontSize:heightPad*0.028}]}>Customer Login</Text>
                        <Text style={[stylesIpad.titleText,{fontSize:heightPad*0.018, fontWeight:'400',marginTop:'10%'}]}>Registered Customers</Text>
                    </View>
                    <View style={{marginTop:'5%',padding:'2%',width:'95%'}}>
                        <Text style={[stylesIpad.titleText,{fontSize:heightPad*0.014,fontWeight:'400'}]}>If you have an account, sign in with your email address.</Text>
                        <View style={{marginTop:'10%'}}>
                            <View style={{flexDirection:'row'}}>
                                <Text style={[stylesIpad.textInputLable,{fontSize:heightPad*0.014}]}>Email</Text>
                                <Text style={{color:'#e02b27',fontSize:heightPad*0.014}}> *</Text>
                            </View>
                            <TextInput style={[stylesIpad.textInput,{borderColor: error? '#ed8380': '#999DA3',
                        height: '13%',
                        borderWidth: 0.5,
                        padding: '2%',
                        marginTop:'3%',
                        fontSize:height*0.020,    
                        }]} 
                            onChangeText={newEmail=>setEmail(newEmail)}/>
                            <View>
                            <Text style={{color:'#e02b27',marginTop:'5%',fontSize:height*0.018}}>{emailMessage}</Text></View>
                            <View style={{flexDirection:'row'}}>
                                <Text style={[stylesIpad.textInputLable,{fontSize:heightPad*0.014}]}>Password</Text>
                                <Text style={{color:'#e02b27',fontSize:heightPad*0.014}}> *</Text>
                            </View>
                            <TextInput style={[stylesIpad.textInput,{borderColor: error? '#ed8380': '#999DA3',
                        height: '13%',
                        borderWidth: 0.5,
                        padding: '2%',
                        marginTop:'3%',
                        fontSize:height*0.020,    
                        }]} 
            onChangeText={newPassword=>setPassword(newPassword)} secureTextEntry={showPassword ? true : false}/> 
             <View><Text style={{color:'#e02b27',marginTop:'5%',fontSize:height*0.018}}>{passwordMessage}</Text></View>
             <View style={{flexDirection:'row',alignItems:'center'}}>
                <TouchableOpacity style={{flexDirection:'row',alignItems:'center'}} onPress={() => {setToggleCheckBox(!toggleCheckBox); setShowPassword(!showPassword);}}>
                    <CheckBox tintColors={'#9E663C'} boxType="square" style={stylesIpad.checkbox} value={toggleCheckBox}></CheckBox>
                    <Text style={[stylesIpad.showPassword,{marginLeft:'5%',
                    fontSize:height*0.014}]}>Show Password</Text>
                </TouchableOpacity>
            </View>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                <TouchableOpacity disabled={loading?true:false} style={[stylesIpad.createAnAccount,{marginTop:'5%',width:'25%',padding:'4%',borderRadius:heightPad*0.005}]} onPress={()=>validate()}>
            {loading?<ActivityIndicator size={height*0.0265} hidesWhenStopped={true} animating={loading}></ActivityIndicator>:<Text style={[stylesIpad.addToBasketText,{fontSize:heightPad*0.014}]}>
                Sign In
            </Text>}
            
            
        </TouchableOpacity>
        <TouchableOpacity style={{marginLeft:'4%'}} onPress={()=>{navigation.navigate('ForgotPassword')}}>
            <Text style={[stylesIpad.forgotPassword,{fontSize:heightPad*0.014}]}>Forgot Your Password?</Text>
        </TouchableOpacity>
                </View>
                <Text style={[stylesIpad.requiredFields,{fontSize:height*0.014}]}>* Required Fields</Text>
                        </View>          
                    </View>
                </View>
                <View style={{width:'45%',padding:'2%',justifyContent:'center'}}>
                <View style={{padding:'2%',borderBottomWidth:0.5,width:'92.5%'}}>
                <Text style={[stylesIpad.titleText,{fontSize:heightPad*0.018, fontWeight:'400'}]}>
                    New Customers
                </Text>
                
                </View>
                <Text style={[stylesIpad.titlePara,{marginTop:'10%',
    fontSize:height*0.014,}]}>
                Creating an account has many benefits: check out faster, 
                keep more than one address, track orders and more.
            </Text>
                <TouchableOpacity onPress={()=>{navigation.navigate("TradeAccount")}} style={[stylesIpad.createAnAccount,{marginTop:'10%',padding:'4%',width:'50%',borderRadius:height*0.004}]}>
                    <Text style={[stylesIpad.addToBasketText,{fontSize:height*0.014,}]}>
                        Create an Account
                    </Text>
                </TouchableOpacity>
                </View>
            </View>
        )
    }else{
    return(
        
        <View style={{height:Platform.OS==='ios'?isKeyboardVisibleHeight:'100%'}}>
    <ScrollView ref={scrollViewRef} style={{backgroundColor:'#fff'}}>
    <View style={[styles.loginContainer]}>
        <Text style={styles.titleText}>Customer Login</Text>

        {displayServerError?<View style={{paddingHorizontal:height*0.020,backgroundColor:'#fae5e5',justifyContent:'center'}}>
            <Text style={[styles.serverError,{fontSize:height*0.016}]}>{errorMessage}</Text>
        </View>:null}

        <Text style={styles.SecondtitleText}>Registered Customers</Text>
        <View style={[styles.prodSaperator, {marginTop:height*0.014}]}></View>
        <Text style={styles.titlePara}>If you have an account, sign in with your email adress.</Text>
        <View style={{marginTop:height*0.034}}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Email</Text>
                <Text style={{color:'#e02b27'}}> *</Text>
            </View>
            <TextInput style={[styles.textInput,{borderColor: error? '#ed8380': '#999DA3'}]} 
            onChangeText={newEmail=>setEmail(newEmail)}/>
            <View><Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{emailMessage}</Text></View>
        </View>
        <View style={{marginTop:height*0.010}}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.textInputLable}>Password</Text>
                <Text style={{color:'#e02b27'}}> *</Text>
            </View>
            <TextInput style={[styles.textInput,{borderColor: error? '#ed8380': '#999DA3'}]}
            onChangeText={newPassword=>setPassword(newPassword)} secureTextEntry={showPassword ? true : false}/> 
             <View><Text style={{color:'#e02b27',marginTop:height*0.010,fontSize:height*0.018}}>{passwordMessage}</Text></View>
        </View>
        <View style={{flexDirection:'row',marginTop:height*0.010}}>
            <TouchableOpacity style={{flexDirection:'row',alignContent:'center'}} onPress={() => {setToggleCheckBox(!toggleCheckBox); setShowPassword(!showPassword);}}>
                <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleCheckBox}></CheckBox>
                <Text style={styles.showPassword}>Show Password</Text>
            </TouchableOpacity>
        </View>

        <View style={{}}>
        <TouchableOpacity disabled={loading?true:false} style={[styles.createAnAccount,{marginTop:height*0.020}]} onPress={()=>validate()}>
            {loading?<ActivityIndicator size={height*0.0265} hidesWhenStopped={true} animating={loading}></ActivityIndicator>:<Text style={styles.addToBasketText}>
                Sign In
            </Text>}
            
            
        </TouchableOpacity>
        </View>

        <View style={{marginTop:height*0.020}}>
        <TouchableOpacity onPress={()=>{navigation.navigate('ForgotPassword')}}>
            <Text style={styles.forgotPassword}>Forgot Your Password?</Text>
        </TouchableOpacity>
        <Text style={styles.requiredFields}>* Required Fields</Text>
        </View>
        <View style={{marginTop:height*0.024}}>
            <Text style={styles.titleText}>
                New Customers
            </Text>
            <View style={[styles.prodSaperator, {marginTop:height*0.014}]}></View>
            <Text style={styles.titlePara}>
                Creating an account has many benefits: check out faster, 
                keep more than one address, track orders and more.
            </Text>
                <TouchableOpacity onPress={()=>{navigation.navigate("TradeAccount")}} style={[styles.createAnAccount,{marginTop:height*0.020}]}>
                    <Text style={styles.addToBasketText}>
                        Create an Account
                    </Text>
                </TouchableOpacity>
        </View>
    </View>
    </ScrollView>
    </View>
    )
    }
}

export default Login;