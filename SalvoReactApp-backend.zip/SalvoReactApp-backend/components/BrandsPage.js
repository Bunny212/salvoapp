import React from "react";
import { View, Text,Dimensions,Image,TouchableOpacity, ScrollView, useWindowDimensions, ActivityIndicator } from "react-native";
import styles from "../styles/styles";
import { RenderHTML, RenderHTMLConfigProvider,TRenderEngineProvider} from 'react-native-render-html';
import { gql, useQuery } from "@apollo/client";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
import { concatAST } from "graphql";
import { FlatGrid } from "react-native-super-grid";
import { FlatList } from "react-native-gesture-handler";
import { Row, Table } from "react-native-table-component";
import { index } from "cheerio/lib/api/traversing";
const { width, height } = Dimensions.get('window');

const Brands = ({navigation}) => {
    const cheerio = require('cheerio');
    const dataArray=[];
    const imageArray=[];
    const subClassArray=[];
    const shopByBrand=(url)=>{
        const match = url.match(/\d+/);
        const number = match ? match[0] : null;
        if(number!=null){
            console.log('Go to listing page',number)
        }else{
            navigation.navigate('Brand',{url:url})
            console.log(url);
        }
        
    }
    const GET_BRANDS = gql`
    {
        cmsPage(identifier: "brands") {
          identifier
          url_key
          title
          content
        }
      }
      `;
      
      const { loading, error, data } = useQuery(GET_BRANDS);
      const {width}=useWindowDimensions();
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      
    //   const html={
    //     html:data.cmsPage.content       
    //   }
    //   const renderers = {
    //     div: ({TDefaultRenderer, tnode, ...props}) => {
    //       const a = tnode.domNode.attribs;
    //       return (<TDefaultRenderer tnode={tnode} {...props} >
    //       </TDefaultRenderer>);
    //     },
    //   };
    const $=cheerio.load(data.cmsPage.content)
    const elements1=$('.label-brand');
    const elements2=$('.brand-des');
    const elements3 = $('.logo-brand a img.pagebuilder-mobile-only');
    const elements4= $('.mobileapp-background-img .pagebuilder-mobile-only');
    const elements6= $('.pagebuilder-button-primary');
    console.log('Ref::::::::::',$(elements6).attr('href'));
    elements1.each((indexMain, element) => {
        // console.log($(element).text().toLowerCase().split(" ")[0]);
        // console.log('Ref::::::::::',$(elements6[index]).attr('href'));
        const elements5=$('.'+$(element).text().toLowerCase().split(" ")[0]+'-sub-brand');
       

            elements5.each((indexes,elements)=>{
                    if($(element).text().toLowerCase().split(" ")[0]+'-sub-brand'==elements.attribs.class){
                        const elements6 = $('.'+$(element).text().toLowerCase().split(" ")[0]+'-sub-brand .pagebuilder-mobile-only');
                        // console.log(':::::::::::::::::::::',$(element).text().toLowerCase().split(" ")[0]);
                        // console.log(':::::::::::::::::::::',$(elements6[indexes]).attr('src'));
                        imageArray.push({brand:$(element).text().toLowerCase(),image:$(elements6[indexes]).attr('src')});
                    }
                   
              
              })
         
              dataArray.push({label:$(element).text(),description:$(elements2[indexMain]).text(),image:$(elements3[indexMain]).attr('src'),bg_image:$(elements4[indexMain]).attr('src'),sub_class:imageArray,url:$(elements6[indexMain]).attr('href')});            // subClassArray.push(elements5);
    });
 
        return(
            <ScrollView>
            <View style={{alignItems:'center'}}>
            <Text style={{fontSize:25,textAlign:'center',fontWeight:'600'}}>{cheerio.load(data.cmsPage.content)('.page-title').text()}</Text>
            <Text style={{fontWeight:'500',fontSize:18,padding:height*0.01,textAlign:'justify'}}>
            {cheerio.load(data.cmsPage.content)('.all-brands-page-content').text()}
            </Text>
               {dataArray.map((item,index1)=>{
                return(
                    <View style={{alignItems:'center',marginTop:height*0.010}}>
                        <View style={{}}>
                            <Image style={{resizeMode:'stretch'}} source={{uri:item.bg_image,height:height*0.65,width:width*0.95}}></Image>
                            <View style={{width:'60%',height:'80%',position:'absolute',marginLeft:12,marginTop:height*0.015,backgroundColor:'#fff',alignItems:'center',padding:height*0.02}}>
                            <Image style={{resizeMode:'contain'}} source={{uri:item.image,height:height*0.15,width:width*0.5}}></Image>
                            <View style={{marginTop:height*0.02}}>
                            <Text style={{textAlign:'center',fontWeight:'600',width:width*0.50,height:height*0.14}}>
                                {item.description}                              
                            </Text>
                            <Text style={{textAlign:'center',fontSize:height*0.022,fontWeight:'600',marginTop:height*0.02}}>
                                {item.label}                                
                            </Text>
                            <TouchableOpacity style={styles.shopByBrand} onPress={()=>{shopByBrand(item.url,elements6,index)}}>
          
          <Text style={{ fontSize:height*0.02,
    color:'#fff'}}>Shop By Brand</Text>
        </TouchableOpacity>
                            </View>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                                <View style={{flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent:'center',
    padding:height*0.010,
    backgroundColor: "#fff",}}>
                                   {item.sub_class.map((items,index)=>{
                                        for(let i=0;i<=dataArray.length;i++){
                                        if(index1==i && item.sub_class[index].brand.split(" ")[0]==item.label.toLowerCase().split(" ")[0]){
                                            return(
                                                    <Image style={{ width: '48%',
                                                    height:height*0.2,
                                                    backgroundColor: '#ccc',
                                                    marginBottom: 10,}} source={{uri:items?.image,height:height*0.05,width:width*0.05}}></Image>
                                             
                                               
                                            )
                                        }
                                    }
                                   })}
                                 
                                 </View>  

                                  
                          {/* <View style={{height:600}}>
                                <FlatGrid style={{borderWidth:1,flex:1}} data={item.sub_class} renderItem={(items,index)=>{
                                    console.log(items.item.brand);
                                     for(let i=0;i<=dataArray.length;i++){
                                        if(index1==i && items.item.brand.split(" ")[0]==item.label.toLowerCase().split(" ")[0]){
                                            return(
                                                
                                                <Image  source={{uri:items.item.image,height:height*0.2,width:width*0.45}}></Image>
                                            
                                            )
                                        }
                                    }
                                    
                                }}>

                                </FlatGrid>
                                </View>
                               */}
                        </View>
                        </View>
                    )
               })}
            </View>
            </ScrollView>
        // <TRenderEngineProvider>
        //     <RenderHTMLConfigProvider>
        //       <ScrollView style={{padding:height*0.020,marginBottom:height*0.030,backgroundColor:'#fff'}}>
        //         <RenderHTML 
        //             classesStyles={stylesClass} 
        //             tagsStyles={stylesTags} 
        //             contentWidth={width} 
        //             source={html}>
        //         </RenderHTML>
        //       </ScrollView>
        //     </RenderHTMLConfigProvider>
        // </TRenderEngineProvider> 
    )
}

export default Brands;

        {/* <View style={styles.ourBrands}>
            <Text style={styles.ourBrandsText}>Our Brands</Text>
        </View>
        <View style={styles.ourBrandsDesc}>
            <Text style={styles.ourBrandsDescText}>Salvo1968 is for B2B trade only. If you are a 
                restaurant, catering company, retailer, delicatessen or other food-related business with a company Registration number 
                please proceed with the form below.</Text>
        </View>

        <View style={styles.brandsContainer}>
            <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Callipo')} style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/callipo.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>Callipo</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Castelli')}  style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/castelli.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>Castelli</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>
        </View>

        <View style={styles.brandsContainer}>
        <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Colussi')} style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/colussi.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>Colussi</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Dolce')} style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/dolce.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>Dolce Tuscia</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>
        </View>

        <View style={styles.brandsContainer}>
            <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Rovagnati')} style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/rovagnati.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>Rovagnati</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Rummo')} style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/rummo.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>Rummo</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>
        </View>

        <View style={styles.brandsContainer}>
            <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Banedetto')} style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/benedetto.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>San Benedetto</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.brandBox}>
                <TouchableOpacity onPress={()=>navigation.navigate('Sapori')} style={styles.brandImgContainer}>
                    <Image source={require('../assets/brands/sapori.png')}
                    style={styles.brandLogoImg}/>
                    <View style={styles.brandName}>
                        <Text style={styles.brandNameText}>Sapori</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity  onPress={()=>navigation.navigate('ShopBrand')} style={styles.shopBrandBtn}>
                    <Text style={{color:'#fff'}}>Shop this Brand</Text>
                </TouchableOpacity>
            </View>
        </View> */}
