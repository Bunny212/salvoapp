import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, Modal} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useSelector } from "react-redux";

const ShareList = ({navigation}) => {
    const CUSTOMER=useSelector(state=>state.customer);

    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
        <Text style={styles.myAccountTitle}>List Sharing</Text>
        <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>

        <View style={{padding:height*0.022,marginTop:height*0.020}}>
            <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Sharing Information</Text>
            <View style={[styles.myAccountSaperatorLine,{marginTop:height*0.014}]}></View>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.inputText}>Email addresses, saperated by commas</Text>
                <Text style={{color:'red'}}>  *</Text>
            </View>
            <TextInput multiline={true} numberOfLines={5}
            style={styles.inputTextField}/>
        </View>

        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.inputText}>Message</Text>
            </View>
            <TextInput multiline={true} numberOfLines={5}
            style={styles.inputTextField}/>
            </View>

        <View style={{padding:height*0.022}}>
            <TouchableOpacity onPress={()=>navigation.navigate('NewAddress')} style={styles.saveBtn}>
            <Text style={styles.saveBtnText}>
                    Share List
                </Text>
            </TouchableOpacity>
        </View>

        </ScrollView>
        </>
    )
}

export default ShareList;