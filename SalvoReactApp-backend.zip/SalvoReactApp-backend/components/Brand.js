import { gql, useQuery } from "@apollo/client";

import React from "react";
import { View, Text,Dimensions,Image,TouchableOpacity, ScrollView,ActivityIndicator,StyleSheet } from "react-native";
import styles from "../styles/styles";
import RenderHTML, { RenderHTMLConfigProvider, TRenderEngineProvider } from "react-native-render-html";

const { width, height } = Dimensions.get('window');


import Header from "./Header";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
const Brand = ({route}) => {
const cheerio = require('cheerio');

    console.log('Check:::::::',route.params.url.startsWith('/'));
    console.log(':::::::',route.params.url[0]);

    const BRAND_PAGE=gql`
    {
        cmsPage(identifier:"${route.params.url.startsWith('/')==true ?route.params.url.replace('/',''):route.params.url}") {
          identifier
          url_key
          title
          content
        }
      }
    `;
      
    const { loading, error, data } = useQuery(BRAND_PAGE);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    const $=cheerio.load(data.cmsPage.content)
    const elements6= $('.pagebuilder-mobile-only');
    const elements7= $('h3').length;
    const elements8= $('h3');
    const elements9= $('p').length;
    const elements10= $('.brand-page');
    console.log('Ref::::::::::',$(elements10).html());
    const html={
        html:$(elements10).html()
    }
    return(
        <>
        <ScrollView>
        {/* <Text style={[styles.brandDescBold,{textAlign:'justify',paddingHorizontal:10}]}>
                {$(elements10).text()}
            </Text> */}
       
            <TRenderEngineProvider>
            <RenderHTMLConfigProvider>
              <ScrollView style={{padding:height*0.020,marginBottom:height*0.030,backgroundColor:'#fff'}}>
                <RenderHTML 
                    classesStyles={stylesClass} 
                    tagsStyles={stylesTags} 
                    source={html}>
                </RenderHTML>
              </ScrollView>
            </RenderHTMLConfigProvider>
        </TRenderEngineProvider> 

        </ScrollView>
        </>
    )
}
const styles1 = StyleSheet.create({
    heading: {
      fontSize: 24,
      fontWeight: 'bold',
    },
  });
export default Brand;