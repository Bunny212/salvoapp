import { View,Image, Text, TouchableOpacity,TextInput,Dimensions, ActivityIndicator} from "react-native";
import styles from "../styles/styles";
const { width, height } = Dimensions.get('window');
import React , { useState } from "react";
import { Collapse,CollapseHeader, CollapseBody} from "accordion-collapse-react-native";
import { ScrollView } from "react-native-gesture-handler";
import { useSelector } from "react-redux";
import { gql, useQuery } from "@apollo/client";

const MyRewards = ({navigation}) => {
    const CUSTOMER=useSelector(state=>state.customer);
    const GET_REWARD_POINTS=gql`
    {
      rewards {
        balance
      }
    }
    `;
    const { loading, error, data } = useQuery(GET_REWARD_POINTS);
    if (loading) return <ActivityIndicator></ActivityIndicator>;
    if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    return(
        <>
        <ScrollView style={{backgroundColor:"#fff"}}>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myAccountTitle}>My Rewards</Text>
            <Text style={styles.myAccountGreeting}>Hello {CUSTOMER.customer.email}</Text>
        </View>
        <View>
            <Collapse>
                <CollapseHeader>
                <View style={styles.myAccountDropdown}>
                <Text style={[styles.accordinTitleText,{marginLeft:width*0.016,fontWeight:'700'}]}>My Account</Text>
                    <Image source={require('../assets/icons/down-arrow.png')} style={styles.downArrow}/>
                </View>
                </CollapseHeader>
                <CollapseBody>
                <View style={[styles.accountAccordinInner,{backgroundColor:'#F7F7F7'}]}>
                <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyAccount')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Account Overview</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View style={{}}>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousOrders')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Orders</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('PreviousPurchases')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Previous Ordered Items</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('SavedLists')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Saved Lists</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('MyRewards')} style={{padding:height*0.016}}><Text style={[styles.myAccountMenuText,{fontWeight:'700'}]}>Reward Points</Text></TouchableOpacity>
                        <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
                    </View>
                    <View>
                        <TouchableOpacity onPress={()=>navigation.navigate('Help')} style={{padding:height*0.016}}><Text style={styles.myAccountMenuText}>Help</Text></TouchableOpacity>
                    </View>
                </View>
                </CollapseBody>
            </Collapse>
        </View>
        <View style={{padding:height*0.022}}>
            <Text style={styles.myRewardsPara}>
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's 
                standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a 
                type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining 
                essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum 
                passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </Text>
        </View>

        <View style={styles.accountInputField}>
            <Text style={styles.rewardQuantity}>{data.rewards.balance}</Text>
            <Text style={[styles.otherOptions,{fontSize:height*0.024}]}>Current Balance</Text>
        </View>

        <View style={styles.accountInputField}>
            <View style={[styles.myAccountSaperatorLine,{width:width*0.900,alignSelf:'center'}]}></View>
        </View>
        <View style={styles.accountInputField}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.otherOptions}>Total Earned:</Text>
                <Text style={[styles.otherOptions,{fontWeight:'600'}]}> 350</Text>
            </View>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.otherOptions}>Total Spent:</Text>
                <Text style={[styles.otherOptions,{fontWeight:'600'}]}> 350</Text>
            </View>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.otherOptions}>Expired:</Text>
                <Text style={[styles.otherOptions,{fontWeight:'600'}]}> 0</Text>
            </View>
        </View>


        </ScrollView>
        </>
    )
}

export default MyRewards;