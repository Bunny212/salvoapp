import React, { useState,useRef } from "react";
import { View,Text,Dimensions,TextInput,TouchableOpacity, BackHandler,Keyboard,Platform, useWindowDimensions } from "react-native";
import styles from "../styles/styles";
import stylesIpad from "../styles/stylesIpad";
import CheckBox from '@react-native-community/checkbox';
import { apiUrl } from "../Utils/constants";
import { ScrollView } from "react-native-gesture-handler";
import { useDispatch } from "react-redux";
import { setnavisionResponse } from "./redux/actions";
import { gql, useQuery } from "@apollo/client";
import { useEffect } from "react";
import KeyboardAvoidingView from "react-native/Libraries/Components/Keyboard/KeyboardAvoidingView";
const { width,height } = Dimensions.get('window');

const TradeAccount = ({navigation}) => {
    const heightPad = useWindowDimensions().height;
    const widthPad = useWindowDimensions().width;
    const [postCode,setPostCode]=useState('');
    const [postCodeMessage,setPostCodeMessage]=useState("");
    const [toggleCheckBox,setToggleCheckBox]=useState(false);
    const [toggleCheckBoxMessage,setToggleCheckBoxMessage]=useState("");
    const [registration,setRegistration]=useState('');
    const [registrationMessage,setRegistrationMessage]=useState("");
    const [response, setResponse] = useState([]);
    const [load, setLoad] = useState(true);
    const dispatch=useDispatch()
    const [error, setError] = useState(false);
    const [locationError, setLocationError]=useState('');
    const [displayServerError,setDisplayServerErrorMsg] = useState(false);
    const inputRefPostcode=useRef(null);
    const inputRefreg=useRef(null);
    const [isKeyboardVisibleHeight, setKeyboardVisibleHeight] = useState('100%');
    if (displayServerError) {
        setTimeout(() => {
          setDisplayServerErrorMsg(false);
        }, 10000);
      }
    const validate=()=>{
        if(postCode.length!=0 && registration.length==0 && toggleCheckBox){
            setPostCodeMessage("");
            setRegistrationMessage("This is a required field.");
            setToggleCheckBoxMessage('');
        }else if(registration.length!=0 && postCode.length==0 && toggleCheckBox){
            setRegistrationMessage("");
            setPostCodeMessage("This is a required field.");
            setToggleCheckBoxMessage('');
        }else if(registration.length!=0 && postCode.length==0 && toggleCheckBox){
            setRegistrationMessage("");
            setPostCodeMessage("");
            setToggleCheckBoxMessage('This is a required field.');
        }else if(registration.length==0 && postCode.length==0 && toggleCheckBox){
            setRegistrationMessage("This is a required field.");
            setPostCodeMessage("This is a required field.");
            setToggleCheckBoxMessage('');
        }else if(registration.length!=0 && postCode.length!=0 && !toggleCheckBox){
            setRegistrationMessage("");
            setPostCodeMessage("");
            setToggleCheckBoxMessage('This is a required field.');
        }else if(registration.length!=0 && postCode.length==0 && !toggleCheckBox){
            setRegistrationMessage("");
            setPostCodeMessage("This is a required field.");
            setToggleCheckBoxMessage('This is a required field.');
        }else if(registration.length==0 && postCode.length!=0 && !toggleCheckBox){
            setRegistrationMessage("This is a required field.");
            setPostCodeMessage("");
            setToggleCheckBoxMessage('This is a required field.');
            setLocationError('');
        }
        else if(postCode.length!=0 && registration.length!=0 && toggleCheckBox){
            setPostCodeMessage("");
            setRegistrationMessage("");
            setToggleCheckBoxMessage('');
            navisionValidation(postCode,registration);
        }else{
            setPostCodeMessage("This is a required field.");
            setRegistrationMessage("This is a required field.");
            setToggleCheckBoxMessage("This is a required field.");
            setLocationError('');
            setError(true);
        }

    }
 
    
    const navisionValidation = async (postcode,company_number) => {
        let params = {
          "company_number": company_number, // '06125660'
          "postcode": postcode, // 'WV3 0QH'
        };
        let query = Object.keys(params)
                     .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
                     .join('&');
        const resp = await fetch(apiUrl+"/navision/account/verify/?"+query);
        const data = await resp.json();
        if(data.valid==true){
            setLocationError('');
            setDisplayServerErrorMsg(false);
            setPostCode('');
            setRegistration('');
            setToggleCheckBox(false);
            inputRefPostcode.current.clear();
            inputRefreg.current.clear();
            navigation.navigate('Register',{postcode:postcode});
            scrollViewRef.current.scrollTo({ x: 0, y: 0, animated: true });
            dispatch(setnavisionResponse(data));
            
        }else{
            
            setDisplayServerErrorMsg(true);
            setLocationError('We are sorry but Salvo do not currently deliver to your location, please contact our Customer Services team who will be happy to assist.');
        }
      }
      
      function handleBackButtonClick() {
        navigation.navigate('DrawerNavigation',{screen:'Login'});
        return true;
      }
      const scrollViewRef = useRef(null);
      
      useEffect(() => {
       
        BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
        return () => {
          BackHandler.removeEventListener('hardwareBackPress', handleBackButtonClick);
        };
      }, []);  
      const keyboardDidShowListener=Keyboard.addListener(
        'keyboardDidShow',
        () => {
          setKeyboardVisibleHeight('60%'); // or some other action
        }
      );
      const keyboardDidHideListener =Keyboard.addListener(
        'keyboardDidHide',
        () => {
          setKeyboardVisibleHeight('100%'); // or some other action
        }
      );
    keyboardDidHideListener;
    keyboardDidShowListener;          
    
  
        if(Platform.isPad){
            return(
                <View style={{flexDirection:'row',flex:1,marginTop:'20%',justifyContent:'center'}}>
                    <View style={{width:'50%',marginTop:'2%'}}>
                        <View style={stylesIpad.tradeAccountTitle}>
                        <Text style={[stylesIpad.titleText,{fontSize:heightPad*0.024}]}>Create a Trade Account</Text>
                        </View>
                        <View style={[stylesIpad.tradeAccountTitle]}>
                        <Text style={[stylesIpad.tradeAccountDescText,{fontSize:heightPad*0.016,lineHeight:24}]}>
                            To make sure that we can deliver to your location, please enter your postcode below and click 
                            "Do you deliver to me?"
                        </Text>
                        </View>
                        <View style={stylesIpad.tradeAccountTitle}>
                        <Text style={[stylesIpad.tradeAccountDescText,{fontSize:heightPad*0.016,lineHeight:24}]}>
                            Salvo can only deliver to business addresses so please enter a valid registered business address postcode and your company registration number.
                        </Text>
                        </View>
                        <View style={stylesIpad.tradeAccountTitle}>
                        <Text style={[stylesIpad.tradeAccountDescText,{fontSize:heightPad*0.016,fontWeight:'700',lineHeight:24}]}>
                            Please ensure you are available to accept delivery between 8am and 5pm, Monday to Friday.
                        </Text>
                        </View>
                    </View>
                    <View style={{width:'50%',marginTop:'2%'}}>
                       
                        <View style={{flexDirection:'row'}}>
                            <Text style={[stylesIpad.otherOptions,{fontSize:heightPad*0.014}]}>Postcode 
                            <Text style={{fontWeight:'500'}}> (include a space in the middle)</Text></Text>
                            <Text style={{color:'#e02b27',fontSize:heightPad*0.014}}> *</Text>
                        </View>
                        <TextInput ref={inputRefPostcode} style={[stylesIpad.textInputCode,{borderColor: error? '#ed8380': '#999DA3',fontSize:heightPad*0.018}]}
                        onChangeText={newPostCode=>setPostCode(newPostCode)}/>
                        <View><Text style={[stylesIpad.tradeAccountError,{  marginTop:'1%',
                        fontSize:heightPad*0.014}]}>{postCodeMessage}</Text></View>
                        <TouchableOpacity style={{flexDirection:'row',marginTop:'1%'}} onPress={()=>setToggleCheckBox(!toggleCheckBox)}>
                            <CheckBox tintColors={'#9E663C'} boxType="square" style={stylesIpad.checkbox} value={toggleCheckBox}></CheckBox>
                            <Text style={[stylesIpad.tradeAccountDescConfirm,{fontSize:heightPad*0.014,lineHeight:24,}]}>
                                Please confirm that you have a commercial address as Salvo are unable to deliver to residential address <Text style={{color:'#e02b27'}}>*</Text>
                            </Text>
                        </TouchableOpacity>
                        <View><Text style={[stylesIpad.tradeAccountError,{  marginTop:'1%',
                            fontSize:heightPad*0.014}]}>{toggleCheckBoxMessage}</Text></View>
                        <View style={{flexDirection:'row',marginTop:'1%'}}>
                            <Text style={{color:'#000',fontSize:heightPad*0.014}}>Company Registration Number (8 digits)</Text>
                            <Text style={{color:'#e02b27',fontSize:heightPad*0.014}}> *</Text>
                        </View>
                        <TextInput ref={inputRefreg} style={[stylesIpad.textInputCode,{borderColor: error? '#ed8380': '#999DA3',fontSize:heightPad*0.018}]}
                        onChangeText={newRegistration=>setRegistration(newRegistration)}/>
                        <View><Text style={[stylesIpad.tradeAccountError,{  marginTop:'1%',
      fontSize:heightPad*0.014}]}>{registrationMessage}</Text></View>
                        <TouchableOpacity onPress={()=>{validate();}} style={[stylesIpad.createAnAccount,{ borderRadius:heightPad*0.008,width:'95%'}]}>
                            <Text style={[stylesIpad.addToBasketText,{fontSize:heightPad*0.015}]}>
                                Do you deliver to me?
                            </Text>
                        </TouchableOpacity>
                        <View style={{width:'95%',alignItems:'center',flexDirection:'row',justifyContent:'center'}}>
                        <Text style={{fontSize:heightPad*0.014,color:'#000000'}}>
                                Already have an Account?
                            </Text>
                            <TouchableOpacity onPress={()=>{navigation.navigate("Login")}} style={{marginLeft:'2%'}}>
                            <Text style={{fontSize:heightPad*0.014,color:'#317250',fontWeight:'800',}}>
                                Login
                            </Text>
                            </TouchableOpacity>
                            </View>
                            
                    </View>
                </View>
            )
        }else{
        return(
        <View style={{height:Platform.OS==='ios'?isKeyboardVisibleHeight:'100%'}}>
        <ScrollView ref={scrollViewRef} keyboardShouldPersistTaps={'handled'} style={{backgroundColor:'#fff'}}>
        <View style={styles.tradeAccountTitle}>
            <Text style={styles.titleText}>Create a Trade Account</Text>
        </View>
        {displayServerError?<View style={{paddingHorizontal:height*0.020,backgroundColor:'#fae5e5',justifyContent:'center'}}>
            <Text style={[styles.serverError,{fontSize:height*0.016}]}>{locationError}</Text>
        </View>:<View style={{backgroundColor:'#fff'}}></View>}

        <View style={styles.tradeAccountDesc}>
            <Text style={styles.tradeAccountDescText}>
                To make sure that we can deliver to your location, please enter your postcode below and click 
                "Do you deliver to me?"
            </Text>
        </View>
        <View style={[styles.tradeAccountDesc,{marginTop:height*0.010}]}>
            <Text style={styles.tradeAccountDescText}>
                Salvo can only deliver to business addresses so please enter a valid registered business address postcode and your company registration number.
            </Text>
        </View>
        <View style={[styles.tradeAccountDesc,{marginTop:height*0.010}]}>
            <Text style={styles.tradeAccountDescText}>
                Please ensure you are available to accept delivery between 8am and 5pm, Monday to Friday.
            </Text>
        </View>
        <View style={[styles.tradeAccountDesc,{marginTop:height*0.020}]}>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.otherOptions}>Postcode 
                <Text style={{fontWeight:'500'}}> (include a space in the middle)</Text></Text>
                <Text style={{color:'#e02b27'}}> *</Text>
            </View>
            <TextInput ref={inputRefPostcode} style={[styles.textInput,{borderColor: error? '#ed8380': '#999DA3'}]}
             onChangeText={newPostCode=>setPostCode(newPostCode)}/>
            <View><Text style={styles.tradeAccountError}>{postCodeMessage}</Text></View>
        </View>
        <View style={[styles.tradeAccountDesc,{marginTop:height*0.010}]}>
            <TouchableOpacity style={{flexDirection:'row'}} onPress={()=>setToggleCheckBox(!toggleCheckBox)}>
                <CheckBox tintColors={'#9E663C'} boxType="square" style={styles.checkbox} value={toggleCheckBox}></CheckBox>
                <Text style={styles.tradeAccountDescConfirm}>
                    Please confirm that you have a commercial address as Salvo are unable to deliver to residential address <Text style={{color:'#e02b27'}}>*</Text>
                </Text>
            </TouchableOpacity>
            <View><Text style={styles.tradeAccountError}>{toggleCheckBoxMessage}</Text></View>
        </View>

        <View style={[styles.tradeAccountDesc,{marginTop:height*0.020}]}>
            <View style={{flexDirection:'row'}}>
                <Text style={{color:'#000',fontSize:height*0.020}}>Company Registration Number (8 digits)</Text>
                <Text style={{color:'#e02b27'}}> *</Text>
            </View>
            <TextInput ref={inputRefreg} style={[styles.textInput,{borderColor: error? '#ed8380': '#999DA3'}]}
             onChangeText={newRegistration=>setRegistration(newRegistration)}/>
            <View><Text style={styles.tradeAccountError}>{registrationMessage}</Text></View>
        </View>

        <View style={styles.tradeAccountTitle}>
            <TouchableOpacity onPress={()=>{validate();}} style={styles.createAnAccount}>
                <Text style={styles.addToBasketText}>
                    Do you deliver to me?
                </Text>
            </TouchableOpacity>
        </View>
        </ScrollView>
       </View>
    )
        }
}

export default TradeAccount;