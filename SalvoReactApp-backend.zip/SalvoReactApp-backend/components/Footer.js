import React from 'react';
import { Text,Image, useWindowDimensions, ScrollView, Dimensions, View,TouchableOpacity,Linking,ActivityIndicator} from 'react-native';
import {gql, useQuery } from '@apollo/client';
import { RenderHTML, RenderHTMLConfigProvider,TRenderEngineProvider} from 'react-native-render-html';
import styles from '../styles/styles';
import stylesClass from '../styles/stylesClass';
import stylesTags from '../styles/stylesTags';
const { width, height } = Dimensions.get('window')

const Footer=()=>{
        const GET_FOOTER = gql`
        {
          cmsBlocks(identifiers: ["salvo_footer"]) {
            items {
              content
              identifier
              title
            }
          }
        }
      `;
      const { loading, error, data } = useQuery(GET_FOOTER);
      const {width}=useWindowDimensions();
      if (loading) return <ActivityIndicator></ActivityIndicator>;
      if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
      return (
        data.cmsBlocks?.items.map(item=>{
          const html={
            html:item.content          
          }
          const renderers = {
            
            div: ({TDefaultRenderer, tnode, ...props}) => {
              const a = tnode.domNode.attribs;
              if (a.class == 'facebook') {
             
                return (
                      <TouchableOpacity>
                        <Image style={styles.facebook} source={require('../assets/icons/facebook.png')}></Image>
                      </TouchableOpacity>
                      );
              }
              if (a.class == 'instagram') {
             
                return (
                  <TouchableOpacity >
                    <Image style={styles.instagram} source={require('../assets/icons/instagram.png')}></Image>
                  </TouchableOpacity>
                );
              }
              if (a.class == 'twitter') {
             
                return (
                  <TouchableOpacity>
                    <Image style={styles.twitter} source={require('../assets/icons/twitter.png')}></Image>
                  </TouchableOpacity>

                );
              }
              return (<TDefaultRenderer tnode={tnode} {...props} >
              </TDefaultRenderer>);
            },
          };
          return(
            <TRenderEngineProvider>
              <RenderHTMLConfigProvider>
                <View style={{}}>
                <RenderHTML classesStyles={stylesClass} tagsStyles={stylesTags} contentWidth={width} renderers={renderers} source={html}></RenderHTML>
                </View>
              </RenderHTMLConfigProvider>
            </TRenderEngineProvider>    
          );
        })
      );
}
export default Footer;