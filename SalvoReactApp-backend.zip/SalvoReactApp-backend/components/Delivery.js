import { gql, useQuery } from "@apollo/client";
import React from "react";
import { useState } from "react";
import { View,Text,TouchableOpacity,Image,Dimensions,ScrollView,ActivityIndicator } from "react-native";
import { TextInput } from "react-native-gesture-handler";
import RenderHTML, { RenderHTMLConfigProvider, TRenderEngineProvider } from "react-native-render-html";
import styles from "../styles/styles";
import stylesClass from "../styles/stylesClass";
import stylesTags from "../styles/stylesTags";
const { width, height } = Dimensions.get('window')

const Delivery = () => {
    const cheerio = require('cheerio');
  const [postCode,setPostCode]=useState('');
  const [postCodeMessage,setPostCodeMessage]=useState("");

  const validate=()=>{
      if(postCode.length!=0){
          setPostCodeMessage("")
      }
      else{
          setPostCodeMessage("This is a required field.");
      }
  }
  const [weightPriceVisible, setWeightPriceVisible] = useState('none');
  const changeWeightPriceVisible = () =>{
      if(weightPriceVisible=='none'){
       setWeightPriceVisible('flex');
      }else{
       setWeightPriceVisible('none');
      }
  }
  const [ordersAcceptancevisible, setOrdersAcceptanceVisible] = useState('none');
  const changeOrdersAcceptanceVisible = () =>{
      if(ordersAcceptancevisible=='none'){
       setOrdersAcceptanceVisible('flex');
      }else{
       setOrdersAcceptanceVisible('none');
      }
  }
  const [deliveryReceiptVisible, setDeliveryReceiptVisible] = useState('none');
  const changeDeliveryReceiptVisible = () =>{
      if(deliveryReceiptVisible=='none'){
       setDeliveryReceiptVisible('flex');
      }else{
       setDeliveryReceiptVisible('none');
      }
  }
  const [returnsVisible, setReturnsVisible] = useState('none');
  const changeReturnsVisible = () =>{
      if(returnsVisible=='none'){
       setReturnsVisible('flex');
      }else{
       setReturnsVisible('none');
      }
  }
  const [claimsVisible, setClaimsVisible] = useState('none');
  const changeClaimsVisible = () =>{
      if(claimsVisible=='none'){
       setClaimsVisible('flex');
      }else{
       setClaimsVisible('none');
      }
  }
  const [minOrderVisible, setMinOrderVisible] = useState('none');
  const changeMinOrderVisible = () =>{
      if(minOrderVisible=='none'){
       setMinOrderVisible('flex');
      }else{
       setMinOrderVisible('none');
      }
  }
  const [maxOrderVisible, setMaxOrderVisible] = useState('none');
  const changeMaxOrderVisible = () =>{
      if(maxOrderVisible=='none'){
       setMaxOrderVisible('flex');
      }else{
       setMaxOrderVisible('none');
      }
  }
  const [pricesVisible, setPricesVisible] = useState('none');
  const changePricesVisible = () =>{
      if(pricesVisible=='none'){
       setPricesVisible('flex');
      }else{
       setPricesVisible('none');
      }
  }
  
  const DELIVERY_PAGE=gql`
  {
      cmsPage(identifier:"delivery") {
        identifier
        url_key
        title
        content
      }
    }
  `;
    
  const { loading, error, data } = useQuery(DELIVERY_PAGE);
  if (loading) return <ActivityIndicator></ActivityIndicator>;
  if (error) return <Text style={{color:'#000'}}>Error :(</Text>;
    const $=cheerio.load(data.cmsPage.content);
    // const html={
    //     html:data.cmsPage.content
    // }
    const heading=$('h1');
    const img=$('img');
    const subHeading=$(".intro-title").text();
    const getAllParagraphs = (htmlContent) => {
        const $ = cheerio.load(htmlContent);
        const paragraphs = $('p').toArray();
        const paragraphTexts = paragraphs.map((p) => $(p).text());
        return paragraphTexts;
      };
      const paras=getAllParagraphs(data.cmsPage.content);
      console.log(subHeading);
  return(
      <>
      <ScrollView style={{backgroundColor:'#fff'}}>
    
      {/* <TRenderEngineProvider>
            <RenderHTMLConfigProvider>
              <ScrollView style={{padding:height*0.020,marginBottom:height*0.030,backgroundColor:'#fff'}}>
                <RenderHTML 
                    classesStyles={stylesClass} 
                    tagsStyles={stylesTags} 
                    source={html}>
                </RenderHTML>
              </ScrollView>
            </RenderHTMLConfigProvider>
        </TRenderEngineProvider>  */}
      <View style={{padding:height*0.022}}>
          <Text style={styles.deliveryTitle}>{heading.text()}</Text>
      </View>
      <View style={styles.deliveryTextContainer}>
          {/* <Text style={styles.deliveryTextPara}>
              Pellentesque lacinia rutrum augue, at rutrum lacus auctor vitae. Praesent ipsum dui, lacinia et rutrum at, 
              auctor placerat tellus. Ut eget nibh id nisl commodo tempor congue at diam. Nulla ac magna porta, ornare 
              lorem a, dignissim orci. Donec luctus nunc sed sollicitudin rutrum. Suspendisse potenti. Pellentesque 
              consectetur ornare dolor et bibendum. Mauris in justo a dui faucibus interdum eget vel arcu.
          </Text> */}
          {paras.map((item,index)=>{
            return(
                item!=""?<View><Text style={styles.deliveryTextPara}>
                {item!=""?item:"Test"}  
            </Text></View>: <View style={{paddingVertical:height*0.05}}>
                
           
                <Image source={{uri:img.attr('src'),height:height*0.2,width:width*0.9}}></Image>
                <View style={{paddingVertical:height*0.05}}>
                <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Salvo Delivery by Country</Text>
          <TouchableOpacity>
              <Image source={require('../assets/images/map.png')} 
              style={{resizeMode:'contain',width:'100%',height:height*0.570}}/>
          </TouchableOpacity>

            </View>
            <View style={{marginTop:height*0.030}}>
          <Text style={[styles.otherOptions,{fontSize:height*0.028}]}>Salvo Delivery by Post Code</Text>
            <Text style={[styles.deliveryTextPara,{textAlign:'justify',marginTop:height*0.030}]}>
            Not sure if your business is eligible for delivery? Enter your postcode below, make sure you include a space in your postcode and press "Do you deliver to me?"
          </Text>
          <View style={{marginTop:height*0.030}}>
          <Text style={[styles.deliveryTextPara,{fontWeight:'600'}]}>Postcode<Text style={{color:'red'}}> *</Text></Text>
          <TextInput style={[styles.textInput,{backgroundColor:'#fff'}]}
              onChangeText={newPostCode=>setPostCode(newPostCode)}/>
          <View><Text style={styles.tradeAccountError}>{postCodeMessage}</Text></View>
      </View>
            <View style={{marginTop:height*0.030}}>
                <TouchableOpacity onPress={()=>{validate()}} style={styles.submitForm}>
                    <Text style={styles.addToBasketText}>
                        Do you deliver to me?
                    </Text>
                </TouchableOpacity>
            </View>
            </View>
           </View>
     
            
            )
          })}
      </View>
      </ScrollView>
      </>
  )
}

export default Delivery;