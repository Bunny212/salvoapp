export const baseUrl='https://new-staging.salvo1968.co.uk/graphql';
export const apiUrl='https://new-staging.salvo1968.co.uk';
export const stagingUrl='https://new-staging.salvo1968.co.uk/';
export const imageUrl="https://new-staging.salvo1968.co.uk/media/catalog/product/cache/6bf57a88f4916e7ee0a4ae6c1b1e6489";